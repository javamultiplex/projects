package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ChangeAddress extends Activity implements OnClickListener{

	String add,type="Home Delivery";
	String order="",bill1="",totalcost="",slctstate="",slctcity="",slctloc="",line="",result="";
	InputStream is=null;
	String[] sstate={};
	String[] scity={};
	String[] sloca={};
	EditText tv;
	TextView bi;
	Button submit,home,contact,about;
	Spinner state,city,location;
	String id1,name2,selctitem;
	protected void onCreate(Bundle v){
		super.onCreate(v);
		setContentView(R.layout.change_address);
		Bundle b = getIntent().getExtras();
		Log.e("wrong at change address","after bundle");
		bill1 = b.getString("bill");
		totalcost = b.getString("totalcost");
		id1= b.getString("id");
		name2=b.getString("name");
		selctitem = b.getString("selctitem");
		
		tv = (EditText)findViewById(R.id.address);
		submit = (Button)findViewById(R.id.sub);
		home=(Button)findViewById(R.id.button1);
		contact=(Button)findViewById(R.id.button2);
		about=(Button)findViewById(R.id.about);
		bi = (TextView)findViewById(R.id.bi);
		bi.setText(bill1);
		selectstate();
        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(ChangeAddress.this, android.R.layout.simple_spinner_item, sstate);
		 state = (Spinner)findViewById(R.id.spinstate);
		 state.setAdapter(adapter2);
		 state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		    	int pos=10;
		 		  try{
		 			  Log.e("state values","selstate");
		 			  pos = state.getSelectedItemPosition();
		 			  selectcity(sstate[pos]);
		 			  Log.e("state values","selstate1"+pos);
		 			  slctstate = sstate[pos];
		 		  }
		 		  catch(Exception e){
		 			  Log.e("error", e.toString()+"    "+pos);
		 		  }
					
		    }
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}});
		 submit.setOnClickListener(this);
		 home.setOnClickListener(this);
		contact.setOnClickListener(this);
		about.setOnClickListener(this);
	}
	
	public void selectstate(){
		Log.e("Fail sending", "before connection");
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/state.php");
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			Log.e("Fail sending", "aftr connection");
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sstate =new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sstate[i]=json_data.getString("state");
				Log.e("state values",sstate[i]);
			}
		}
		catch(Exception e )
		{
			Log.e("fail json array state", "state is wrong");
		}
	}
	
	
	
	
	
	
	public void selectcity(String state){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("state",state));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/city.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			scity=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				scity[i]=json_data.getString("city");
				Log.e("state values",scity[i]);
			}
			ArrayAdapter<String> adapter1= new ArrayAdapter<String>(ChangeAddress.this, android.R.layout.simple_spinner_item, scity);
			 city = (Spinner)findViewById(R.id.spincity);
			 city.setAdapter(adapter1);
			 city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = city.getSelectedItemPosition();
				 			  selectloc(scity[pos]);
				 			  Log.e("city values","selcity1"+pos);
				 			  slctcity = scity[pos];
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	
	
	
	
	
	public void selectloc(String scity){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("city",scity));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/loc.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sloca=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sloca[i]=json_data.getString("location");
				Log.e("state values",sloca[i]);
			}
			ArrayAdapter<String> adapter2= new ArrayAdapter<String>(ChangeAddress.this, android.R.layout.simple_spinner_item, sloca);
			 location = (Spinner)findViewById(R.id.spinloc);
			 location.setAdapter(adapter2);
			 location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = location.getSelectedItemPosition();
				 			  Log.e("city values","selcity1"+pos);
				 			  slctloc = sloca[pos]; 
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent i;
		int id = arg0.getId();
		if (id == R.id.sub) {
			add = tv.getText().toString();
			connect();
		} else if (id == R.id.button1) {
			i=new Intent(ChangeAddress.this,MainActivity.class);
			startActivity(i);
		} else if (id == R.id.button2) {
			i=new Intent(ChangeAddress.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.about) {
			i=new Intent(ChangeAddress.this,About.class);
			startActivity(i);
		}
	}
	
	public void connect(){
		
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			try{
				Date currentDate = new Date(System.currentTimeMillis());
				Time currentTime = new Time();
				currentTime.setToNow();
				String cd = currentDate.toString();
				nameValuePairs.add(new BasicNameValuePair("cust_id",id1));
				nameValuePairs.add(new BasicNameValuePair("bill",selctitem));
				nameValuePairs.add(new BasicNameValuePair("totalcost",totalcost));
				nameValuePairs.add(new BasicNameValuePair("currenttime",cd));
				nameValuePairs.add(new BasicNameValuePair("address1",add));
				nameValuePairs.add(new BasicNameValuePair("slctloc",slctloc));
				nameValuePairs.add(new BasicNameValuePair("slctcity",slctcity));
				nameValuePairs.add(new BasicNameValuePair("slctstate",slctstate));
				nameValuePairs.add(new BasicNameValuePair("type",type));
				Log.e("Fail sending", "before connection");
				}
			catch(Exception e){
				Log.e("error",e.toString());
			}
			try{
				
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/order_placed.php");
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
				HttpResponse response = httpclient.execute(httppost);
				System.out.println("Response Code : " 
		                + response.getStatusLine().getStatusCode());

				HttpEntity entity = response.getEntity();
				is = entity.getContent();
			
				
			}
			catch(Exception e){
				Log.e("Fail 1",e.toString());
				Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
			}
			try{
				
				BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
				StringBuilder sb= new StringBuilder();
				while((line = reader.readLine())!=null)
				{
					sb.append(line+"\n");
				}
				is.close();
				result=sb.toString();
			}
			catch(Exception e){
				Log.e("fail 2", "connection success "+e.toString());
			}
			try
			{
				int c;
				//JSONArray jArray= new JSONArray(result);
			
				//String re = jArray.getString(jArray.length()-1);
				JSONObject json_data = new JSONObject(result);
				Log.e("Fail 3", "i m here");
				c=(json_data.getInt("c"));
						
						if(c==1){
							Toast.makeText(getBaseContext(),"your order has been placed", Toast.LENGTH_LONG).show();
							//Toast.makeText(this,"Welcome back", Toast.LENGTH_LONG).show();
							Intent i = new Intent(ChangeAddress.this,Details.class);
							i.putExtra("id",id1);
							i.putExtra("name", name2);
							startActivity(i);
						}
						else 
						{
							Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
						}
			}
			catch(Exception e)
			{
		            Log.e("Fail 3", e.toString());
			}
		
	}
}
