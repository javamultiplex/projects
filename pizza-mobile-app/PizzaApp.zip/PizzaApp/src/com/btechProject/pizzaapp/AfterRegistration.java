package com.btechProject.pizzaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AfterRegistration extends Activity implements OnClickListener{
	
	Button login,about,cont,home;
	TextView id,pass;
	
	protected void onCreate(Bundle v){
		super.onCreate(v);
		setContentView(R.layout.after_registration);
		Bundle bundle = getIntent().getExtras();
		
		String stringid = bundle.getString("code");
		String stringpass = bundle.getString("passw");
		
		login=(Button)findViewById(R.id.login);
		cont=(Button)findViewById(R.id.contact);
		about=(Button)findViewById(R.id.about);
		home=(Button)findViewById(R.id.home);
		id=(TextView)findViewById(R.id.textid);
		pass=(TextView)findViewById(R.id.textpass);
		
		id.setText(stringid);
		pass.setText(stringpass);
	
		login.setOnClickListener(this);
		cont.setOnClickListener(this);
		about.setOnClickListener(this);
		home.setOnClickListener(this);
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent i;
		int id = v.getId();
		if (id == R.id.login) {
			i=new Intent(AfterRegistration.this,Login.class);
			startActivity(i);
		} else if (id == R.id.contact) {
			i=new Intent(AfterRegistration.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.about) {
			i=new Intent(AfterRegistration.this,About.class);
			startActivity(i);
		} else if (id == R.id.home) {
			i=new Intent(AfterRegistration.this,MainActivity.class);
			startActivity(i);
		}
	}

}
