package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EditDetails extends Activity implements OnClickListener {
	
	
	Button submit,cancel,about,home,contact;
	TextView hi;
	EditText name,email,phone,address;
	String id,name1,line ="",result="",editemail,editaddress="",editcontact;
	int code;
	InputStream is =null;
	Spinner state,city,location;
	String[] sstate={};
	String[] scity={};
	String[] sloca={};
	String slctstate,slctcity,slctloc;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.editdetails);
		Bundle bundle = getIntent().getExtras();
		id = bundle.getString("id");
		name1 = bundle.getString("name");
		
		submit=(Button)findViewById(R.id.button3);
		cancel=(Button)findViewById(R.id.button4);
		contact=(Button)findViewById(R.id.button2);
		home=(Button)findViewById(R.id.button1);
		about=(Button)findViewById(R.id.about);
		hi=(TextView)findViewById(R.id.textView6);
		hi.setText(name1);
		email=(EditText)findViewById(R.id.email);
		phone=(EditText)findViewById(R.id.mobile);
		address=(EditText)findViewById(R.id.address);
		
		 selectstate();
         ArrayAdapter<String> adapter2= new ArrayAdapter<String>(EditDetails.this, android.R.layout.simple_spinner_item, sstate);
 		 state = (Spinner)findViewById(R.id.spinstate);
 		 state.setAdapter(adapter2);
 		 state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
 		    	int pos=10;
		 		  try{
		 			  Log.e("state values","selstate");
		 			  pos = state.getSelectedItemPosition();
		 			  selectcity(sstate[pos]);
		 			  Log.e("state values","selstate1"+pos);
		 			  slctstate = sstate[pos];
		 		  }
		 		  catch(Exception e){
		 			  Log.e("error", e.toString()+"    "+pos);
		 		  }
					
 		    }
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}});

		
		
		submit.setOnClickListener(this);
		cancel.setOnClickListener(this);
		contact.setOnClickListener(this);
		home.setOnClickListener(this);
		about.setOnClickListener(this);
		
		extract();
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		int id = v.getId();
		if (id == R.id.about) {
			Intent i1=new Intent(EditDetails.this,About.class);
			startActivity(i1);
		} else if (id == R.id.button1) {
			Intent i2=new Intent(EditDetails.this,MainActivity.class);
			startActivity(i2);
		} else if (id == R.id.button2) {
			Intent i3=new Intent(EditDetails.this,ContactUs.class);
			startActivity(i3);
		} else if (id == R.id.button3) {
			editcontact = phone.getText().toString();
			editaddress = address.getText().toString();
			editemail = email.getText().toString();
			update();
		} else if (id == R.id.button4) {
			Intent i5=new Intent(EditDetails.this,Details.class);
			startActivity(i5);
		}
		
		
	}
	
	
	
	
	public void extract(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("id",id));
		
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/edit.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			
			JSONObject json_data = new JSONObject(result);
			code=(json_data.getInt("code"));	
					if(code==1){
						editemail= json_data.getString("email");
						editaddress = json_data.getString("address");
						editcontact = json_data.getString("contact");
						
						email.setText(editemail);
						phone.setText(editcontact);
						address.setText(editaddress);
						
						
					}
					else
					{
						Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
	
	
	
	public void update(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("id",id));
		nameValuePairs.add(new BasicNameValuePair("email",editemail));
		nameValuePairs.add(new BasicNameValuePair("contact",editcontact));
		nameValuePairs.add(new BasicNameValuePair("address",editaddress));
		nameValuePairs.add(new BasicNameValuePair("slctstate",slctstate));
		nameValuePairs.add(new BasicNameValuePair("slctcity",slctcity));
		nameValuePairs.add(new BasicNameValuePair("slctloc",slctloc));
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/edit_details.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			
			JSONObject json_data = new JSONObject(result);
			code=(json_data.getInt("code"));	
					if(code==1){
						Toast.makeText(EditDetails.this, "Your Details Has Been Modified", Toast.LENGTH_SHORT).show();
						Intent i4=new Intent(EditDetails.this,Details.class);
						i4.putExtra("id", id);
						i4.putExtra("name", name1);
					    startActivity(i4);
						
					}
					else
					{
						Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
	public void selectstate(){
		Log.e("Fail sending", "before connection");
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/state.php");
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			Log.e("Fail sending", "aftr connection");
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sstate =new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sstate[i]=json_data.getString("state");
				Log.e("state values",sstate[i]);
			}
		}
		catch(Exception e )
		{
			Log.e("fail json array state", "state is wrong");
		}
	}
	
	
	
	
	
	
	public void selectcity(String state){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("state",state));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/city.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			scity=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				scity[i]=json_data.getString("city");
				Log.e("state values",scity[i]);
			}
			ArrayAdapter<String> adapter1= new ArrayAdapter<String>(EditDetails.this, android.R.layout.simple_spinner_item, scity);
			 city = (Spinner)findViewById(R.id.spincity);
			 city.setAdapter(adapter1);
			 city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = city.getSelectedItemPosition();
				 			  selectloc(scity[pos]);
				 			  Log.e("city values","selcity1"+pos);
				 			  slctcity = scity[pos];
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	
	
	
	
	
	public void selectloc(String scity){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("city",scity));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://10.0.2.2/loc.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sloca=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sloca[i]=json_data.getString("location");
				Log.e("state values",sloca[i]);
			}
			ArrayAdapter<String> adapter2= new ArrayAdapter<String>(EditDetails.this, android.R.layout.simple_spinner_item, sloca);
			 location = (Spinner)findViewById(R.id.spinloc);
			 location.setAdapter(adapter2);
			 location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = location.getSelectedItemPosition();
				 			  Log.e("city values","selcity1"+pos);
				 			  slctloc = sloca[pos]; 
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	
	
}
