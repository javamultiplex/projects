package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class SideOrder extends Activity implements OnClickListener{

	/**
	 * @param args
	 */
		// TODO Auto-generated method stub
		InputStream is = null;
		String line=null,result,Name,Id,Cat,Price1,Price2, n,i,order,ord="",total,stotal;
		TableLayout tlayout;
		TextView hi, setorder,totalcv;
		Button submit, side,bill,offers,register,login, home, about, contact;
		double cost=0.0,totalcost;
		int c;
		String bill1;
		String id1, name2,selctitem;
		int iid;
		LinearLayout linear,linear1;
		protected void onCreate(Bundle v){
			super.onCreate(v);
			Log.e("starting", "error before layputsetting");
			setContentView(R.layout.sideorder);
			 Log.e("starting", "error before bundle");
			Bundle b = getIntent().getExtras();
			ord= b.getString("order");
			total=b.getString("stotal");
			bill1 = b.getString("bill");
			id1= b.getString("id");
			name2=b.getString("name");
			selctitem = b.getString("selctitem");
			
			 Log.e("starting", "error in  bundle");
			 
			totalcost=Double.parseDouble(total);
			 Log.e("starting", "error after double");
			 linear =(LinearLayout)findViewById(R.id.linear);
			 linear1 =(LinearLayout)findViewById(R.id.linear1);
			submit = (Button)findViewById(R.id.sub);
			hi= (TextView)findViewById(R.id.rname1);
			setorder = (TextView)findViewById(R.id.setorder);
			totalcv = (TextView)findViewById(R.id.total);
			bill = (Button)findViewById(R.id.bill);
			offers = (Button)findViewById(R.id.offer);
			about = (Button)findViewById(R.id.about);
			home = (Button)findViewById(R.id.home);
			contact = (Button)findViewById(R.id.contact);
			hi.setText(name2);
			
			connect();
			Log.e("starting", "error after connect()");
			iid=Integer.parseInt(id1);
			if(iid != 0){
				
			
			totalcv.setText(total);
			submit.setOnClickListener(this);
			
			bill.setOnClickListener(this);
			}
			else{
				linear.removeView(submit);
				linear.removeView(bill);
				linear1.removeAllViews();
				TextView log = new TextView(SideOrder.this);
				log.setText("if you are registered then click on login to place order\n otherwise click on register ");
				linear.addView(log);
				login = new Button(SideOrder.this);
				login.setText("Login");
				login.setId(2000);
				linear.addView(login);
				
				register = new Button(SideOrder.this);
				register.setText("Register");
				register.setId(2001);
				linear.addView(register);
				register.setOnClickListener(this);
				login.setOnClickListener(this);
			}
		
			Log.e("starting", "error in last  bundle");
			offers.setOnClickListener(this);
			Log.e("starting", "error in last  bundle 1");
			contact.setOnClickListener(this);
			Log.e("starting", "error in last  bundle 2");
			home.setOnClickListener(this);
			Log.e("starting", "error in last  bundle 3");
			about.setOnClickListener(this);
			Log.e("starting", "error in last  bundle 1");
			
		}
		
		public void connect(){

			try{
				Log.e("connect", "start connect");
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/side.php");
				HttpResponse response = httpclient.execute(httppost);
				System.out.println("Response Code : " 
		                + response.getStatusLine().getStatusCode());

				HttpEntity entity = response.getEntity();
				is = entity.getContent();
			
				
			}
			catch(Exception e){
				Log.e("Fail 1",e.toString());
				Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
			}
			try{
				BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
				StringBuilder sb= new StringBuilder();
				while((line = reader.readLine())!=null)
				{
					sb.append(line+"\n");
				}
				is.close();
				result=sb.toString();
			}
			catch(Exception e){
				Log.e("fail 2", "connection success "+e.toString());
			}
			try
			{
				c=1;
				JSONArray jArray= new JSONArray(result);
				String re = jArray.getString(jArray.length()-1);
				Log.e("Fail 3", "i m here");
				tlayout=(TableLayout)findViewById(R.id.tb);
				TableRow tableline = new TableRow(SideOrder.this);
				
				tlayout.addView(tableline);
				
				TextView name1  = new TextView(SideOrder.this);
				name1.setText("name");
				name1.setPadding(10, 0, 0, 0);
				tableline.addView(name1);
				
				TextView type = new TextView(SideOrder.this);
				type.setText("type");
				type.setPadding(25, 0, 0, 0);
				tableline.addView(type);
				
				TextView cost  = new TextView(SideOrder.this);
				cost.setText("cost");
				cost.setPadding(25, 0, 0, 0);
				tableline.addView(cost);
				
				
				
				for(int i=0;i<jArray.length();i++){
				  JSONObject json_data =  jArray.getJSONObject(i);
				  Log.e("Fail 3", "i m here2");
				  
				  Name = json_data.getString("Name");
				  Cat = json_data.getString("cat");
				  Price1 = json_data.getString("price1");
				  Price2 = json_data.getString("price2");
				  
				  Log.e("Fail 3", "i m here3");
				 
					  	TableRow tr = new TableRow(SideOrder.this);
					  	
					  	
					  	
					  	TextView name = new TextView(SideOrder.this);
					  	name.setText(Name);
					  	name.setPadding(10, 0, 0, 0);
					  	tr.addView(name);
					  	
					  	TextView cat1= new TextView(SideOrder.this);
					  	cat1.setText(Cat);
					  	cat1.setPadding(25, 0, 0, 0);
					  	tr.addView(cat1);
					  		
					  		
					  	
					  	CheckBox price1 = new CheckBox(SideOrder.this);
					  	price1.setText(Price1);
					  	price1.setHint(Name);
					  	price1.setId(c);
					  	price1.setPadding(13, 0, 0, 0);
					  	tr.addView(price1);
					
					  	c++;
					  	
					  	EditText qty1= new EditText(SideOrder.this);
					  	qty1.setId(c);
					  	qty1.setText("1");
					  	qty1.setPadding(5, 0, 0, 0);
					  	tr.addView(qty1);
				
						c++;
					  	
					  	
					  	tlayout.addView(tr);
				  		//}
					  	
				}
			
			}
			catch(Exception e)
			{
		            Log.e("Fail 3", e.toString());
			}
		}

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			int t=1; 
			double cost,p,n;
			Intent i;
		  int id = arg0.getId();
		if (id == R.id.bill) {
			for(t=1;t<=c;t+=2){
				  try{
		  			CheckBox ch =(CheckBox)findViewById(t);
		  			Log.e("onclick", "before check");
		  			if(ch.isChecked()){
		  				Log.e("onclick", "after check");
		  			EditText ed = (EditText)findViewById(t+1);
		  			String stringt=ch.getText().toString();
		  			String s=ch.getHint().toString();
		  			String edt=ed.getText().toString();
		  			p=Double.parseDouble(stringt);
		  			n=Double.parseDouble(edt);
		  			cost=p*n;
		  			totalcost+=cost;
		  			selctitem = selctitem+";"+s+","+stringt+","+edt+","+cost;
		  			ord=ord+"\n"+s+"\t"+stringt+"\t"+edt+"\t"+cost+"\t";
		  			bill1=bill1+"\n"+s+"\t\t\t"+stringt+"\t\t\t"+edt+"\t\t\t\t"+cost+"\t";
		  			Log.e("onclick", "after calculation");
		  			}
				  }
				  catch(Exception e)
				  {
					  Log.e("onclick", "something wrong");
				  }
		  		}
			setorder.setText(bill1);
			stotal = String.valueOf(totalcost);
			totalcv.setText(stotal);
		} else if (id == R.id.sub) {
			i = new Intent(SideOrder.this,Bill.class);
			i.putExtra("order", ord);
			i.putExtra("bill",bill1);
			i.putExtra("totalcost",stotal);
			i.putExtra("id",id1);
			i.putExtra("name", name2);
			i.putExtra("selctitem", selctitem);
			startActivity(i);
		} else if (id == R.id.offer) {
		Log.e("side order","error in offer button");	
			i= new Intent(SideOrder.this,Offers.class);
			i.putExtra("order",ord);
			i.putExtra("bill", bill1);
			i.putExtra("totalcost",stotal);
			i.putExtra("id",id1);
			i.putExtra("name", name2);
			i.putExtra("selctitem", selctitem);
			startActivity(i);
		} else if (id == 2000) {
			i=new Intent(SideOrder.this,Login.class);
			startActivity(i);
		} else if (id == 2001) {
			i=new Intent(SideOrder.this,Registration.class);
			startActivity(i);
		} else if (id == R.id.contact) {
			i=new Intent(SideOrder.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.home) {
			i=new Intent(SideOrder.this,MainActivity.class);
			startActivity(i);
		} else if (id == R.id.about) {
			i=new Intent(SideOrder.this,About.class);
			startActivity(i);
		}
			
		}

	}

