package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Registration extends Activity implements OnClickListener{
	EditText name;
	EditText pass,retypepass,contact,email, address;
	Spinner location,city,state;
	TextView warning;
	String name1,passw,con,emal,address1,loc,line=null,result=null,gender,code,retype;
	int i, posat=0,posdot=0;
	Button submit,home,contact1,about;
	InputStream is=null;
	RadioGroup radio;
	RadioButton radiobutton;
	int c;
	String a[]={"r1","e2"};
	String[] scity={};
	String[] sstate={};
	String[] sloca={};
	String slctcity="",slctloc="",slctstate="";
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.register);  
         name=(EditText)findViewById(R.id.user);
         pass=(EditText)findViewById(R.id.pass);
         contact=(EditText)findViewById(R.id.rp);
         email=(EditText)findViewById(R.id.email);
         address=(EditText)findViewById(R.id.cn);
         retypepass=(EditText)findViewById(R.id.edpass);
         submit=(Button)findViewById(R.id.sub);
         
         home=(Button)findViewById(R.id.button1);
         about=(Button)findViewById(R.id.about);
         contact1=(Button)findViewById(R.id.button2);
         radio=(RadioGroup)findViewById(R.id.rdgp);
         
         if(android.os.Build.VERSION.SDK_INT>9)
 	    {
 	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
 	    	StrictMode.setThreadPolicy(policy);
 	    	System.out.println("Success");
 	    }
          
         selectstate();
         ArrayAdapter<String> adapter2= new ArrayAdapter<String>(Registration.this, android.R.layout.simple_spinner_item, sstate);
 		 state = (Spinner)findViewById(R.id.spinstate);
 		 state.setAdapter(adapter2);
 		 state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
 		    	int pos=10;
		 		  try{
		 			  Log.e("state values","selstate");
		 			  pos = state.getSelectedItemPosition();
		 			  selectcity(sstate[pos]);
		 			  Log.e("state values","selstate1"+pos);
		 			  slctstate = sstate[pos];
		 		  }
		 		  catch(Exception e){
		 			  Log.e("error", e.toString()+"    "+pos);
		 		  }
					
 		    }
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}});
 		 
 		
         submit.setOnClickListener(this);
         contact1.setOnClickListener(this);
         about.setOnClickListener(this);
         home.setOnClickListener(this);
}
	
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		int id = v.getId();
		if (id == R.id.sub) {
			int selectedId = radio.getCheckedRadioButtonId();
			radiobutton = (RadioButton) findViewById(selectedId);
			gender=radiobutton.getText().toString();
			name1=name.getText().toString();
			passw=pass.getText().toString();
			retype=retypepass.getText().toString();
			con=contact.getText().toString();
			emal=email.getText().toString();
			address1=address.getText().toString();
			if(name1.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your Name", Toast.LENGTH_LONG).show();
			}
			else if(passw.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your password", Toast.LENGTH_LONG).show();
			}
			else if(retype.contentEquals(""))
			{
				Toast.makeText(this,"Please retype your password for confirmation", Toast.LENGTH_LONG).show();
			}
			else if(!passw.contentEquals(retype))
			{
				Toast.makeText(this,"both the entries in password field and retype password field should be equal", Toast.LENGTH_LONG).show();
			}
			else if(con.contentEquals("") || con.length()!=10)
			{
				Toast.makeText(this,"Please enter your 10 digit mobile number with country code and 0", Toast.LENGTH_LONG).show();
			}
			else if(emal.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your valid email address", Toast.LENGTH_LONG).show();
			}
			
			else if(address1.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your valid  address", Toast.LENGTH_LONG).show();
			}
		
			else if(!emal.contentEquals(""))
			{
			int elen;
			elen=emal.length();
			for(i=0;i<elen;i++){
				if(emal.charAt(i)=='@'){
					posat=i;
					break;
				}
				
			}
			for(;i<elen;i++)
			{
				if(emal.charAt(i)=='.')
					{
						posdot=i;
						break;
					}
			}
		
			if(posat>=posdot || posdot==posat+1){
			Toast.makeText(this,"Please enter your valid email address", Toast.LENGTH_LONG).show();
			}
		
			Log.e("Fail sending", "in onClick");
				register();
				
			}
		} else if (id == R.id.button2) {
			Intent i1=new Intent(Registration.this,ContactUs.class);
			startActivity(i1);
		} else if (id == R.id.about) {
			Intent i2=new Intent(Registration.this,	About.class);
			startActivity(i2);
		} else if (id == R.id.button1) {
			Intent i3=new Intent(Registration.this,MainActivity.class);
			startActivity(i3);
		}
	}
	
	
	
	
	
	public void register(){
		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try{
			
			nameValuePairs.add(new BasicNameValuePair("name1",name1));
			nameValuePairs.add(new BasicNameValuePair("passw",passw));
			nameValuePairs.add(new BasicNameValuePair("emal",emal));
			nameValuePairs.add(new BasicNameValuePair("con",con));
			nameValuePairs.add(new BasicNameValuePair("gender",gender));
			nameValuePairs.add(new BasicNameValuePair("address1",address1));
			nameValuePairs.add(new BasicNameValuePair("slctloc",slctloc));
			nameValuePairs.add(new BasicNameValuePair("slctcity",slctcity));
			nameValuePairs.add(new BasicNameValuePair("slctstate",slctstate));
			Log.e("Fail sending", "before connection");
			}
		catch(Exception e){
			Log.e("error",e.toString());
		}
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/register.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
			HttpResponse response = httpclient.execute(httppost);
			System.out.println("Response Code : " 
	                + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			//JSONArray jArray= new JSONArray(result);
		
			//String re = jArray.getString(jArray.length()-1);
			JSONObject json_data = new JSONObject(result);
			Log.e("Fail 3", "i m here");
			code=(json_data.getString("code"));
			c=(json_data.getInt("c"));
					
					if(c==1){
						Toast.makeText(getBaseContext(),code, Toast.LENGTH_LONG).show();
						//Toast.makeText(this,"Welcome back", Toast.LENGTH_LONG).show();
						Intent i = new Intent(Registration.this,AfterRegistration.class);
						i.putExtra("code", code);
						i.putExtra("passw", passw);
						startActivity(i);
					}
					else 
					{
						Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
	
	
	
	
	public void selectstate(){
		Log.e("Fail sending", "before connection");
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/state.php");
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			Log.e("Fail sending", "aftr connection");
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sstate =new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sstate[i]=json_data.getString("state");
				Log.e("state values",sstate[i]);
			}
		}
		catch(Exception e )
		{
			Log.e("fail json array state", "state is wrong");
		}
	}
	
	
	
	
	
	
	public void selectcity(String state){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("state",state));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/city.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			scity=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				scity[i]=json_data.getString("city");
				Log.e("state values",scity[i]);
			}
			ArrayAdapter<String> adapter1= new ArrayAdapter<String>(Registration.this, android.R.layout.simple_spinner_item, scity);
			 city = (Spinner)findViewById(R.id.spincity);
			 city.setAdapter(adapter1);
			 city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = city.getSelectedItemPosition();
				 			  selectloc(scity[pos]);
				 			  Log.e("city values","selcity1"+pos);
				 			  slctcity = scity[pos];
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	
	
	
	
	
	public void selectloc(String scity){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("city",scity));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/loc.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sloca=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sloca[i]=json_data.getString("location");
				Log.e("state values",sloca[i]);
			}
			ArrayAdapter<String> adapter2= new ArrayAdapter<String>(Registration.this, android.R.layout.simple_spinner_item, sloca);
			 location = (Spinner)findViewById(R.id.spinloc);
			 location.setAdapter(adapter2);
			 location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = location.getSelectedItemPosition();
				 			  Log.e("city values","selcity1"+pos);
				 			  slctloc = sloca[pos]; 
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	}
		

