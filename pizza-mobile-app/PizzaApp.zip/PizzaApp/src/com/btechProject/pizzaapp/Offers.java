package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Offers extends Activity implements OnClickListener{
	
	String order="",totalcost="", result="",line="";
	InputStream is=null;
	Button sub,genbill, register,login, home, contact, about;
	String constraints,cat,ben1,ben2,offer="";
	int cate;
	float bene1,bene2;
	 RadioGroup rg;
	LinearLayout test,linear;
	int iid;
	String bill1="",id1,name2,selctitem;
	TextView hi;
	
	 @TargetApi(Build.VERSION_CODES.GINGERBREAD)
		@SuppressLint("NewApi")
	
	 protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.offers);
        
        Bundle b= getIntent().getExtras();
        order=b.getString("order");
        totalcost = b.getString("totalcost");
        bill1 = b.getString("bill");
        id1= b.getString("id");
		name2=b.getString("name");
		selctitem= b.getString("selctitem");
		linear = (LinearLayout)findViewById(R.id.linear);
		iid = Integer.parseInt(id1);
		test= (LinearLayout)findViewById(R.id.test);
	    sub = (Button)findViewById(R.id.sub);
	    genbill = (Button)findViewById(R.id.bill);
		home = (Button)findViewById(R.id.home);
		contact = (Button)findViewById(R.id.contact);
		about = (Button)findViewById(R.id.about);
		hi = (TextView)findViewById(R.id.rname1);
		hi.setText(name2);
	        if(iid !=0){
			
	      
	        sub.setOnClickListener(this);
	        genbill.setOnClickListener(this);
		}
		else{
			
			linear.removeView(sub);
			linear.removeView(genbill);
			TextView log = new TextView(Offers.this);
			log.setText("if you are registered then click on login to place order\n otherwise click on register ");
			linear.addView(log);
			login = new Button(Offers.this);
			login.setText("Login");
			login.setId(2000);
			linear.addView(login);
			
			register = new Button(Offers.this);
			register.setText("Register");
			register.setId(2001);
			linear.addView(register);
			register.setOnClickListener(this);
			login.setOnClickListener(this);
		}
        if(android.os.Build.VERSION.SDK_INT>9)
	    {
	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    	StrictMode.setThreadPolicy(policy);
	    	System.out.println("Success");
	    }
        connect();
        Log.e("offer", "i m after connect");
        home.setOnClickListener(this);
        about.setOnClickListener(this);
        contact.setOnClickListener(this);
        
	}
	
	public void onClick(View v){
		
		Intent in;
		int id = v.getId();
		if (id == R.id.bill) {
			try{
				int rgid = rg.getCheckedRadioButtonId();
				if(rgid>0){
						int tv1=rgid+1;
						int tv2 = rgid+2;
						int c=0;
						TextView text = (TextView)findViewById(tv1);
						TextView text1 = (TextView)findViewById(tv2);
						String tv2hint="",tv2text="",tv1Text="",tv1hint="";
						tv2hint = text1.getHint().toString();
						tv2text = text1.getText().toString();
						int tv2cat = Integer.parseInt(tv2text);
						
						tv1Text = text.getText().toString();
						tv1hint = text.getHint().toString();
						float ben12;
						ben12 = Float.parseFloat(tv1hint);
						if(tv2cat == 1){
								for(int i=0;i<tv2hint.length();i++){
									if( i==tv2hint.length()-1 || tv2hint.charAt(i)==',')
										c++;
								}
								String[] s = new String[c];
								int pos1 =0,pos2,j=0;
								for(int i=0;i<=tv2hint.length();i++){
									if( i==tv2hint.length() || tv2hint.charAt(i)==','){
										pos2 =i;
										s[j]=tv2hint.substring(pos1, pos2);
										pos1=pos2+1;
										j++;
										
									}
								}
								
								Log.e("wrong on submit " ,"before length()");
								int ol=order.length();
								Log.e("wrong on submit " ,"outside for 2");
								Boolean valid;
								int flag=0;
								for(j=0;j<c;j++){
									flag=0;
									for(int i=0;i<ol;i++){
										pos1=order.indexOf('\n',i);
										Log.e("wrong on submit " ,"inside for 2");
										//pos2= order.indexOf('\t',pos1);
										if(pos1 != -1){
										valid = order.regionMatches(pos1+1,s[j],0,s[j].length());
										Log.e("wrong on submit " ,s[j]);
										if(valid == true){
											Log.e("wrong on submit " ,"inside if 2");
											flag=1;
											break;
										}
									}
								}
								if(flag==0){
									Toast.makeText(getApplicationContext(),"Constraints are not full filled", Toast.LENGTH_LONG).show();
									break;
								}
								
								}
								if(flag==1)
								{
									Toast.makeText(getApplicationContext(),"offers successfully added", Toast.LENGTH_LONG).show();
									Log.e("wrong on submit " ,"flag 1");
									order+="\n"+tv1Text+"\t"+tv1hint+"\t"+"1"+"\t"+tv1hint;
									bill1 += String.format("%-20.5s", tv1Text)+String.format("%-10s", tv1hint)+String.format("%-10s","1")+tv1hint+"\t";
									Log.e("wrong on submit " ,"flag 2");
									float total = Float.parseFloat(totalcost);
									Log.e("wrong on submit " ,"flag 3");
									total+=ben12;
									TextView st = new TextView(Offers.this);
									st.setText(order);
									Log.e("wrong on submit " ,"flag 4");
									test.addView(st);
									totalcost = String.valueOf(total);
									TextView totalc = new TextView(Offers.this);
									totalc.setText(totalcost);
									test.addView(totalc);
							
								}
								
						}
						else if(tv2cat==2){
							float cons = Float.parseFloat(tv2hint);
							float ftotal =Float.parseFloat(totalcost);
							if(cons < ftotal){
								Toast.makeText(getApplicationContext(),"offers successfully added", Toast.LENGTH_LONG).show();
								ftotal = ftotal-cons;
								selctitem+=";Discount"+",,,"+cons;
								order+="\nDiscount"+"\t\t\t"+cons;
								bill1+="\n"+String.format("%-20s", "discount")+String.format("%f", cons);
								TextView st = new TextView(Offers.this);
								st.setText(bill1);
								Log.e("wrong on submit " ,"flag 4");
								test.addView(st);
								totalcost = String.valueOf(ftotal);
								TextView totalc = new TextView(Offers.this);
								totalc.setText(totalcost);
								test.addView(totalc);
							}
							
						}
				}
				else
				{
							TextView st = new TextView(Offers.this);
						st.setText(bill1);
						Log.e("wrong on submit " ,"flag 4");
						test.addView(st);
						TextView totalc = new TextView(Offers.this);
						totalc.setText(totalcost);
						test.addView(totalc);
				}
		}
			catch(Exception e){
				Log.e("wrong on submit " ,e.toString());
			}
		} else if (id == R.id.sub) {
			in=new Intent(Offers.this,Bill.class);
			Log.e("wrong on submit " ,"flag 20");
			in.putExtra("order",order);
			Log.e("wrong on submit " ,"flag 21");
			in.putExtra("bill", bill1);
			Log.e("wrong on submit " ,"flag 22");
			in.putExtra("totalcost", totalcost);
			Log.e("wrong on submit " ,"flag 22");
			in.putExtra("id",id1);
			in.putExtra("name", name2);
			in.putExtra("selctitem", selctitem);
			startActivity(in);
		} else if (id == 2000) {
			in=new Intent(Offers.this,Login.class);
			startActivity(in);
		} else if (id == 2001) {
			in=new Intent(Offers.this,Registration.class);
			startActivity(in);
		} else if (id == R.id.about) {
			in=new Intent(Offers.this,About.class);
			startActivity(in);
		} else if (id == R.id.contact) {
			in=new Intent(Offers.this,ContactUs.class);
			startActivity(in);
		} else if (id == R.id.home) {
			in=new Intent(Offers.this,MainActivity.class);
			startActivity(in);
		}
	}
	
	
	public void connect()
	{
		try{
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/offers.php");
			Log.e("fail 1","something wrong ");
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			Log.e("fail 1","something wrong 2");
			
		}
		
		catch(Exception e)
		{
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
			Log.e("fail 1 ", " invalid Ip address");
			
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"),8);
			StringBuilder sb = new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			int c=0;
			JSONArray jArray = new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			
			Log.e("fail 1","something wrong 3");
			
			   LinearLayout tb = (LinearLayout)findViewById(R.id.tb);
			  rg = new RadioGroup(Offers.this);
			   tb.addView(rg);
			for(int i=0;i<jArray.length();i++){
			JSONObject json_data = jArray.getJSONObject(i);
			
			constraints = json_data.getString("constraints");
			
			cat = json_data.getString("cat");
			
			ben1 = json_data.getString("benefits1");
			
			ben2 = json_data.getString("benefit2");
			cate = Integer.parseInt(cat);
			bene2 = Float.parseFloat(ben2);
			
			Log.e("fail 1","something wrong 7");
			TableRow tr = new TableRow(Offers.this);
			
			
			Log.e("fail 1","something wrong 6");
			 if(cate==1){
				 Log.e("fail 1","something wrong 5");
				 if(bene2 == 0)
					 offer = "Buy "+constraints+" and get 1"+ben1+" free";
				 else if(bene2 >0)
					 offer = "Buy "+constraints+" and get 1 "+ben1+" at "+bene2;
				 else 
				 {
					 bene2 = bene2*100;
				 	offer = "Buy "+constraints+" and get "+bene2+"% discount on 1"+bene1;
				  }
			 }
			 else{
				 if(bene2 < 0)
					 {
					 bene2 = bene2*100;
				 	offer = "Get "+ben2+"% discount on minimum bii of Rs"+constraints;
					 }
			 	else
			 		offer = "Get Rs"+ben2+" OFF on minimum bii of Rs"+constraints;
			 			
			}
			 
			 
			 RadioButton ch = new RadioButton(Offers.this);
			 ch.setId(c);
			 ch.setText(offer);
			 rg.addView(ch);
			 Log.e("fail 1","something wrong 4");;
			 c++;
			 
			 TextView tv1 = new TextView(Offers.this);
			 tv1.setId(c);
			 tv1.setText(ben1);
			 tv1.setHint(ben2);
			 tv1.setVisibility(View.INVISIBLE);
			 tb.addView(tv1);
			 c++;
			 
			 TextView tv2 = new TextView(Offers.this);
			 tv2.setId(c);
			 tv2.setText(cat);
			 tv2.setHint(constraints);
			 tv2.setVisibility(View.INVISIBLE);
			 tb.addView(tv2);
			 c++;
			 
			 
			}
		}
		catch(Exception e){
			
		}
	}

}
