package com.btechProject.pizzaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ContactUs extends Activity implements OnClickListener{

	Button about,home;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contactus);
		
		about=(Button)findViewById(R.id.about);
		home=(Button)findViewById(R.id.button1);
		
		about.setOnClickListener(this);
		home.setOnClickListener(this);
		
			}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		int id = v.getId();
		if (id == R.id.about) {
			Intent i=new Intent(ContactUs.this,About.class);
			startActivity(i);
		} else if (id == R.id.button1) {
			Intent i1=new Intent(ContactUs.this,MainActivity.class);
			startActivity(i1);
		}
	}

	
	
}
