package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class ForgetPassword extends Activity implements OnClickListener{
	
	Button about,contact,home,submit;
	EditText pass, confpass, email,id;
	InputStream is = null;
	String chpass="", chid="", chemail="", chconfpass="", line ="", result = "";
	int code;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.forgtpass);
		
		Log.e("forget","wrong after setcontent view");
		id = (EditText)findViewById(R.id.chid);
		pass = (EditText)findViewById(R.id.chpass);
		confpass =(EditText)findViewById(R.id.confpass);
		email=(EditText)findViewById(R.id.chemail);
		
		Log.e("forget","wrong after setcontent view 1");
		about=(Button)findViewById(R.id.about);
        contact=(Button)findViewById(R.id.button2);
        home=(Button)findViewById(R.id.button1);
        submit=(Button)findViewById(R.id.button3);


        Log.e("forget","wrong after setcontent view 3 ");
        about.setOnClickListener(this);
        home.setOnClickListener(this);
        contact.setOnClickListener(this);
        submit.setOnClickListener(this);
		
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		Intent i;
		int id1 = v.getId();
		if (id1 == R.id.about) {
			i=new Intent(ForgetPassword.this,About.class);
			startActivity(i);
		} else if (id1 == R.id.button1
				|| id1 == R.id.button2) {
			i=new Intent(ForgetPassword.this,ContactUs.class);
			startActivity(i);
		} else if (id1 == R.id.button3) {
			try{
			    	Log.e("forget","wrong after setcontent view 2");
			    	chpass = pass.getText().toString();
			    	Log.e("forget","wrong after setcontent view 4");
			    	chid = id.getText().toString();
			    	Log.e("forget","wrong after setcontent view 5");
			    	chconfpass = confpass.getText().toString();
			    	Log.e("forget","wrong after setcontent view 6");
			    	chemail = email.getText().toString();
			    	Log.e("forget","wrong after setcontent view 7");
			  
			   Log.e("forget","wrong after setcontent view 8");
				if(chid.contentEquals("")){
					Toast.makeText(ForgetPassword.this, "enter your id provided to you", Toast.LENGTH_LONG).show();
				}
				
				else if(chemail.contentEquals("")){
					Toast.makeText(ForgetPassword.this, "enter your email id ", Toast.LENGTH_LONG).show();
				}
				else if(chpass.contentEquals("")){
					Toast.makeText(ForgetPassword.this, "enter your new password", Toast.LENGTH_LONG).show();
				}
				else if(chconfpass.contentEquals("")){
					Toast.makeText(ForgetPassword.this, "enter the password in confirm field to reset password", Toast.LENGTH_LONG).show();
				}
				else if(!(chconfpass.equals(chpass))){
					Log.e("forget","wrong after setcontent view 9");
					Toast.makeText(ForgetPassword.this, "password and confirm password fields shuld have same value", Toast.LENGTH_LONG).show();
				}
				else
				{   
					Log.e("forget","wrong after setcontent view 9");
					update();
				}
			   }
			   catch(Exception e){
				   Log.e("forget","something wrong  "+e.toString());
			   }
		}
		
	}
	

	public void update(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("chid",chid));
		nameValuePairs.add(new BasicNameValuePair("chpass",chpass));
		nameValuePairs.add(new BasicNameValuePair("chemail",chemail));
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/forget.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			
			JSONObject json_data = new JSONObject(result);
			code=(json_data.getInt("code"));	
					if(code==1){
						
						Toast.makeText(this,"your password has been changed successfully " , Toast.LENGTH_LONG).show();
						Intent i=new Intent(ForgetPassword.this,Login.class);
						startActivity(i);
					}
					else
					{
						Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
	
	
}
