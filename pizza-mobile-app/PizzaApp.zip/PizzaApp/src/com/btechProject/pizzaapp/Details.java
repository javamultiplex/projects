package com.btechProject.pizzaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Details extends Activity implements OnClickListener{
	Button placeorder,home,about,contact,reset,logout,edit, history;
	TextView hi;
	String id1,name;
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);
        
        Bundle bundle = getIntent().getExtras();
        name = bundle.getString("name");
        id1 = bundle.getString("id");
        
        placeorder=(Button)findViewById(R.id.plcorder);
        hi=(TextView)findViewById(R.id.name);
        about=(Button)findViewById(R.id.about);
        contact=(Button)findViewById(R.id.button2);
        home=(Button)findViewById(R.id.button1);
        reset=(Button)findViewById(R.id.chpass);
        logout=(Button)findViewById(R.id.button3);
        edit=(Button)findViewById(R.id.edtdetails);
        history = (Button)findViewById(R.id.history);
        placeorder.setOnClickListener(this);
        
        
        hi.setText(name);
        
 reset.setOnClickListener(this);
               
 about.setOnClickListener(this);
         
         home.setOnClickListener(this);
         contact.setOnClickListener(this);
         
         logout.setOnClickListener(this);
        
         edit.setOnClickListener(this);
         history.setOnClickListener(this);
         
        }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent i;
		int id = v.getId();
		if (id == R.id.about) {
			i=new Intent(Details.this,	About.class);
			startActivity(i);
		} else if (id == R.id.plcorder) {
			String selctitem = "Name,QTY,Unit Price,Price";
			i=new Intent(Details.this, Order.class);
			i.putExtra("selctitem", selctitem);
			i.putExtra("id", id1);
			i.putExtra("name", name);
			startActivity(i);
		} else if (id == R.id.button3) {
			Toast.makeText(Details.this, "You Are Logged Out Successfully", Toast.LENGTH_SHORT).show();
			i=new Intent(Details.this,MainActivity.class);
			startActivity(i);
		} else if (id == R.id.button2) {
			i=new Intent(Details.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.button1) {
			i=new Intent(Details.this,MainActivity.class);
			startActivity(i);
		} else if (id == R.id.chpass) {
			i=new Intent(Details.this,	ResetPassword.class);
			i.putExtra("id", id1);
			i.putExtra("name", name);
			startActivity(i);
		} else if (id == R.id.edtdetails) {
			i=new Intent(Details.this,EditDetails.class);
			i.putExtra("id", id1);
			i.putExtra("name", name);
			startActivity(i);
		} else if (id == R.id.history) {
			i = new Intent(Details.this,History.class);
			i.putExtra("id", id1);
			i.putExtra("name", name);
			startActivity(i);
		}
		
		}
		
	}
