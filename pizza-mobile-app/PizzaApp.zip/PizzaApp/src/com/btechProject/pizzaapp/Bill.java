package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Bill extends Activity implements OnClickListener{

	String order="", bill1="",totalcost="",type;
	TextView tv,cost;
	Button tkawy,homed,about,contact,home;
	String[] sstate={};
	String[] scity={};
	String[] sloca ={};
	Spinner state,city,location;
	InputStream is = null;
	String line="",result="";
	String slctstate,slctcity,slctloc;
	LinearLayout linear; 
	String id1,name2,selctitem;
	
		// TODO Auto-generated method stub
		protected void onCreate(Bundle v){
			super.onCreate(v);
			setContentView(R.layout.bill);
			Bundle b = getIntent().getExtras();
			order = b.getString("order");
			bill1 = b.getString("bill");
			totalcost = b.getString("totalcost");
			id1= b.getString("id");
			name2=b.getString("name");
			selctitem = b.getString("selctitem");
			
			tkawy = (Button)findViewById(R.id.takeaway);
			homed = (Button)findViewById(R.id.homedel);
			tv = (TextView)findViewById(R.id.bill);
			cost = (TextView)findViewById(R.id.cost);
			tv.setText(bill1);
			cost.setText(totalcost);
			linear = (LinearLayout)findViewById(R.id.linear);
			home=(Button)findViewById(R.id.button1);
			contact=(Button)findViewById(R.id.button2);
			about=(Button)findViewById(R.id.about);
			
			tkawy.setOnClickListener(this);
			homed.setOnClickListener(this);
			home.setOnClickListener(this);
			contact.setOnClickListener(this);
			about.setOnClickListener(this);
			
			
	}
		
		
		
		
		@Override
		public void onClick(View arg0) {
			
			Intent i;
			TextView tv;
			Button conf;
			int id = arg0.getId();
			if (id == R.id.takeaway) {
				linear.removeAllViews();
				tv = new TextView(Bill.this);
				tv.setText("please click confirm to place your order");
				linear.addView(tv);
				conf = new Button(Bill.this);
				conf.setText("Confirm");
				conf.setId(20);
				linear.addView(conf);
				conf.setOnClickListener(this);
			} else if (id == R.id.homedel) {
				linear.removeAllViews();
				tv = new TextView(Bill.this);
				tv.setText("if you want to delivery at another place then your permanent address then \nclick on change address otherwise click confirm");
				linear.addView(tv);
				conf = new Button(Bill.this);
				conf.setText("Confirm");
				conf.setId(2);
				linear.addView(conf);
				Button address = new Button(Bill.this);
				address.setText("Change Address");
				address.setId(3);
				linear.addView(address);
				address.setOnClickListener(this);
				conf.setOnClickListener(this);
			} else if (id == 20) {
				Log.e("bill","wrong at 1");
				type = "take away";
				connect();
			} else if (id == 2) {
				type = "home delivery";
				connect();
			} else if (id == 3) {
				i=new Intent(Bill.this,ChangeAddress.class);
				i.putExtra("bill", order);
				i.putExtra("totalcost",totalcost);
				i.putExtra("id",id1);
				i.putExtra("name", name2);
				i.putExtra("selctitem", selctitem);
				startActivity(i);
			} else if (id == R.id.button1) {
				i=new Intent(Bill.this,MainActivity.class);
				startActivity(i);
			} else if (id == R.id.button2) {
				i=new Intent(Bill.this,ContactUs.class);
				startActivity(i);
			} else if (id == R.id.about) {
				i=new Intent(Bill.this,About.class);
				startActivity(i);
			}
		}
		
public void connect(){
		
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			try{
				Date currentDate = new Date(System.currentTimeMillis());
				Time currentTime = new Time();
				currentTime.setToNow();
				String cd = currentDate.toString();
				nameValuePairs.add(new BasicNameValuePair("cust_id",id1));
				nameValuePairs.add(new BasicNameValuePair("bill",selctitem));
				nameValuePairs.add(new BasicNameValuePair("totalcost",totalcost));
				nameValuePairs.add(new BasicNameValuePair("currenttime",cd));
				nameValuePairs.add(new BasicNameValuePair("type",type));
				Log.e("Fail sending", "before connection");
				}
			catch(Exception e){
				Log.e("error",e.toString());
			}
			try{
				
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/order_placed2.php");
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
				HttpResponse response = httpclient.execute(httppost);
				System.out.println("Response Code : " 
		                + response.getStatusLine().getStatusCode());

				HttpEntity entity = response.getEntity();
				is = entity.getContent();
			
				
			}
			catch(Exception e){
				Log.e("Fail 1",e.toString());
				Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
			}
			try{
				
				BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
				StringBuilder sb= new StringBuilder();
				while((line = reader.readLine())!=null)
				{
					sb.append(line+"\n");
				}
				is.close();
				result=sb.toString();
			}
			catch(Exception e){
				Log.e("fail 2", "connection success "+e.toString());
			}
			try
			{
				int c;
				//JSONArray jArray= new JSONArray(result);
			
				//String re = jArray.getString(jArray.length()-1);
				JSONObject json_data = new JSONObject(result);
				Log.e("Fail 3", "i m here");
				c=(json_data.getInt("c"));
						
						if(c==1){
							Toast.makeText(getBaseContext(),"your order has been placed", Toast.LENGTH_LONG).show();
							//Toast.makeText(this,"Welcome back", Toast.LENGTH_LONG).show();
							Intent i = new Intent(Bill.this,Details.class);
							i.putExtra("id",id1);
							i.putExtra("name", name2);
							startActivity(i);
						}
						else 
						{
							Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
						}
			}
			catch(Exception e)
			{
		            Log.e("Fail 3", e.toString());
			}
		
	}
		

}
