package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class History  extends Activity{

	String id ="",name="", line ="", result="";
	InputStream is=null;
	LinearLayout linear;

	protected void onCreate(Bundle v){
		super.onCreate(v);
		setContentView(R.layout.history);
		
		Bundle c = getIntent().getExtras();
		id = c.getString("id");
		name = c.getString("name");
		
		linear = (LinearLayout)findViewById(R.id.linear);
		
		
		conect();
	}
	
	public void conect(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("id",id));
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/history.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			JSONArray jArray = new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			int i=0;
			String temp;	
			for( i=0;i<jArray.length();i++){
				JSONObject json_data = jArray.getJSONObject(i);
				
				TextView date = new TextView(History.this);
				date.setText(json_data.getString("time"));
				linear.addView(date);
				
				TextView tv = new TextView(History.this);
				String s = json_data.getString("item_list");
				temp = s.replaceAll(",", "\t\t\t\t");
				temp = temp.replaceAll(";", "\n");
				tv.setPadding(10, 30, 10, 20);
				tv.setTextSize(20);
				tv.setText(temp);
				linear.addView(tv);
				
				TextView total = new TextView(History.this);
				total.setText(json_data.getString("total_cost"));
				
				TextView newdata = new TextView(History.this);
				String newline = "\n        \n\n\n";
				newdata.setText(newline);
			}
		}
		catch(Exception e){
			Log.e("history ","wrong  "+e.toString());
		}
			
	}
	
	
}
