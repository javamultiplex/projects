package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class ResetPassword extends Activity implements OnClickListener{
	
	Button about,contact,home,submit,cancel;
	EditText pass, confpass, oldpass;
	InputStream is = null;
	String chpass="", chid="", chemail="", chconfpass="", line ="", result = "",choldpass="",id="",name = "";
	int code;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.respass);
		
		Bundle b = getIntent().getExtras();
		id = b.getString("id");
		name = b.getString("name");
		Log.e("forget","wrong after setcontent view");
		
		pass = (EditText)findViewById(R.id.chpass);
		confpass =(EditText)findViewById(R.id.confpass);
		oldpass=(EditText)findViewById(R.id.oldpass);
		
		Log.e("forget","wrong after setcontent view 1");
		about=(Button)findViewById(R.id.about);
        contact=(Button)findViewById(R.id.button2);
        home=(Button)findViewById(R.id.button1);
        submit=(Button)findViewById(R.id.button3);
        cancel=(Button)findViewById(R.id.button4);

        Log.e("forget","wrong after setcontent view 3 ");
        about.setOnClickListener(this);
        home.setOnClickListener(this);
        contact.setOnClickListener(this);
        submit.setOnClickListener(this);
        cancel.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		Intent i;
		int id = v.getId();
		if (id == R.id.about) {
			i=new Intent(ResetPassword.this,About.class);
			startActivity(i);
		} else if (id == R.id.button1
				|| id == R.id.button2) {
			i=new Intent(ResetPassword.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.button3) {
			try{
			    	chpass = pass.getText().toString();
			    	chconfpass = confpass.getText().toString();
			    	choldpass=oldpass.getText().toString();
			  
			   Log.e("forget","wrong after setcontent view 8");
				if(choldpass.contentEquals("")){
					Toast.makeText(ResetPassword.this, "enter your old password to you", Toast.LENGTH_LONG).show();
				}
				else if(chpass.contentEquals("")){
					Toast.makeText(ResetPassword.this, "enter your new password", Toast.LENGTH_LONG).show();
				}
				else if(chconfpass.contentEquals("")){
					Toast.makeText(ResetPassword.this, "enter the password in confirm field to reset password", Toast.LENGTH_LONG).show();
				}
				else if(!(chconfpass.equals(chpass))){
					Log.e("forget","wrong after setcontent view 9");
					Toast.makeText(ResetPassword.this, "password and confirm password fields shuld have same value", Toast.LENGTH_LONG).show();
				}
				else
				{   
					Log.e("forget","wrong after setcontent view 9");
					update();
				}
			   }
			   catch(Exception e){
				   Log.e("forget","something wrong  "+e.toString());
			   }
		} else if (id == R.id.button4) {
			i=new Intent(ResetPassword.this,Details.class);
			startActivity(i);
		}
		
	}

	public void update(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("id",id));
		nameValuePairs.add(new BasicNameValuePair("chpass",chpass));
		nameValuePairs.add(new BasicNameValuePair("choldpass",choldpass));
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/reset.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			
			JSONObject json_data = new JSONObject(result);
			code=(json_data.getInt("code"));	
					if(code==1){
						
						Toast.makeText(this,"your password has been changed successfully " , Toast.LENGTH_LONG).show();
						Intent i=new Intent(ResetPassword.this,Login.class);
						startActivity(i);
					}
					else
					{
						Toast.makeText(getBaseContext(), "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
	
	
}
