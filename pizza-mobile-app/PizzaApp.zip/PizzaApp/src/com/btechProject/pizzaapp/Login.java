package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.widget.TextView;



public class Login extends Activity implements OnClickListener{
	EditText name,password;
	Button submit,home,contact,about,forget;
	String id1,pass,line=null,result=null;
	InputStream is=null;
	int code;
	String name1;
	
	 @TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.login);
	        
	        name=(EditText)findViewById(R.id.name);
	        password=(EditText)findViewById(R.id.pass);
            submit=(Button)findViewById(R.id.sub);
            home=(Button)findViewById(R.id.button1);
            about=(Button)findViewById(R.id.about);
            contact=(Button)findViewById(R.id.button2);
            forget=(Button)findViewById(R.id.button3);
            
            if(android.os.Build.VERSION.SDK_INT>9)
    	    {
    	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    	    	StrictMode.setThreadPolicy(policy);
    	    	System.out.println("Success");
    	    }
            
            submit.setOnClickListener(this);
            home.setOnClickListener(this);
            about.setOnClickListener(this);
            contact.setOnClickListener(this);
            forget.setOnClickListener(this);
    }

	@Override
	public void onClick(View v) {
		
		int id = v.getId();
		if (id == R.id.sub) {
			id1=name.getText().toString();
			pass=password.getText().toString();
			if(id1.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your Login Id", Toast.LENGTH_LONG).show();
			}
			else if(pass.contentEquals(""))
			{
				Toast.makeText(this,"Please enter your password", Toast.LENGTH_LONG).show();
			}
			else{
				insert();
				
				
			}
		} else if (id == R.id.about) {
			Intent i=new Intent(Login.this,About.class);
			startActivity(i);
		} else if (id == R.id.button1) {
			Intent i1=new Intent(Login.this,MainActivity.class);
			startActivity(i1);
		} else if (id == R.id.button2) {
			Intent i2=new Intent(Login.this,ContactUs.class);
			startActivity(i2);
		} else if (id == R.id.button3) {
			Intent i3=new Intent(Login.this,ForgetPassword.class);
			startActivity(i3);
		}
		
	}
	
	public void insert(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("id",id1));
		nameValuePairs.add(new BasicNameValuePair("pass",pass));
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/login.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{
			
			JSONObject json_data = new JSONObject(result);
			code=(json_data.getInt("code"));
					
					if(code==1){
						name1=json_data.getString("name");
						Toast.makeText(this,"Welcome! "+name1 , Toast.LENGTH_LONG).show();
						Intent i=new Intent(Login.this, Details.class);
						i.putExtra("name", name1);
						i.putExtra("id",id1);
						startActivity(i);
					}
					else
					{
						Toast.makeText(this, "Sorry, Try Again",Toast.LENGTH_LONG).show();
					}
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}
}

