package com.btechProject.pizzaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Front extends Activity {
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.front_page);
	        Thread timer= new Thread(){
				public void run(){
					try{
						sleep(2000);
					}catch(InterruptedException e){
						e.printStackTrace();
					}finally{
						Intent openMainActivity= new Intent("com.btechProject.pizzaapp.MAINACTIVITY");
						
						startActivity(openMainActivity);
					}
				}
			};
			timer.start();
	 }

}
