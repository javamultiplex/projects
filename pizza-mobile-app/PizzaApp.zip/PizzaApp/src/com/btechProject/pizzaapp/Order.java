package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.btechProject.pizzaapp.ImageLoader;
import com.btechProject.pizzaapp.R;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Order extends Activity implements OnClickListener, OnItemSelectedListener{
	
	InputStream is = null;
	String line=null,result,Name,Id,Cat1,Cat2,Price1,Price2,Price3, name2,id1,order="",description;
	TableLayout tlayout;
	TextView hi, setorder,total;
	String item="none";
	Button submit, side,bill,login,register,about,contactus,home,loc;
	double cost=0, totalcost=0;
	String stotal="";
	int c;
	String bill1="",selctitem="";
	String[] paths = {"Veg Pizza","Non-Veg Pizza"};
	Spinner sp;
	LinearLayout linear,linear1;
	int iid;
	 @TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	protected void onCreate(Bundle v){
		super.onCreate(v);
		setContentView(R.layout.order);
		Bundle b = getIntent().getExtras();
		id1= b.getString("id");
		name2=b.getString("name");
		selctitem=b.getString("selctitem");
		bill1="Name\t\tQty\t\tUnit Price\t\t\tCost";
		Log.e("Order", "i m before strict mode");
		if(android.os.Build.VERSION.SDK_INT>9)
	    {
	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    	StrictMode.setThreadPolicy(policy);
	    	System.out.println("Success");
	    }
		Log.e("Order", "i m before strict mode 1");
		linear = (LinearLayout)findViewById(R.id.linear);
		Log.e("Order", "i m before strict mode 2");
		linear1= (LinearLayout)findViewById(R.id.linear1);
		submit = (Button)findViewById(R.id.sub);
		side = (Button)findViewById(R.id.side);
		hi= (TextView)findViewById(R.id.rname1);
		setorder = (TextView)findViewById(R.id.setorder);
		total = (TextView)findViewById(R.id.total);
		bill = (Button)findViewById(R.id.bill);
		about = (Button)findViewById(R.id.about);
		contactus = (Button)findViewById(R.id.contact);
		home = (Button)findViewById(R.id.home);
		loc = (Button)findViewById(R.id.loc);
		
		Log.e("Order", "i m before strict mode 2");
		
		iid =Integer.parseInt(id1);
		if(iid != 0){
	
		hi.setText(name2);
		submit.setOnClickListener(this);
		
		bill.setOnClickListener(this);
		Log.e("Order", "i m before strict mode 3");
		}
		else{
			linear.removeView(submit);
			linear.removeView(bill);
			linear1.removeAllViews();
			TextView log = new TextView(Order.this);
			log.setText("if you are registered then click on login to place order\n otherwise click on register ");
			linear.addView(log);
			login = new Button(Order.this);
			login.setText("Login");
			login.setId(2000);
			linear.addView(login);
			
			register = new Button(Order.this);
			register.setText("Register");
			register.setId(2001);
			linear.addView(register);
			register.setOnClickListener(this);
			login.setOnClickListener(this);
		}
		about.setOnClickListener(this);
		contactus.setOnClickListener(this);
		home.setOnClickListener(this);
		side.setOnClickListener(this);
		loc.setOnClickListener(this);
		
		connect();
		
		ArrayAdapter<String> adapter= new ArrayAdapter<String>(Order.this, android.R.layout.simple_spinner_item, paths);
		sp = (Spinner) findViewById(R.id.choice);
		sp.setAdapter(adapter);
		sp.setOnItemSelectedListener(this);
		
	}
	
	public void connect(){
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("item",item));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/pizza.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try
		{	
			c=1;
			
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			Log.e("Fail 3", "i m here");
			LinearLayout sc=(LinearLayout)findViewById(R.id.scrol);
			sc.removeAllViews();
			int width = sc.getWidth();
			int height = sc.getHeight();
			String[] n =new String[4];
			TableLayout firstline =new TableLayout(Order.this);
			firstline.setPadding(0, 0, 0, 0);
			firstline.setId(10000);
			TableLayout.LayoutParams params2 = new TableLayout.LayoutParams(width,height);
			sc.addView(firstline);
			
			TableRow tableline = new TableRow(Order.this);
			TableRow.LayoutParams params1 = new TableRow.LayoutParams(width,height);
			firstline.addView(tableline);
			
			TextView name1  = new TextView(Order.this);
			name1.setText("Name");
			name1.setPadding(0, 0, 0, 0);
			tableline.addView(name1);
			
			TextView small  = new TextView(Order.this);
			small.setText("Small");
			small.setPadding(0, 0, 0, 0);
			tableline.addView(small);
			
			TextView Qty1  = new TextView(Order.this);
			Qty1.setText("Qty");
			Qty1.setPadding(0, 0, 50, 0);
			tableline.addView(Qty1);
			
			TextView medium  = new TextView(Order.this);
			medium.setText("Medium");
			medium.setPadding(30, 0, 0, 0);
			tableline.addView(medium);
			
			TextView Qty2  = new TextView(Order.this);
			Qty2.setText("Qty");
			Qty2.setPadding(0, 0, 50, 0);
			tableline.addView(Qty2);
			
			TextView large = new TextView(Order.this);
			large.setText("Large");
			large.setPadding(30, 0, 0, 0);
			tableline.addView(large);
			
			TextView Qty3  = new TextView(Order.this);
			Qty3.setText("Qty");
			Qty3.setPadding(0, 0, 50, 0);
			tableline.addView(Qty3);

			TextView description1 = new TextView(Order.this);
			description1.setText("Description");
			description1.setPadding(30, 0, 0, 0);
			tableline.addView(description1);
			
			
			int j=0,f;
			for(int i=0;i<jArray.length();i++)
			{
				f=0;
				JSONObject json_data =  jArray.getJSONObject(i);
				Name = json_data.getString("cat2");
				for(int k=0;k<=j;k++){
					if(Name.equals(n[k]))
					{
						f=1;
						break;
					}
				}
				if(f!=1){
					
				n[j]=Name;
				Log.e("Fail 3", "i m here inserting"+jArray.length());
				j++;
				}
			
			}
			for(int l=0;l<j;l++){
						TableRow tr =new TableRow(Order.this);
						firstline.addView(tr);
						TextView tv = new TextView(Order.this);
						tv.setText(n[l]);
						tr.addView(tv);
						for(int i=0;i<jArray.length();i++){
						  JSONObject json_data =  jArray.getJSONObject(i);
						  Log.e("Fail 3", "i m here2");
						  Id = json_data.getString("Id");
						  Name = json_data.getString("Name");
						  Cat1 = json_data.getString("cat1");
						  Cat2 = json_data.getString("cat2");
						  Price1 = json_data.getString("price1");
						  Price3 = json_data.getString("price3");
						  Price2 = json_data.getString("price2");
						  description = json_data.getString("Description");
						    if(Cat2.equals(n[l])){
							  	TableRow tr1 = new TableRow(Order.this);
							  	firstline.addView(tr1);
							  	
							  	/*	int loader1 = R.drawable.pizza17;
							  	ImageView image = new ImageView(Order.this);
							  	 String image_url1 = "http://10.0.2.2/"+Cat1+"/"+i+".png";
							  	 Log.e("image",image_url1);
							  	ImageLoader imgLoader1 = new ImageLoader(getApplicationContext());
							    imgLoader1.DisplayImage(image_url1, loader1, image);
							    Log.e("image","i m here");
							  	image.setPadding(0, 0, 0, 0);
							  	tr1.addView(image);
							  	*/
							  	TextView name = new TextView(Order.this);
							  	name.setText(Name);
							  	name.setPadding(0, 0, 0, 0);
							  	tr1.addView(name);
							  	
							  		
							  	
							  	
							  	CheckBox price1 = new CheckBox(Order.this);
							  	price1.setText(Price1);
							  	price1.setHint(Name);
							  	price1.setId(c);
							  	price1.setPadding(30, 0, 0, 0);
							  	tr1.addView(price1);
							
							  	c++;
							  	
							  	EditText qty1= new EditText(Order.this);
							  	qty1.setId(c);
							  	qty1.setText("1");
							  	qty1.setPadding(0, 0, 50, 0);
							  	tr1.addView(qty1);
						
								c++;
							  	
							  	
							  	
							  	CheckBox price2 = new CheckBox(Order.this);
							  	price2.setText(Price2);
							  	price2.setPadding(30, 0, 0, 0);
							  	price2.setId(c);
							  	price2.setHint(Name);
							  	tr1.addView(price2);
							  
							  	c++;
							  	
							 	EditText qty2= new EditText(Order.this);
							  	qty2.setId(c);
							  	qty2.setText("1");
							  	qty2.setPadding(0,0,50,0);
							  	tr1.addView(qty2);
							
							  	c++;
							  	
							  	
							  	CheckBox price3 = new CheckBox(Order.this);
							  	price3.setText(Price3);
							  	price3.setPadding(30, 0, 0, 0);
							  	price3.setId(c);
							  	price3.setHint(Name);
							  	tr1.addView(price3);
							  	
							  	c++;
							  
							 	EditText qty3 = new EditText(Order.this);
							  	qty3.setId(c);
							  	qty3.setText("1");
							  	qty3.setPadding(0, 0, 50, 0);
							  	tr1.addView(qty3);
							  	
							  	c++;
						
							  	TextView des = new TextView(Order.this);
							  	des.setText(description);
								des.setPadding(30, 0, 0, 0);
							  	tr1.addView(des);
							  
						  		}
								
						}
			}
			
		
		}
		catch(Exception e)
		{
	            Log.e("Fail 3", e.toString());
		}
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int t=1; 
		double p,n;;
		Intent i;
		
	  int id = arg0.getId();
	if (id == R.id.bill) {
		for(t=1;t<=c;t+=2){
			  try{
	  			CheckBox ch =(CheckBox)findViewById(t);
	  			Log.e("onclick", "before check");
	  			if(ch.isChecked()){
	  				Log.e("onclick", "after check");
	  			EditText ed = (EditText)findViewById(t+1);
	  			String stringt=ch.getText().toString();
	  			String s=ch.getHint().toString();
	  			String edt=ed.getText().toString();
	  			p=Double.parseDouble(stringt);
	  			n=Double.parseDouble(edt);
	  			cost=p*n;
	  			totalcost+=cost;
	  			selctitem=selctitem+";"+s+","+stringt+","+edt+","+cost;
	  			order=order+"\n"+s+"\t"+stringt+"\t"+edt+"\t"+cost+"";
	  			bill1=bill1+"\n"+s+"\t\t\t"+stringt+"\t\t\t"+edt+"\t\t\t\t"+cost+"\t";
	  			Log.e("onclick", "after calculation");
	  			}
	  		}
			  catch(Exception e)
			  {
				  Log.e("onclick", "something wrong");
			  }
			  setorder.setText(bill1);
			  stotal =String.valueOf(totalcost);
				total.setText(stotal);
	  		}
	} else if (id == R.id.side) {
		if(iid == 0){
			 double s=0;
			 
			  order = "";
			  bill1 = "";
			  stotal = String.valueOf(s);
			  selctitem ="";
		  }
		  else{
		  stotal =String.valueOf(totalcost);
			total.setText(stotal);
		  }
		Log.e("Intent", "error before Intent");
		i = new Intent(Order.this,SideOrder.class);
		i.putExtra("order", order);
		i.putExtra("bill", bill1);
		i.putExtra("stotal",stotal);
		i.putExtra("id",id1);
		i.putExtra("name", name2);
		i.putExtra("selctitem", selctitem);
		Log.e("Intent", "error after Intent");
		startActivity(i);
	} else if (id == R.id.sub) {
		i = new Intent(Order.this,Bill.class);
		i.putExtra("order", order);
		i.putExtra("bill", bill1);
		i.putExtra("totalcost",stotal);
		i.putExtra("id",id1);
		i.putExtra("name", name2);
		i.putExtra("selctitem", selctitem);
		startActivity(i);
	} else if (id == 2000) {
		i=new Intent(Order.this,Login.class);
		startActivity(i);
	} else if (id == 2001) {
		i=new Intent(Order.this,Registration.class);
		startActivity(i);
	} else if (id == R.id.home) {
		i = new Intent(Order.this,MainActivity.class);
		startActivity(i);
	} else if (id == R.id.contact) {
		i= new Intent(Order.this,ContactUs.class);
		startActivity(i);
	} else if (id == R.id.about) {
		i= new Intent(Order.this,About.class);
		startActivity(i);
	}
	else if(id == R.id.loc){
		i = new Intent(Order.this,Location.class);
		startActivity(i);
	}
		
	}

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		 Log.e("select", "before select");
		int pos = sp.getSelectedItemPosition();
		switch(pos){
		case 0 :
			item="Veg";
			break;
		case 1:
			item="Non-Veg";
			break;
			     
		}
		Log.e("select" ,"before connect");
		connect();
		 Log.e("select" ,"after connect");
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}
}
