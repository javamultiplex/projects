package com.btechProject.pizzaapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
public class About extends Activity implements OnClickListener {
	
	Button contact,home;
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about); 
        contact=(Button)findViewById(R.id.button2);
        home=(Button)findViewById(R.id.button1);
        
        contact.setOnClickListener(this);
        home.setOnClickListener(this);
        
    	
    	}
	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.button2) {
			Intent i=new Intent(About.this,ContactUs.class);
			startActivity(i);
		} else if (id == R.id.button1) {
			Intent i1=new Intent(About.this,MainActivity.class);
			startActivity(i1);
		}

	
		
		 
	}
	
}
