package com.btechProject.pizzaapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.android.gms.maps.GoogleMap;
import android.support.v4.app.FragmentActivity;  
import com.google.android.gms.maps.SupportMapFragment; 
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
public class Location extends Activity implements OnClickListener{
  
	Spinner state,city;
	Button search,home,contact,about;
	String[] sstate={};
	String[] scity={};
	InputStream is=null;
	String slctstate,line,result,slctcity;
	String address;
	TableLayout linear;	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location);
        
        Log.e("locatoion","wrong 1");
        search = (Button)findViewById(R.id.search);
        linear = (TableLayout)findViewById(R.id.loc);
        home = (Button)findViewById(R.id.home);
        about = (Button)findViewById(R.id.about);
        contact = (Button)findViewById(R.id.contact);
        
        Log.e("locatoion","wrong 2");
        selectstate();
        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(Location.this, android.R.layout.simple_spinner_item, sstate);
		 state = (Spinner)findViewById(R.id.spinstate);
		 state.setAdapter(adapter2);
		 state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		    	int pos=10;
		 		  try{
		 			  Log.e("state values","selstate");
		 			  pos = state.getSelectedItemPosition();
		 			  selectcity(sstate[pos]);
		 			  Log.e("state values","selstate1"+pos);
		 			  slctstate = sstate[pos];
		 		  }
		 		  catch(Exception e){
		 			  Log.e("error", e.toString()+"    "+pos);
		 		  }
					
		    }
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}});
		 Log.e("locatoion","wrong 3");
        search.setOnClickListener(this);
        about.setOnClickListener(this);
        contact.setOnClickListener(this);
        home.setOnClickListener(this);
        Log.e("locatoion","wrong 4");
	}
	
	
	
	public void selectstate(){
		Log.e("Fail sending", "before connection");
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/state.php");
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
			Log.e("Fail sending", "aftr connection");
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			sstate =new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				sstate[i]=json_data.getString("state");
				Log.e("state values",sstate[i]);
			}
		}
		catch(Exception e )
		{
			Log.e("fail json array state", "state is wrong");
		}
	}
	
	
	

	public void selectcity(String state){
		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("state",state));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/city.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			scity=new String[jArray.length()];
			for(int i=0;i<jArray.length();i++)
			{
				JSONObject json_data =  jArray.getJSONObject(i);
				scity[i]=json_data.getString("city");
				Log.e("state values",scity[i]);
			}
			ArrayAdapter<String> adapter1= new ArrayAdapter<String>(Location.this, android.R.layout.simple_spinner_item, scity);
			 city = (Spinner)findViewById(R.id.spincity);
			 city.setAdapter(adapter1);
			 city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
		 		    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
		 		    	int pos=10;
				 		  try{
				 			  Log.e("city values","selcity");
				 			  pos = city.getSelectedItemPosition();
				 			
				 			  Log.e("city values","selcity1"+pos);
				 			  slctcity = scity[pos];
				 		  }
				 		  catch(Exception e){
				 			  Log.e("error", e.toString()+"    "+pos);
				 		  }
							
		 		    }
		 		   @Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}});

		}
		catch(Exception e){
			Log.e("fail json array city", "city is wrong");
		}
	}
	
	
	public void selectaddress(String city)
	{
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("city",city));
			
		
		try{
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://www.mypolo.cu.cc/address.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			//System.out.println("Response Code : " 
	               // + response.getStatusLine().getStatusCode());

			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		
			
		}
		catch(Exception e){
			Log.e("Fail 1",e.toString());
			Toast.makeText(getApplicationContext(),"Invalid IP Address", Toast.LENGTH_LONG).show();
		}
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
			StringBuilder sb= new StringBuilder();
			while((line = reader.readLine())!=null)
			{
				sb.append(line+"\n");
			}
			is.close();
			result=sb.toString();
		}
		catch(Exception e){
			Log.e("fail 2", "connection success "+e.toString());
		}
		try{
			JSONArray jArray= new JSONArray(result);
			String re = jArray.getString(jArray.length()-1);
			
			for(int i=0;i<jArray.length();i++){
				linear.removeAllViewsInLayout();
				JSONObject json_data =  jArray.getJSONObject(i);
				address = json_data.getString("address");
				TableRow tr = new TableRow(Location.this);
				linear.addView(tr);
				TextView tv = new TextView(Location.this);
				tv.setText(address);
				tr.addView(tv);
			}
		}catch(Exception e)
		{
			Log.e("location ",e.toString());
		}
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent i;
		switch(arg0.getId())
		{
		
		case R.id.search:
			selectaddress(slctcity);
			break;
			
		case R.id.about:
			i = new Intent(Location.this,About.class);
			startActivity(i);
			break;
			
		case R.id.home: 
			i = new Intent(Location.this,MainActivity.class);
			startActivity(i);
			break;
		case R.id.contact:
			i = new Intent(Location.this,ContactUs.class);
			startActivity(i);
			break;
		}
	}
 
}

