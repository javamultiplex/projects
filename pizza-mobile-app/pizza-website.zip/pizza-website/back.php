<?php
header('Location:http://localhost/pizza%20website/ordery.php');
?>
