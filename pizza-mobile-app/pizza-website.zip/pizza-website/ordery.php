<!doctype html>
<html>
<head>
<style>
body
{
background:url('a.jpg');
}
h2
{
color:black;
}
fieldset
{
margin-top:40px;
padding:40px;
margin-bottom:60px;
}
input[type=submit] {
    width: 10em;  height: 3em;
	moz-appearance: button;
    -moz-binding: none;
    -moz-box-sizing: border-box;
    -moz-user-select: none;
    background-color: buttonface;
    border: 2px outset buttonface;
    color: buttontext;
    cursor: default;
    font: -moz-button;
    line-height: normal;
    padding: 0 6px;
    text-align: center;
    text-shadow: none;
    white-space: pre;
	ackground: #f4f4f4;
}
</style>
<title>Online Orders</title>
<meta name="author" content="Rohit Agarwal"/>
<meta name="keyword" content="pizza"/>
</head>
<body >
<center><h1 style="font-family:Mongolian Baiti;font-size:50px;color:blue;">Pizza Online Orders</h1></center>
<img src="veg/3.jpg" style="padding:20px;margin-left:170px;"/>
<img src="veg/2.jpg" style="padding:20px;"/>
<?php
ob_start();
session_start();
function loggedin()
{
	if((isset($_SESSION['id'])) && (!empty($_SESSION['id'])))
	{
		return true;
	}
}
$con=mysql_connect("localhost","root");
if(!$con)
{
	echo 'connection error';
}
else
{
	mysql_select_db('pizzadb');
	if(!loggedin())
	{
		$adminid=$_POST['admin'];
		$pass=$_POST['pass'];
		$query="SELECT * FROM admin_register WHERE id='$adminid' AND Password='$pass'";
		$result=mysql_query($query);
		$num_rows=mysql_num_rows($result);
		if(!$num_rows)
		{
			die('<center><h2>You are not registered,Please Register yourself <a href="register.html">Register Here</a> </h2></center>');
		}
		$row=mysql_fetch_array($result);
		$_SESSION['id']=$row['id'];
		$_SESSION['pass']=$row['Password'];
		$_SESSION['Name']=$row['Name'];
		$_SESSION['Picture']=$row['Picture'];
		$name=$row['Name'];
		$pic=$row['Picture'];
	}
	else
	{
		$adminid=$_SESSION['id'];
		$name=$_SESSION['Name'];
		$pic=$_SESSION['Picture'];
	}
	echo "<img src='upload/$pic' height='200px' width='200px' alt='missing' style='float:left;'/>".'<br/>';
	echo '<b>'."<h3 style='clear:both;'>".'Hello      '.$name.'</h3>'.'</b>';
}
if(loggedin())
{
	echo '<a href="logout.php" style="float:right;text-decoration:none;margin-top:-280px;"><b><font size="8"><img src="logout.png"/></font></b></a>';
}
mysql_close($con);
?>
<fieldset>
<legend style="font-family:Lucida Calligraphy;font-size:25px;">Check Orders</legend>
<form method="GET" action="placedorder.php">

<center><input type="submit" name="submit" value="Check Orders" /></center>
</form>
</fieldset>

<img src="Beverages/5.jpg" style="padding:10px;margin-left:20px;"/>
<img src="Beverages/6.png" style="padding:10px;"/>
<img src="Beverages/7.jpg" style="padding:10px;"/>
<img src="veg/3.jpg" style="padding:10px;"/>

</form>
</body>
</html>