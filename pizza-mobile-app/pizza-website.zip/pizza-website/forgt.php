<!doctype html>
<html>
<head>
<style>
body
{
background:url('a.jpg');
}

</style>
</head>
<body>
<?php
$con=mysql_connect("localhost","root");
if(!$con)
{
echo 'connection error';
}
else
{
mysql_select_db('pizzadb');
$email=$_POST['email'];
$query="SELECT `Password` FROM admin_register WHERE `Email`='$email'";
$result=mysql_query($query);
$pass=mysql_result($result,0,'Password');
}
mysql_close($con);
?>
<script>
alert('Your Password is <?php echo $pass ?>');
</script>
<center><h2 style="color:black;">Now Login Here <a href="index.html">Login</a></h2></center>
</body>
</html>