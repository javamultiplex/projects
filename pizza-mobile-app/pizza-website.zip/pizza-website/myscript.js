
		function checkagain()
		{
			var name=document.pizza.name.value;
			var email=document.pizza.email.value;
			var pass=document.pizza.pass.value;
			var confpass=document.pizza.confpass.value;
			var contact=document.pizza.contact.value;
			var h=email.indexOf('@');
			var j=email.lastIndexOf('.');
			var k=contact.length;
			if(name==null || name=="")
			{
				document.getElementById("1").innerHTML="Enter your name";
				return false;
			}
			if(email==null || email=="")
			{
				document.getElementById("1").innerHTML="Enter your Email Id";
				return false;
			}
			else if(h>j || h<1)
			{
				document.getElementById("1").innerHTML="Your email id is wrong";
				return false;	
			}
			if(pass==null || pass=="")
			{
				
				document.getElementById("1").innerHTML="Enter your password";
				return false;	
			}
			if(confpass!=pass)
			{
				document.getElementById("1").innerHTML="Both Passwords Should be same";
				return false;
			}	
            if(contact==null || contact=="")
			{
				document.getElementById("1").innerHTML="Enter your Contact Number";
				return false;
			}	
			if(k>13)
			{
			    document.getElementById("1").innerHTML="Contact Number Should Not Be Greater Than 13 Digits";
				return false;
			}
		}