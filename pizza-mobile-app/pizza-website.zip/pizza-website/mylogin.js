function check()
{
var logid=document.login.admin.value;
var pass=document.login.pass.value;
if(logid==null || logid=="")
	{
				document.getElementById("1").innerHTML="Enter your Admin Id";
				return false;
	}
if(pass==null || pass=="")
	{
				document.getElementById("1").innerHTML="Enter Password";
				return false;
	}

}