function checky()
{
var email=document.forget.email.value;
var h=email.indexOf('@');
var j=email.lastIndexOf('.');
if(email==null || email=="")
	{
				document.getElementById("1").innerHTML="Enter your Email Id";
				return false;
	}
else if(h>j || h<1)
	{
				document.getElementById("1").innerHTML="Your email id is wrong";
				return false;	
	}
}