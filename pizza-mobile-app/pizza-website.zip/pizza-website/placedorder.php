<!doctype html>
<html>
<head>
<title>
Placed Orders
</title>
<meta http-equiv="refresh" content="60"/>
<style>
body
{
background:url('a.jpg');
}
th
{
font-family:Copperplate Gothic Light;
}
td
{
font-family:Copperplate Gothic Light;
}

</style>
</head>
<body>
<?php echo '<a href="back.php" style="float:left;text-decoration:none;"><b><font size="8"><img src="b.png"/></font></b></a>'; ?>
<?php echo '<a href="logout.php" style="float:right;text-decoration:none;"><b><font size="8"><img src="logout.png"/></font></b></a>'; ?>
<center><h1 style="font-family:Mongolian Baiti;font-size:50px;color:blue;">Placed Orders</h1></center>

<?php

$con=mysql_connect("localhost","root");
if(!$con)
{
echo 'connection error';
}
else
{
mysql_select_db('pizzadb');

$query="SELECT * FROM order_placed";
$result=mysql_query($query);
echo "<table border=1 cellpadding=5 cellspacing=5><tr>
<th>ORDER_ID</th>
<th>CUSTOMER_ID</th>
<th>ITEM_LIST</th>
<th>TIME</th>
<th>TOTAL COST</th>
<th>TYPE</th>
<th>LOCATION</th>
<th>CITY</th>
<th>STATE</th>
<th>ADDRESS</th>
</tr>";
while($row=mysql_fetch_array($result))
{
if($row['city']==NULL)
{
$quey="SELECT * FROM CUSTOMER";
$RR=mysql_query($quey);
$row['location']=mysql_result($RR,0,'location');
$row['city']=mysql_result($RR,0,'city');
$row['state']=mysql_result($RR,0,'state');
$row['address']=mysql_result($RR,0,'address');

}
echo "<tr>";
echo "<td>".$row['order_id']."</td>";
echo "<td>".$row['customer_id']."</td>";
echo "<td>".$row['item_list']."</td>";
echo "<td>".$row['time']."</td>";
echo "<td>".$row['total_cost']."</td>";
echo "<td>".$row['type']."</td>";
echo "<td>".$row['location']."</td>";
echo "<td>".$row['city']."</td>";
echo "<td>".$row['state']."</td>";
echo "<td>".$row['address']."</td>";
echo "</tr>";
}
echo "</table>";

}
?>
</body>
</html>