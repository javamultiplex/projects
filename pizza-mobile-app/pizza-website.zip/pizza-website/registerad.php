<HTML>
<head>
<title>
User Details
</title>
<style>
body
{
background:url('a.jpg');

}
h1
{
color:blue;
}
h2
{
color:RED;
}
</style>
</head>
<body>
<?php

$con=mysql_connect("localhost","root");
if(!$con)
	echo 'Connection Error';
else
	{
	 mysql_select_db('pizzadb');
	 $name=$_POST['name'];
	 $pass=$_POST['pass'];
	 $email=$_POST['email'];
	 $contact=$_POST['contact'];
	 $picname=$_FILES['pic']['name'];
	 $tmp=$_FILES['pic']['tmp_name'];
	 if(isset($picname))
	 {
	 if(!empty($picname))
	 {
	 $location='upload/';
	 move_uploaded_file($tmp,$location.$picname);
	 }
	 }
	 $result=mysql_query("INSERT INTO admin_register VALUES(NULL,'$name','$pass','$email','$contact','$picname')") or die(mysql_error());
	 
	 $query="SELECT * FROM admin_register where `Email`='$email'";
	 if($result1=mysql_query($query))
	 {
	 $query_num_rows=mysql_num_rows($result1);
	 $name1=mysql_result($result1,0,'Name');
	 $email1=mysql_result($result1,0,'Email');
	 $contact1=mysql_result($result1,0,'Contact');
	 $user_id = mysql_result($result1,0,'id');
	 if($query_num_rows==1)
	 {
	 echo '<center>'.'<b>'.'<h1>'.'Congratulations You are Succuessfully Registerd'.'</h1>'.'</b>'.'</center>';
	 echo '<center>'."<img src='upload/$picname' height='150px' width='150px' alt='missing'/>".'</center>';
	 echo '<center>'.'<h2>'.$name.' Your Admin Id is '.$user_id.' Please Note down this Admin id becuase  this is required at the time of login'.'</h2>'.'</center>'; 
	 
	 
	 }
	 else
	 {
	 echo '<center>'.'<h1>'.'Email id already exist'.'</h2>'.'</center>';
	 mysql_query("DELETE FROM admin_register where `Email`='$email' AND `CONTACT`='$contact'");
	 echo '<center>'.'<h2>'.'Please Register with another Email id   '.'<a href="register.html">Register Here</a>'.'</h2>'.'</center>';
	 die();
	 }
	 
	}
	}
mysql_close($con);
?>
<center><table border="1" cellspacing="2" cellpadding="2">
<caption><font face="Arial, Helvetica, sans-serif"><b>Admin Details</b></font></caption>
	 <tr>
	 <th><font face="Arial, Helvetica, sans-serif">Name</font></th>
	 <td><font face="Arial, Helvetica, sans-serif"><?php echo $name1; ?></font></td>
	 </tr>
	 <tr>
	 <th><font face="Arial, Helvetica, sans-serif">Email</font></th>
	 <td><font face="Arial, Helvetica, sans-serif"><?php echo $email1; ?></font></td>
	 </tr>
	 <tr>
	 <th><font face="Arial, Helvetica, sans-serif">Contact</font></th>
	 <td><font face="Arial, Helvetica, sans-serif"><?php echo $contact1; ?></font></td>
	 </tr>
	 </table></center>
	 
<center><h2 style="color:black;">Now Login Here <a href="index.html">Login</a></h2></center>
</body>
</HTML>




