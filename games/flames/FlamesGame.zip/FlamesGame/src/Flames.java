
public interface Flames {

	static String flames="FLAMES";
}
