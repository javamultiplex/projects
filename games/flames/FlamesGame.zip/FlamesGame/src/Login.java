import java.sql.SQLException;
import java.util.Scanner;

public class Login {
	public static Scanner sc = new Scanner(System.in);
	public int userid = 0;
	public char choice = '\u0000';
	public char playOrNot = '\u0000';
	public String password = null;
	public boolean result = false;

	public void doLogin() throws SQLException {
		DatabaseQueries dq = new DatabaseQueries();
		System.out.println("Enter login id:>");
		userid = sc.nextInt();
		System.out.println("Enter password:>");
		password = sc.next();
		result = dq.validateUser(userid,password);
		if (result) {
			System.out.println("Now you can play flames with anyone");
			System.out.println("Are you ready to play?(y/n)");
			playOrNot=sc.next().charAt(0);
			if(playOrNot=='y' || playOrNot=='Y')
			{
				GetDetails fd=new GetDetails();
				fd.getDetails(userid);
				
			}
			else
			{
				System.out.println("Ohk thanks for login,you will automatically logout in 5 mins");
				System.exit(0);
			}
			
		} else {
			System.out.println("Your details are not correct");
			System.out.println("Do you want to try again?(y/n)");
			choice = sc.next().charAt(0);
			if (choice == 'y' || choice == 'Y') {
				doLogin();

			} else {
				System.out.println("Ohk, Have a nice day");
			}
		}

	}

}
