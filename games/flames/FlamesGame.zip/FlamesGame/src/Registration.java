import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Registration {

	public static Scanner sc = new Scanner(System.in);
	String name = null;
	String password = null;
	boolean result1 = false;
	boolean result2 = false;
	int queryResult=0;
	char choice='\u0000';
    int id=0;
	public void doRegisteration() throws SQLException {
		Validations val = new Validations();
		DatabaseQueries dq = new DatabaseQueries();
		System.out.println("***********Guidlines for name*********");
		System.out.println("\n1)Only Alphabets are acceptable. \n2)Minimum name length should be 5");
		System.out.println("***********Guidlines for password*********");
		System.out.println("\n1)Minimum password length should be 6. \n2)Atleast one special character(#,$,@) \n3)Password should be alphanumeric");
		System.out.println("Enter Your Full Name:>");
		name = sc.nextLine();
		System.out.println("Enter password:>");
		password = sc.next();
		result1 = val.validateName(name);
		result2 = val.validatePassword(password);
		String newName=name.toLowerCase();	 
		if (result1 && result2) {
			queryResult = dq.insertData(newName,password);
			if(queryResult>0)
			{
				System.out.println("You are successfully Registered");
			    id=dq.getUserid(newName,password);	
			    System.out.println("Your login id is:> "+id);
			    System.out.println("Please note down your login id becuase it will be useful at the time of login,Now login");
				Login lg=new Login();
				lg.doLogin();
			}
		} else {
			System.out.println("Either your username or password doesn't meet guidlines.");
			System.out.println("Do you want to try again?(y/n)");
			choice=sc.next().charAt(0);
			if(choice=='y' || choice=='Y')
			{
				doRegisteration();
			}
			else
			{
				System.out.println("Ohk,have a nice day");
			}
		}
	}

}
