import java.sql.SQLException;
import java.util.Scanner;

public class GetDetails {

	public static Scanner sc = new Scanner(System.in);
	String name = null;
	boolean result = false;
	String userName = null;
	String newName = null;

	public void getDetails(int id) throws SQLException {
		DatabaseQueries dq = new DatabaseQueries();
		Validations v = new Validations();
		RemoveDuplicates fd = new RemoveDuplicates();
		System.out.println("***********Guidlines for name*********");
		System.out
				.println("\n1)Only Alphabets are acceptable. \n2)Minimum name length should be 5");
		System.out.println("Enter anther person full name:>");
		name = sc.nextLine();
		result = v.validateName(name);
		if (result) {
			newName = name.toLowerCase();
			userName = dq.getName(id);
			fd.removeDuplicates(newName, userName, id);

		} else {
			System.out
					.println("Another person name doesn't fullfill guidlines");
			System.out.println("Now try again.....");
			getDetails(id);

		}
	}
}
