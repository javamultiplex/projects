import java.sql.SQLException;
import java.util.Scanner;
public class FlamesController {

	public static Scanner sc=new Scanner(System.in);
	public static int choice=0;
	public static void main(String[] args) throws SQLException {		
	
		System.out.println("****************Welcome to FLAMES-The Game Of Love**********************");
		System.out.println("1.Registration");
		System.out.println("2.Login");
		System.out.println("Enter your choice:>");
		choice=sc.nextInt();
		switch(choice)
		{
		 case 1:
			 Registration res=new Registration();
			 res.doRegisteration();
			 break;
		 case 2:
			 Login log=new Login();
			 log.doLogin();
			 break;
		 default:
			 System.out.println("Your choice is wrong");
	    }
		
	}
}
