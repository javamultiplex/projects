import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class RemoveDuplicates implements Flames {

	String temp1 = null;
	String temp2 = null;
	String sub=null;
	String sub1="";
	String relation=null;
	char choice='\u0000';
	StringBuffer output=null;
	ArrayList<Character> list1 = new ArrayList<Character>();
	ArrayList<Character> tempList1 = new ArrayList<Character>();
	ArrayList<Character> list2 = new ArrayList<Character>();
	ArrayList<Character> tempList2 = new ArrayList<Character>();
	Scanner sc=new Scanner(System.in);
	int sizeList1 = 0;
	int sizeList2 = 0;
	int finalSize = 0;
    int limit=0;
    int length=0;
    char ch='\u0000';
    int row=0;
	public void removeDuplicates(String name, String userName, int id) throws SQLException {
		DatabaseQueries dq=new DatabaseQueries();
		int i = 0;
		temp1 = name.replaceAll("\\s", "");
		temp2 = userName.replaceAll("\\s", "");
		char[] ch1 = new char[temp1.length()];
		char[] ch2 = new char[temp2.length()];
		ch1 = temp1.toCharArray();
		ch2 = temp2.toCharArray();
		sizeList1 = ch1.length;
		sizeList2 = ch2.length;
		for (i = 0; i < sizeList1; i++) {
			list1.add(ch1[i]);
		}
		tempList1.addAll(list1);
		for (i = 0; i < sizeList2; i++) {
			list2.add(ch2[i]);
		}
		tempList2.addAll(list2);
		for (i = 0; i < sizeList1; i++) {
			if (list2.contains(list1.get(i))) {
				list2.remove(list1.get(i));
			}
		}
		for (i = 0; i < sizeList2; i++) {
			if (list1.contains(tempList2.get(i))) {
				list1.remove(tempList2.get(i));
			}
		}
		StringBuffer sb = new StringBuffer(flames);
		length = sb.length();
		int count = 0;
		while (sb.length() != 1) {
			finalSize = list1.size() + list2.size();
			
		
						if (finalSize == length) {
										limit=length-1;
										if(limit==length-1)
										{
											limit=0;
										}	
										sb.deleteCharAt(length-1);
										length--;

						} else if (finalSize < length) {
										limit=finalSize-1;
										if(limit==length-1)
										{
											limit=0;
										}	
										sb.deleteCharAt(finalSize-1);
										length--;
						} else if (finalSize > length) {
										count = finalSize-length;
											while (count>length) {
													count = count-length;
											}
										limit=count-1;
										if(limit==length-1)
										{
											limit=0;
										}	
										sb.deleteCharAt(count-1);
										length--;
						}
							
							sub="";
							if(limit>0)
							{
								sub1=sb.substring(0,limit);
								for(i=limit;i<length;i++)
								{
									sub=sub+String.valueOf(sb.charAt(i));
								}
								for(i=0;i<sub1.length();i++)
								{
									sub=sub+String.valueOf(sb.charAt(i));
								}
							  output=new StringBuffer(sub);
							  sb=output;
							}
		  
			
		}
		
		ch=sb.charAt(0);
		switch(ch)
		{
		case 'F':
			relation="Friendship";
			break;
		case 'L':
			relation="Love";
			break;
		case 'A':
			relation="ancestor";
			break;
		case 'M':
			relation="Marriage";
			break;
		case 'E':
			relation="Enemy";
			break;
		case 'S':
			relation="Sibling";
			break;
		}
		System.out.println("Relationship is:> "+relation);
		row=dq.insertRelation(id,name,relation);
		if(row>0)
		{
			System.out.println("Do you want to continue(y/n)");
			choice=sc.next().charAt(0);
			if(choice=='y' || choice=='Y')
			{
				GetDetails gd=new GetDetails();
				gd.getDetails(id);
			}
			else
			{
				dq.getRelations(id);
				System.out.println("Thanks for playing,You will automatically logout with in 5 min");
				System.exit(0);
			}
		}

	}

}
