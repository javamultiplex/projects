import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseQueries {

	int rowcount = 0;
	int id = 0;
	boolean result = false;
	boolean checkRow = false;
	ResultSet rs = null;
	String name = null;
	DatabaseConnectivity dc = new DatabaseConnectivity();
	Statement st = dc.MakeConnection();

	public int insertData(String name, String password) {

		try {

			String str = "insert into register(username,password) values('"
					+ name + "','" + password + "')";
			rowcount = st.executeUpdate(str);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowcount;
	}

	public int getUserid(String name, String password) throws SQLException {

		String str = "select userid from register where username='" + name
				+ "' AND password='" + password + "'";
		rs = st.executeQuery(str);
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}

	public boolean validateUser(int userid,String password) throws SQLException {
		String str = "select * from register where userid=" + userid + " AND password='"+password+"'";
		rs = st.executeQuery(str);
		checkRow = rs.next();
		if (checkRow) {
			result = true;
			System.out.println("Welcome " + rs.getString(2));
		}
		return result;

	}

	public String getName(int userid) throws SQLException {
		String str = "select * from register where userid=" + userid;
		rs = st.executeQuery(str);
		rs.next();
		name = rs.getString(2);
		return name;
	}
	
	public int insertRelation(int id,String name1,String relation)
	{
		try {

			String str = "insert into relationship(userid,anothername,relation) values("
					+ id + ",'"+name1+"','"+relation+"')";
			rowcount = st.executeUpdate(str);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowcount;
	}
	
	public void getRelations(int id) throws SQLException
	{
		System.out.println("Relationship Status of You with another persons:>");
		String str = "select * from relationship where userid=" + id;
		rs = st.executeQuery(str);
		while(rs.next())
		{
			System.out.println(rs.getString("anothername")+": >" +rs.getString("relation"));
			
		}
	}

}
