
public class Validations {

	static String patternName=null;
	static boolean flag1=false;
	static boolean flag2=false;
	int digit=0;
	int upper=0;
	int lower=0;
	int special=0;
	public boolean validatePassword(String password)
	{
	
		int length=password.length();
		for(int i=0;i<length;i++)
		{
			if(Character.isDigit(password.charAt(i)))
			{
				digit++;
			}
			if(Character.isUpperCase(password.charAt(i)))
			{
				upper++;
			}
			if(Character.isLowerCase(password.charAt(i)))
			{
				lower++;
			}
			if(password.charAt(i)=='@' || password.charAt(i)=='$' || password.charAt(i)=='#')
			{
				special++;
			}
		}
		if(digit>0 && special>0 && (lower+upper)>0 && password.length()>=6)
		{
			flag2=true;
		}
		return flag2;
	}
	public boolean validateName(String name)
	{
		patternName="[a-zA-Z ]+";
		if(name.matches(patternName) && name.length()>=5)
		{
			flag1=true;
		}
		
		return flag1;
		
	}
}
