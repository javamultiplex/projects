import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DatabaseConnectivity {

	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String driver="oracle.jdbc.OracleDriver";
	String userName="system";
	String passWord="root"; 
	Connection con=null;
	Statement st=null;
	public Statement MakeConnection()
	{
		try {
			Class.forName(driver);
		    con=DriverManager.getConnection(url,userName,passWord);
		    st=con.createStatement();
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return st;
	}

}
