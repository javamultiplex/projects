function sendTestInfoUpdation(test)
{
	var url="UpdateTestDetailsView?id="+test;
	xhtp=handle();
	xhtp.onreadystatechange=getTestdetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
	
}

function getTestdetailsInfo()
{
	removetestdetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("testviewslot").innerHTML=xhtp.responseText;
	}
	
}