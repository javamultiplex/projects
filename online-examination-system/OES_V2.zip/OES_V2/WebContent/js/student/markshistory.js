$(document).ready(function(){
	$("div").click(function(){
		$("#test"+this.id).toggle();
	});
});