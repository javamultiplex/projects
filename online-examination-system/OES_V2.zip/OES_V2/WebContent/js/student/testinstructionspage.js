function loadTest(value)
	{
		window.open("PreTest?Test="+value, "_blank","width="+window.outerWidth+",height="+window.outerHeight+",scrollbars=yes");
	}