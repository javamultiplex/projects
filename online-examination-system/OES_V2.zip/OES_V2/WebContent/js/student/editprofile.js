function editProfileValidator()
{
	var firstName=document.getElementById("firstName").value;
	var lastName=document.getElementById("lastName").value;
	var email=document.getElementById("email").value;
	var phone=document.getElementById("phone").value;
	var emailRegx=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var nameRegx=/^[a-zA-Z]+$/;
	var phoneRegx=/^[1-9]{1}[0-9]{9}$/;
	var result1=true;
	var result2=true;
	var result3=true;
	var result4=true;
	if(firstName==null || firstName=="" || !(firstName.match(nameRegx)))
	{
		document.getElementById("firstNameError").innerHTML="<b>First name is mandatory and should be alphabetic.</b>";
		result1=false;
	}
	
	if(lastName==null || lastName=="" || !(lastName.match(nameRegx)))
	{
		document.getElementById("lastNameError").innerHTML="<b>Last name is mandatory and should be alphabetic.</b>";
		result2=false;
	}
	
	if(phone==null || phone=="" || isNaN(phone) || !(phone.match(phoneRegx)))
	{
		document.getElementById("mobileError").innerHTML="<b>Phone number is mandatory and should be 10 digit long.</b>";
		result3=false;
	}
	
	if(email==null || email=="" || !(email.match(emailRegx)))
	{
		document.getElementById("emailError").innerHTML="<b>Email is mandatory.</b>";
		result4=false;
	}
	
	if(result1==false || result2==false || result3==false || result4==false)
		{
			return false;
		}
}