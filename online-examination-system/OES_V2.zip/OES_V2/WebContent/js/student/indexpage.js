function forgetPassword()
	{
		var id=prompt("Enter Your Roll Number");
		location.href=decodeURI("PreForgetPassword?id="+id);
	}

function loginValidation()
{
	var enrollmentId=document.getElementById("name").value;
	var password=document.getElementById("password").value;
	var result1=true;
	var result2=true;
	if(enrollmentId==null || enrollmentId=="" || isNaN(enrollmentId))
		{
			document.getElementById("nameError").style.display="block";
			document.getElementById("nameError").innerHTML="<b>Roll number is mandatory and should be numerical.</b>";
			result1=false;
		}
	if(password==null || password=="")
		{
		document.getElementById("passwordError").style.display="block";
		document.getElementById("passwordError").innerHTML="<b>Password is mandatory.</b>";
			result2=false;
		}
	if(result1==false || result2==false)
		{
			return false;
		}
		
}