function showDetails(id)
	{
		$(document).ready(function(){
			
			$("#testdetails"+id).dialog({
				
			title:"Test Details",
			width:430,
			height:300,
			modal:true
			
			});
			
		});
	}