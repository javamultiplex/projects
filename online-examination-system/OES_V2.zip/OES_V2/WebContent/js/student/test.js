$(document).ready(function(){
	$("div").hide();
	$("#divQuestion1").show();
});
function nextElement(myId)
{
	var id=myId.substring(myId.length-1,myId.length);
	$("#divQuestion"+id).hide();
	id++;
	$("#divQuestion"+id).show(); 
}
function previousElement(myId)
{
	var id=myId.substring(myId.length-1,myId.length);
	$("#divQuestion"+id).hide();
	id--;
	$("#divQuestion"+id).show();
}