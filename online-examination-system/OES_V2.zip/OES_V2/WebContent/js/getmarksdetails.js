function sendTestInfo(test)
{
	var url="GetMarkstDetails?testId="+test;
	xhtp=handle();
	xhtp.onreadystatechange=getMarksInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getMarksInfo()
{
	removemarksdetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("marksviewslot").innerHTML=xhtp.responseText;
	}
}