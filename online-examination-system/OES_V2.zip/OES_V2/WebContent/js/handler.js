var xhtp;
function handle()
{

		if(window.XMLHttpRequest)
		{
			xhtp=new XMLHttpRequest();
		}
		else if(window.ActiveXObject)
		{
			xhtp=new ActiveXObject(Microsoft.XMLHTTP);
		}

		return xhtp;
}