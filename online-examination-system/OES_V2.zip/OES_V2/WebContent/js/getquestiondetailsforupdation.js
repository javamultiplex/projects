function sendQuestionInfoUpdation(question)
{
	var url="UpdateQuestionDetailsView?id="+question;
	xhtp=handle();
	xhtp.onreadystatechange=getQuestionDetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
	
}

function getQuestionDetailsInfo()
{
	removequestiondetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("questionviewslot").innerHTML=xhtp.responseText;
	}
	
}