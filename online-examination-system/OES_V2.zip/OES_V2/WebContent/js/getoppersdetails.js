function sendTestInfo(test)
{
	var url="GetTopperDetailsByTestId?id="+test;
	xhtp=handle();
	xhtp.onreadystatechange=getTopperdetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getTopperdetailsInfo()
{
	removetopperdetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("marksviewslot").innerHTML=xhtp.responseText;
	}
	
}