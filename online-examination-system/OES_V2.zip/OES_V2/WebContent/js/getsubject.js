function sendBranchInfo(branch)
{
	var url="GetSubjectsDetail?branch="+branch;
	xhtp=handle();
	xhtp.onreadystatechange=getSubjectInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
	
}

function getSubjectInfo()
{
	removeAllOptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		z=0;
		 var r1=xhtp.responseXML.documentElement;
         var r2 =r1.getElementsByTagName("subject")[z];
         var key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
         var value=r2.getElementsByTagName("name")[0].childNodes[0].nodeValue;

         while(key!=null && value!=null)
         {
                 addoptions(key,value);
                 z++
                 r2 =r1.getElementsByTagName("subject")[z];
                 key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
                 value=r2.getElementsByTagName("name")[0].childNodes[0].nodeValue;
         }
	
		
	}
	
}
