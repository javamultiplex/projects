 function multiAnswer()
					    {
							var option1=document.getElementById("option1").value;
							var option2=document.getElementById("option2").value;
							var option3=document.getElementById("option3").value;
							var option4=document.getElementById("option4").value;
							document.getElementById("answer1").style.display="inline";
							document.getElementById("answer1").value=option1;
							document.getElementById("answerlabel1").innerHTML=option1;
							document.getElementById("answer2").style.display="inline";
							document.getElementById("answer2").value=option2;
							document.getElementById("answerlabel2").innerHTML=option2;
							document.getElementById("answer3").style.display="inline";
							document.getElementById("answer3").value=option3;
							document.getElementById("answerlabel3").innerHTML=option3;
							document.getElementById("answer4").style.display="inline";
							document.getElementById("answer4").value=option4;
							document.getElementById("answerlabel4").innerHTML=option4;
					    }