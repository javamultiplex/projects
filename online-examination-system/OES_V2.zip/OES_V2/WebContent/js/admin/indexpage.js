function loginValidation()
{
	var enrollmentId=document.getElementById("name").value;
	var password=document.getElementById("password").value;
	var result1=true;
	var result2=true;
	if(enrollmentId==null || enrollmentId=="" || !(enrollmentId.match(/^[a-zA-Z]+$/)))
		{
			document.getElementById("nameError").style.display="block";
			document.getElementById("nameError").innerHTML="<b>Username is mandatory.</b>";
			result1=false;
		}
	if(password==null || password=="")
		{
		document.getElementById("passwordError").style.display="block";
		document.getElementById("passwordError").innerHTML="<b>Password is mandatory.</b>";
			result2=false;
		}
	if(result1==false || result2==false)
		{
			return false;
		}
		
}