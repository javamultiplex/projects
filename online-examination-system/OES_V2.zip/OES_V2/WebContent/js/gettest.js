function sendSubjectInfo(subject)
{
	var url="GetTestDetail?subject="+subject;
	xhtp=handle();
	xhtp.onreadystatechange=getTestInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getTestInfo()
{
	removetestoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		z=0;
		 var r1=xhtp.responseXML.documentElement;
         var r2 =r1.getElementsByTagName("test")[z];
         var key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
         var value=r2.getElementsByTagName("name")[0].childNodes[0].nodeValue;

         while(key!=null && value!=null)
         {
                 addtestoptions(key,value);
                 z++
                 r2 =r1.getElementsByTagName("test")[z];
                 key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
                 value=r2.getElementsByTagName("name")[0].childNodes[0].nodeValue;
         }
	
		
	}
	
}