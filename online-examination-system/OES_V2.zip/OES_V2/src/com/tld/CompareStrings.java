package com.tld;

public class CompareStrings {

	public static boolean equals(String str1,String str2)
	{
		return str1.equalsIgnoreCase(str2);
	}
	
}
