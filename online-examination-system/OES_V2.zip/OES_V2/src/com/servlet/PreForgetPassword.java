package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;
import com.variables.ServletVariables;


@WebServlet("/PreForgetPassword")
public class PreForgetPassword extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    public PreForgetPassword() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Student student=new Student();
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.rd=request.getRequestDispatcher(FORGETPASSWORD);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.status=StudentDB.isValidId(ServletVariables.con, ServletVariables.enrollmentID);
		request.setAttribute(VALIDSTUDENT, ServletVariables.status);
		request.setAttribute(ID, ServletVariables.enrollmentID);
		student.setEnrollment(ServletVariables.enrollmentID);
		ServletVariables.status=StudentDB.isFirstLogin(ServletVariables.con, student);
		request.setAttribute(FIRSTLOGIN, ServletVariables.status);
		ServletVariables.rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
