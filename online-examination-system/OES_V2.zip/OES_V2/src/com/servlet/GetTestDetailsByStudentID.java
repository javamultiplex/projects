package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;

@WebServlet("/admin/GetTestDetailsByStudentID")
public class GetTestDetailsByStudentID extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
   
    public GetTestDetailsByStudentID() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(XML);
		PrintWriter out=response.getWriter();
		Connection con=DBConnection.getConnection();
		int id=Integer.parseInt(request.getParameter("studentId"));
		List<List<String>> myTest=TestDB.getTestDetailsByStudentID(con, id);
		out.print(TESTSSTARTTAG);
			out.print(TESTSTARTTAG);
			out.print("<id>None</id>");
			out.print("<name>None</name>");
			out.print(TESTENDTAG);
			for(List<String> test:myTest)
			{
				out.print(TESTSTARTTAG);
				out.print("<id>"+test.get(0)+"S"+id+"</id>");
				out.print("<name>"+test.get(1)+"</name>");
				out.print(TESTENDTAG);
				
			}
		out.print(TESTSENDTAG);
		out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
