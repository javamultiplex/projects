package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;
import com.utilities.CapitalizeFirstLetter;

/**
 * Servlet implementation class GetTestDetailsByID
 */
@WebServlet("/admin/GetTestDetailsByID")
public class GetTestDetailsByID extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetTestDetailsByID() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		List<String> testList=TestDB.getTestDetails(con, id);
		out.println(TABLESTARTTAGWITHBORDER);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print("Title");
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(CapitalizeFirstLetter.getResultantString(testList.get(0)));
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print("Description");
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(CapitalizeFirstLetter.getResultantString(testList.get(2)));
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print("Type of Question");
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					if(testList.get(4).equals(SINGLE))
						out.print("Single Choice");
					if(testList.get(4).equals(MULTI))
						out.print("Multiple Choice");
					if(testList.get(4).equals(TRUEORFALSE))
						out.print("True/False");
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print("Number of Questions");
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(testList.get(1));
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print("Marks");
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(testList.get(3));
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
		out.println(TABLEENDTTAG);
		out.close();
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
