package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inteface.Constants;
import com.pojo.Test;
import com.variables.ServletVariables;


@WebServlet("/PreTestInstructionsProcess")
public class PreTestInstructionsProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    
    public PreTestInstructionsProcess() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Test test=new Test();
		ServletVariables.session=request.getSession();
		ServletVariables.testDetails=request.getParameter(TEST);
		ServletVariables.testDetailsArray=ServletVariables.testDetails.split(COMMA);
		test.setTestID(Integer.valueOf(ServletVariables.testDetailsArray[0]));
		test.setTitle(ServletVariables.testDetailsArray[1]);
		test.setNoOfQuestions(Integer.valueOf(ServletVariables.testDetailsArray[2]));
		test.setDescription(ServletVariables.testDetailsArray[3]);
		test.setMarks(Integer.valueOf(ServletVariables.testDetailsArray[4]));
		test.setTypeOfQuestion(ServletVariables.testDetailsArray[5]);
		ServletVariables.session.setAttribute(TEST,test);
		ServletVariables.session.setAttribute(TESTDETAILS, ServletVariables.testDetails);
		response.sendRedirect(TESTINSTRUCTIONS);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
