package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.utilities.CapitalizeFirstLetter;
import com.variables.ServletVariables;

@WebServlet("/admin/GetStudentDetailsByID")
public class GetStudentDetailsByID extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
   
    public GetStudentDetailsByID() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.studentDetailsList=StudentDB.getStudentDetailsById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID));
		ServletVariables.out.println(TABLESTARTTAG);
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>First Name</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print(CapitalizeFirstLetter.getResultantString(ServletVariables.studentDetailsList.get(0)));
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>Last Name</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print(CapitalizeFirstLetter.getResultantString(ServletVariables.studentDetailsList.get(1)));
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>Email ID</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print(ServletVariables.studentDetailsList.get(2));
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>Phone Number</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print(ServletVariables.studentDetailsList.get(3));
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>Branch</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print(ServletVariables.studentDetailsList.get(4));
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		ServletVariables.out.print(TABLEENDTTAG);
		
		ServletVariables.out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
