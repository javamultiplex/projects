package com.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.ResultDB;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Test;
import com.variables.ServletVariables;

@WebServlet("/PreMarksHistoryProcess")
public class PreMarksHistoryProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    
    public PreMarksHistoryProcess() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Test testObject=null;
		Map<Test,List<List<String>>> testDetailsWithAttempts=new HashMap<Test,List<List<String>>>();
		ServletVariables.session=request.getSession();
		ServletVariables.enrollmentID=(String) ServletVariables.session.getAttribute(ID);
		ServletVariables.test=TestDB.getTestDetailsByStudentID(ServletVariables.con, Integer.valueOf(ServletVariables.enrollmentID));
		for(List<String> myTest:ServletVariables.test)
		{
			testObject=new Test();
			List<List<String>> testAttempts=null;
			ServletVariables.testId=Integer.valueOf(myTest.get(0));
			ServletVariables.resultId=ResultDB.getResultId(ServletVariables.con,ServletVariables.testId,Integer.valueOf(ServletVariables.enrollmentID));
			testAttempts=ResultDB.getAttempsDetailsBasedOnResultId(ServletVariables.con, ServletVariables.resultId);
			testObject.setTestID(Integer.valueOf(ServletVariables.testId));
			testObject.setTitle(myTest.get(1));
			testObject.setNoOfQuestions(Integer.valueOf(myTest.get(2)));
			testObject.setDescription(myTest.get(3));
			testObject.setMarks(Integer.valueOf(myTest.get(4)));
			testObject.setTypeOfQuestion(myTest.get(5));
			testDetailsWithAttempts.put(testObject, testAttempts);
		}
		ServletVariables.session.setAttribute(TESTDETAILSWITHATTEMPTS,testDetailsWithAttempts);
		response.sendRedirect(MARKSHISTORY);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
