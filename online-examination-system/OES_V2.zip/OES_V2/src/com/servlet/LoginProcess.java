package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Student;
import com.validation.LoginValidation;
import com.variables.ServletVariables;


@WebServlet(urlPatterns={"/LoginProcess","/admin/LoginProcess"})
public class LoginProcess extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
    
    public LoginProcess() {
        super();
        
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		ServletVariables.name=request.getParameter(NAME);
		ServletVariables.password=request.getParameter(PASSWORD);
		ServletVariables.role=request.getParameter(ROLE);
		LoginValidation login=new LoginValidation();
		if(ServletVariables.role.equals(ADMIN))
		{
			if(login.isUserNameValid(ServletVariables.name)&& login.isPasswordValid(ServletVariables.password))
			{
				if(ServletVariables.name.equalsIgnoreCase(ADMIN) && ServletVariables.password.equalsIgnoreCase(DEFAULTPASSWORD))
				{
					ServletVariables.session=request.getSession();
					ServletVariables.session.setAttribute(NAME, ADMIN);
					response.sendRedirect(HOME);
				}
				else
				{
					ServletVariables.out.println(ADMIN_VALIDATION);
					ServletVariables.rd=request.getRequestDispatcher(INDEX);
					ServletVariables.rd.include(request, response);
				}
			}
			else
			{
				
				if(!login.isUserNameValid(ServletVariables.name))
				{
					ServletVariables.out.print(INVALID_USERNAME);
				}
				if(!login.isPasswordValid(ServletVariables.password))
				{
					ServletVariables.out.print(INVALID_PASSWORD);
				}
				ServletVariables.rd=request.getRequestDispatcher(INDEX);
				ServletVariables.rd.include(request, response);
				
			}
		}
		else if(ServletVariables.role.equals(STUDENT))
		{
			Student student=new Student();
			if(login.isRollNumberValid(ServletVariables.name) && login.isPasswordValid(ServletVariables.password))
			{
					student.setEnrollment(ServletVariables.name);
					student.setPassword(ServletVariables.password);
					ServletVariables.con=DBConnection.getConnection();
					ServletVariables.status=StudentDB.isValidStudent(ServletVariables.con, student);
					if(ServletVariables.status)
					{
						ServletVariables.status=StudentDB.isFirstLogin(ServletVariables.con, student);
						if(ServletVariables.status==false)
						{
							response.sendRedirect(FORGETPASSWORD+QUESTIONMARK+ID+EQUAL+URLEncoder.encode(ServletVariables.name,UTF8));
						}
						else
						{
							ServletVariables.session=request.getSession();
							ServletVariables.session.setAttribute(ID,ServletVariables.name);
							ServletVariables.rd=request.getRequestDispatcher("PostLoginProcess");
							ServletVariables.rd.forward(request, response);
							//response.sendRedirect(HOME);
						}
					}
					else
					{
						ServletVariables.out.println(STUDENT_VALIDATION);
						ServletVariables.rd=request.getRequestDispatcher(INDEX);
						ServletVariables.rd.include(request, response);
					}
			}
			else
			{
				if(!login.isRollNumberValid(ServletVariables.name))
				{
					ServletVariables.out.print(INVALID_ROLLNUMBER);
				}
				if(!login.isPasswordValid(ServletVariables.password))
				{
					ServletVariables.out.print(INVALID_PASSWORD);
				}
				ServletVariables.rd=request.getRequestDispatcher(INDEX);
				ServletVariables.rd.include(request, response);
			}
		}
		ServletVariables.out.close();
	}

}
