package com.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.SubjectDB;
import com.inteface.Constants;
import com.variables.ServletVariables;


@WebServlet("/admin/GetSubjectsDetail")
public class GetSubjectsDetail extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    
    public GetSubjectsDetail() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(XML);
		ServletVariables.out=response.getWriter();
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.branch=Integer.parseInt(request.getParameter(BRANCH));
		Map<Integer,String> map=SubjectDB.getSubjectDetails(ServletVariables.con, ServletVariables.branch);
		Set<Entry<Integer,String>> set=map.entrySet();
		Iterator<Entry<Integer,String>> iterator=set.iterator();
		ServletVariables.out.print(SUBJECTSSTARTTAG);
			ServletVariables.out.print(SUBJECTSTARTTAG);
					ServletVariables.out.print("<id>None</id>");
					ServletVariables.out.print("<name>None</name>");
			ServletVariables.out.print(SUBJECTENDTAG);
			while(iterator.hasNext())
			{
				Entry<Integer,String> entry=iterator.next();
				ServletVariables.out.print(SUBJECTSTARTTAG);
				ServletVariables.out.print("<id>"+entry.getKey()+"</id>");
				ServletVariables.out.print("<name>"+entry.getValue()+"</name>");
				ServletVariables.out.print(SUBJECTENDTAG);
				
			}
		ServletVariables.out.print(SUBJECTSENDTAG);
		ServletVariables.out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
