package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.db.ResultDB;
import com.db.TestDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Result;
import com.utilities.FindGrade;
import com.utilities.FindPercentage;
import com.variables.ServletVariables;


@WebServlet("/GenerateResult")
public class GenerateResult extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;

    public GenerateResult() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		ServletVariables.session=request.getSession();
		ServletVariables.testType=request.getParameter(TESTTYPE);
		ServletVariables.enrollmentID=(String)ServletVariables.session.getAttribute(ID);
		ServletVariables.testId=Integer.parseInt(request.getParameter(TESTID));
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.testDetailsList=TestDB.getTestDetails(ServletVariables.con, ServletVariables.testId);
		ServletVariables.questions=QuestionDB.getQuestionsBasedOnItsType(ServletVariables.con, ServletVariables.testId, ServletVariables.testType);
		ServletVariables.marksOfEachQuestion=Integer.parseInt(ServletVariables.testDetailsList.get(3));
		ServletVariables.numberOfQuestions=Integer.parseInt(ServletVariables.testDetailsList.get(1));
		int status=0,i=0,marks=0,totalMarks=ServletVariables.numberOfQuestions*ServletVariables.marksOfEachQuestion;
		float percentage=0;
		char grade;
		if(ServletVariables.testType.equalsIgnoreCase(TRUEORFALSE))
		{
			i=1;
			marks=0;
			for(List<String> question:ServletVariables.questions)
			{
				ServletVariables.answer=request.getParameter(NAMEQUESTION+i);
				if(ServletVariables.answer!=null && ServletVariables.answer.equals(question.get(2)))
				{
					marks+=ServletVariables.marksOfEachQuestion;
				}
				i++;
			}
		}
		else if(ServletVariables.testType.equalsIgnoreCase(SINGLE))
		{
			i=1;
			marks=0;
			for(List<String> question:ServletVariables.questions)
			{
				ServletVariables.answer=request.getParameter(NAMEQUESTION+i);
				if(ServletVariables.answer!=null && ServletVariables.answer.equals(question.get(6)))
				{
					marks+=ServletVariables.marksOfEachQuestion;
				}
				i++;
			}
		}
		else if(ServletVariables.testType.equalsIgnoreCase(MULTI))
		{
			i=1;
			marks=0;
			String[] multiAnswers=null;
			List<String> myAnswers=new ArrayList<String>();
			List<String> correctAnswers=null;
			for(List<String> question:ServletVariables.questions)
			{
				correctAnswers=new ArrayList<String>();
				multiAnswers=request.getParameterValues(NAMEQUESTION+i);
				if(multiAnswers!=null)
				{
					myAnswers=Arrays.asList(multiAnswers);
					for(int j=6;j<question.size();j++)
					{
						correctAnswers.add(question.get(j));
					}
					if(myAnswers.equals(correctAnswers))
					{
						marks+=ServletVariables.marksOfEachQuestion;
					}
				}
				i++;
			}
		}
		
	percentage=FindPercentage.getPercentange((float)marks,(float)totalMarks);
	grade=FindGrade.getGrade(percentage);
	Result result=new Result();
	result.setTotalMarks(totalMarks);
	result.setStudentMarks(marks);
	result.setPercentage((int)percentage);
	result.setGrade(grade);
	if(!ResultDB.isTestIdAndStudentIdExistInResultsTable(ServletVariables.con, ServletVariables.testId, Integer.parseInt(ServletVariables.enrollmentID)))
	{
		status=ResultDB.insertDetailsInResultsAndTestAttemptsTable(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID), ServletVariables.testId, result);
	}
	else
	{
		int resultId=ResultDB.getResultId(ServletVariables.con, ServletVariables.testId,Integer.parseInt(ServletVariables.enrollmentID));
		status=ResultDB.insertDetailsInTestAttemptsTable(ServletVariables.con, result, resultId);
	}
	if(status<=0)
	{
		ServletVariables.rd=request.getRequestDispatcher(HOME);
		ServletVariables.out.println(DEFAULT_ERROR);
		ServletVariables.rd.include(request, response);
	}
	else
	{
		ServletVariables.session.setAttribute("marks", marks);
		ServletVariables.session.setAttribute("totalMarks", totalMarks);
		ServletVariables.session.setAttribute("percentage", (int)percentage);
		ServletVariables.session.setAttribute("grade", grade);
		response.sendRedirect(RESULT);
	}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
