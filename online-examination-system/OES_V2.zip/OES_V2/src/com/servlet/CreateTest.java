package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Test;
import com.variables.ServletVariables;

@WebServlet("/admin/CreateTest")
public class CreateTest extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    public CreateTest() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(HTML);
		Test test=new Test();
		ServletVariables.title=request.getParameter(TITLE);
		ServletVariables.description=request.getParameter(DESCRIPTION);
		ServletVariables.subjectId=Integer.parseInt(request.getParameter(SUBJECT));
		ServletVariables.testType=request.getParameter(TESTTYPE);
		ServletVariables.marksOfEachQuestion=Integer.parseInt(request.getParameter(MARKS));
		test.setTitle(ServletVariables.title);
		test.setDescription(ServletVariables.description);
		test.setSubjectId(ServletVariables.subjectId);
		test.setTypeOfQuestion(ServletVariables.testType);
		test.setMarks(ServletVariables.marksOfEachQuestion);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.testId=TestDB.insertTestDetails(ServletVariables.con, test);
		if(ServletVariables.testId>0)
		{
			if(ServletVariables.testType.equals(SINGLE))
			{
				response.sendRedirect("PostSingleChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId);
			}
			else if(ServletVariables.testType.equals(MULTI))
			{
				response.sendRedirect("PostMultiChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId);
			}
			else if(ServletVariables.testType.equals(TRUEORFALSE))
			{
				response.sendRedirect("PostTrueFalseChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId);
			}
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
