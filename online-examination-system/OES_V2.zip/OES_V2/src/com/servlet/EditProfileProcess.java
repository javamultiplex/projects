package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Student;
import com.validation.UpdateProfileValidation;
import com.variables.ServletVariables;

@WebServlet("/EditProfileProcess")
public class EditProfileProcess extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
       
    
    public EditProfileProcess() {
        super();
  
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Student student=new Student();
		UpdateProfileValidation update=new UpdateProfileValidation();
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		ServletVariables.session=request.getSession();
		ServletVariables.enrollmentID=(String) ServletVariables.session.getAttribute(ID);
		ServletVariables.firstName=request.getParameter(FIRSTNAME);
		ServletVariables.lastName=request.getParameter(LASTNAME);
		ServletVariables.email=request.getParameter(EMAIL);
		ServletVariables.phone=request.getParameter(PHONE);
		if(update.isNameValid(ServletVariables.firstName) && update.isNameValid(ServletVariables.lastName) && update.isEmailValid(ServletVariables.email) &&  update.isPhoneValid(ServletVariables.phone))
		{
				student.setEnrollment(ServletVariables.enrollmentID);
				student.setFirstName(ServletVariables.firstName);
				student.setLastName(ServletVariables.lastName);
				student.setEmail(ServletVariables.email);
				student.setPhone(ServletVariables.phone);
				ServletVariables.con=DBConnection.getConnection();
				ServletVariables.queryStatus=StudentDB.updateStudentDetailsById(ServletVariables.con, student);
				if(ServletVariables.queryStatus>0)
				{
					response.sendRedirect("PreViewProfileProcess");
				}
				else
				{
					ServletVariables.out.print(DEFAULT_ERROR);
					ServletVariables.rd=request.getRequestDispatcher(EDITPROFILE);
					ServletVariables.rd.include(request, response);
				}
		}
		else
		{
			if(!(update.isNameValid(ServletVariables.firstName)))
			{
				ServletVariables.out.print(INVALID_FIRSTNAME);
			}
			if(!(update.isNameValid(ServletVariables.lastName)))
			{
				ServletVariables.out.print(INVALID_LASTNAME);
			}
			if(!(update.isEmailValid(ServletVariables.email)))
			{
				ServletVariables.out.print(INVALID_EMAIL);
			}
			if(!(update.isPhoneValid(ServletVariables.phone)))
			{
				ServletVariables.out.print(INVALID_PHONE);
			}
			
			ServletVariables.rd=request.getRequestDispatcher(EDITPROFILE);
			ServletVariables.rd.include(request, response);
			
		}
	
	}

}
