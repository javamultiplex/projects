package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.utilities.CapitalizeFirstLetter;
import com.variables.ServletVariables;

@WebServlet("/admin/PostMultiChoice")
public class PostMultiChoice extends HttpServlet implements Constants, Messages{
	private static final long serialVersionUID = 1L;
       
  
    public PostMultiChoice() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletVariables.session=request.getSession();
		ServletVariables.testId=Integer.parseInt(request.getParameter(TESTID));
		ServletVariables.message=request.getParameter(MESSAGE);
		String flag=request.getParameter("flag");
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.testDetailsList=TestDB.getTestDetails(ServletVariables.con, ServletVariables.testId);
		ServletVariables.title=CapitalizeFirstLetter.getResultantString(ServletVariables.testDetailsList.get(0));
		ServletVariables.numberOfQuestions=Integer.parseInt(ServletVariables.testDetailsList.get(1));
		ServletVariables.session.setAttribute(TITLE, ServletVariables.title);
		ServletVariables.session.setAttribute(NUMBEROFQUESTIONS,ServletVariables.numberOfQuestions);
		if(ServletVariables.message==null)
		{
			response.sendRedirect(MULTICHOICE+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId);
		}
		else
		{
			response.sendRedirect(MULTICHOICE+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId+AND+MESSAGE+EQUAL+ServletVariables.message+AND+"flag="+flag);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
