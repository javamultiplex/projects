package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.variables.ServletVariables;


@WebServlet("/admin/UpdateStudentBranch")
public class UpdateStudentBranch extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
       

    public UpdateStudentBranch() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.branch=Integer.parseInt(request.getParameter(BRANCH));
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.queryStatus=StudentDB.updateBranchNameById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID), ServletVariables.branch);
		if(ServletVariables.queryStatus>0)
		{
			response.sendRedirect(UPDATESTUDENT+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(SUCCESS_STUDENT_BRANCH_ADDED,UTF8));
		}
		else
		{
			response.sendRedirect(UPDATESTUDENT+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(DEFAULT_ERROR,UTF8));
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
