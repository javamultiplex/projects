package com.servlet;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.BranchDB;
import com.db.DBConnection;
import com.inteface.Constants;
import com.variables.ServletVariables;

@WebServlet("/admin/PreCreateTest")
public class PreCreateTest extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
   
    public PreCreateTest() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletVariables.session=request.getSession();
		ServletVariables.con=DBConnection.getConnection();
		Map<Integer,String> branch=BranchDB.getBranchDetails(ServletVariables.con);
		ServletVariables.session.setAttribute(BRANCH,branch);
		response.sendRedirect(CREATETEST);
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
