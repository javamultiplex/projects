package com.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.BranchDB;
import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.variables.ServletVariables;

@WebServlet("/admin/UpdateStudentBranchView")
public class UpdateStudentBranchView extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
   
    public UpdateStudentBranchView() {
        super();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.studentDetailsList=StudentDB.getStudentDetailsById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID));
		Map<Integer,String> branch=BranchDB.getBranchDetails(ServletVariables.con);
		Set<Entry<Integer,String>> set=branch.entrySet();
		Iterator<Entry<Integer,String>> iterator=set.iterator();	
		ServletVariables.out.println(TABLESTARTTAG);
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>Current Branch</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<input type='text' style='width:250px;' value='"+ServletVariables.studentDetailsList.get(4)+"'/>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEROWSTARTTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<b>New Branch</b>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLECELLSTARTTAG);
		ServletVariables.out.print("<select name='branch' style='width:255px;'>");
		ServletVariables.out.print("<option value='None'>None</option>");
		while(iterator.hasNext())
		{
			Entry<Integer,String> entry=iterator.next();
			ServletVariables.out.print("<option value='"+entry.getKey()+"'>"+entry.getValue()+"</option>");
		}
		ServletVariables.out.print("</select>");
		ServletVariables.out.print(TABLECELLENDTAG);
		ServletVariables.out.print(TABLEROWENDTAG);
		
		ServletVariables.out.print(TABLEENDTTAG);
		
		ServletVariables.out.close();
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
