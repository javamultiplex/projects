package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Question;
import com.variables.ServletVariables;


@WebServlet("/admin/MultiChoiceQuestionsProcess")
public class MultiChoiceQuestionsProcess extends HttpServlet implements Constants,Messages {
	private static final long serialVersionUID = 1L;
       
    public MultiChoiceQuestionsProcess() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		Question ques=new Question();
		List<String> answers=new ArrayList<String>();
		ServletVariables.question=request.getParameter(QUESTION);
		ServletVariables.option1=request.getParameter(OPTION1);
		ServletVariables.option2=request.getParameter(OPTION2);
		ServletVariables.option3=request.getParameter(OPTION3);
		ServletVariables.option4=request.getParameter(OPTION4);
		ServletVariables.answer1=request.getParameter(ANSWER1);
		ServletVariables.answer2=request.getParameter(ANSWER2);
		ServletVariables.answer3=request.getParameter(ANSWER3);
		ServletVariables.answer4=request.getParameter(ANSWER4);
		ServletVariables.testId=Integer.parseInt(request.getParameter(ID));
		if(ServletVariables.answer1!=null)
			answers.add(ServletVariables.answer1);
		if(ServletVariables.answer2!=null)
			answers.add(ServletVariables.answer2);
		if(ServletVariables.answer3!=null)
			answers.add(ServletVariables.answer3);
		if(ServletVariables.answer4!=null)
			answers.add(ServletVariables.answer4);
		ques.setQuestion(ServletVariables.question);
		ques.setOption1(ServletVariables.option1);
		ques.setOption2(ServletVariables.option2);
		ques.setOption3(ServletVariables.option3);
		ques.setOption4(ServletVariables.option4);
		ques.setMultiAnswer(answers);
		
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.queryStatus=QuestionDB.insertMultiChoiceQuestionDetails(ServletVariables.con, ques, ServletVariables.testId);
		if(ServletVariables.queryStatus>0)
		{
			response.sendRedirect("PostMultiChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId+AND+MESSAGE+EQUAL+URLEncoder.encode(SUCCESS_QUESTION_ADDED,UTF8)+AND+"flag=1");
		}
		else
		{
			response.sendRedirect("PostMultiChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId+AND+MESSAGE+EQUAL+URLEncoder.encode(DEFAULT_ERROR,UTF8)+AND+"flag=0");
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
