package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Student;
import com.variables.ServletVariables;

@WebServlet("/ForgetPasswordProcess")
public class ForgetPasswordProcess extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
   
    public ForgetPasswordProcess() {
        super();  
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		ServletVariables.out=response.getWriter();
		String status=request.getParameter(STATUS);
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.password=request.getParameter(PASSWORD);
		Student student=new Student();
		student.setEnrollment(ServletVariables.enrollmentID);
		student.setPassword(ServletVariables.password);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.result=0;
		if(status.equals(FALSE))
		{
			ServletVariables.oldPassword=request.getParameter(OLDPASSWORD);
			ServletVariables.result=StudentDB.isPasswordUpdated(ServletVariables.con, ServletVariables.oldPassword, student);
			if(ServletVariables.result>0)
			{
				response.sendRedirect(INDEX);
			}
			else
			{
				ServletVariables.rd=request.getRequestDispatcher(FORGETPASSWORD+QUESTIONMARK+ID+EQUAL+URLEncoder.encode(ServletVariables.enrollmentID,UTF8));
				ServletVariables.out.println(INVALID_OLDPASSWORD);
				ServletVariables.rd.include(request, response);
			}
		}
		else
		{
			ServletVariables.result=StudentDB.isPasswordUpdated(ServletVariables.con, student);
			if(ServletVariables.result>0)
			{
				response.sendRedirect(INDEX);
			}else
			{
				ServletVariables.rd=request.getRequestDispatcher(FORGETPASSWORD+QUESTIONMARK+ID+EQUAL+URLEncoder.encode(ServletVariables.enrollmentID,UTF8));
				ServletVariables.out.println(DEFAULT_ERROR);
				ServletVariables.rd.include(request, response);
			}
		}
		ServletVariables.out.close();
	}

}
