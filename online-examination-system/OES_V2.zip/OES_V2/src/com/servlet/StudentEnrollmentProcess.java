package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Student;
import com.variables.ServletVariables;

@WebServlet("/admin/StudentEnrollmentProcess")
public class StudentEnrollmentProcess extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
    public StudentEnrollmentProcess() {
        super();
        
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(HTML);
		Student student=new Student();
		ServletVariables.firstName=request.getParameter(FIRSTNAME);
		ServletVariables.lastName=request.getParameter(LASTNAME);
		ServletVariables.branch=Integer.parseInt(request.getParameter(BRANCH));
		student.setFirstName(ServletVariables.firstName);
		student.setLastName(ServletVariables.lastName);
		student.setBranch(ServletVariables.branch);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.queryStatus=StudentDB.insertStudentDataByAdmin(ServletVariables.con, student);
		if(ServletVariables.queryStatus>0)
		{
			response.sendRedirect(ADDSTUDENT+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(SUCCESS_STUDENT_ADDED,UTF8));
		}
		else
		{
			response.sendRedirect(ADDSTUDENT+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(DEFAULT_ERROR,UTF8));
		}
		
		
	}

}
