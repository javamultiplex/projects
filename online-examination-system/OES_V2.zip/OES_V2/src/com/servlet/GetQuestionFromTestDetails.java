package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.db.TestDB;
import com.inteface.Constants;

/**
 * Servlet implementation class GetQuestionFromTestDetails
 */
@WebServlet("/admin/GetQuestionFromTestDetails")
public class GetQuestionFromTestDetails extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetQuestionFromTestDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(XML);
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		List<String> list=TestDB.getTestDetails(con, id);
		int numberOfQuestions=Integer.parseInt(list.get(1));
		String typeOfQuestions=list.get(4);
		List<String> questionsID=null;
		int questionStartingNumber=1;
		if(typeOfQuestions.equals(TRUEORFALSE))
		{
			questionsID=QuestionDB.getTrueFalseQuestionsIDByTestID(con, id);
			out.print(QUESTIONSSTARTTAG);
			out.print(QUESTIONSTARTTAG);
					out.print("<id>None</id>");
					out.print("<number>None</number>");
			out.print(QUESTIONENDTAG);
			for(String quesID:questionsID)
			{
				if(questionStartingNumber!=numberOfQuestions+1)
				{
				out.print(QUESTIONSTARTTAG);
				out.print("<id>"+TRUEORFALSE+quesID+"</id>");
				out.print("<number>Question "+ questionStartingNumber++ +"</number>");
				out.print(QUESTIONENDTAG);
				}
			}
		out.print(QUESTIONSENDTAG);
		}
		else if(typeOfQuestions.equals(SINGLE))
		{
			questionsID=QuestionDB.getSingleChoiceQuestionsIDByTestID(con, id);
			out.print(QUESTIONSSTARTTAG);
			out.print(QUESTIONSTARTTAG);
					out.print("<id>None</id>");
					out.print("<number>None</number>");
			out.print(QUESTIONENDTAG);
			for(String quesID:questionsID)
			{
				if(questionStartingNumber!=numberOfQuestions+1)
				{
				out.print(QUESTIONSTARTTAG);
				out.print("<id>"+SINGLE+quesID+"</id>");
				out.print("<number>Question "+ questionStartingNumber++ +"</number>");
				out.print(QUESTIONENDTAG);
				}
			}
		out.print(QUESTIONSENDTAG);
		
		}
		else if(typeOfQuestions.equals(MULTI))
		{
			questionsID=QuestionDB.getMultiChoiceQuestionsIDByTestID(con, id);
			out.print(QUESTIONSSTARTTAG);
			out.print(QUESTIONSTARTTAG);
					out.print("<id>None</id>");
					out.print("<number>None</number>");
			out.print(QUESTIONENDTAG);
			for(String quesID:questionsID)
			{
				if(questionStartingNumber!=numberOfQuestions+1)
				{
				out.print(QUESTIONSTARTTAG);
				out.print("<id>"+MULTI+quesID+"</id>");
				out.print("<number>Question "+ questionStartingNumber++ +"</number>");
				out.print(QUESTIONENDTAG);
				}
			}
		out.print(QUESTIONSENDTAG);
		}
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
