package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.pojo.Question;
import com.variables.ServletVariables;


@WebServlet("/admin/TrueFalseQuestionsProcess")
public class TrueFalseQuestionsProcess extends HttpServlet implements Constants,Messages{
	private static final long serialVersionUID = 1L;
       
   
    public TrueFalseQuestionsProcess() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType(HTML);
		Question ques=new Question();
		ServletVariables.question=request.getParameter(QUESTION);
		ServletVariables.answer=request.getParameter(ANSWER);
		ServletVariables.testId=Integer.parseInt(request.getParameter(ID));
		ques.setQuestion(ServletVariables.question);
		ques.setBooleanAnswer(ServletVariables.answer);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.queryStatus=QuestionDB.insertTrueFalseQuestionDetails(ServletVariables.con, ques, ServletVariables.testId);
		if(ServletVariables.queryStatus>0)
		{
			response.sendRedirect("PostTrueFalseChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId+AND+MESSAGE+EQUAL+URLEncoder.encode(SUCCESS_QUESTION_ADDED,UTF8)+AND+"flag=1");
		}
		else
		{
			response.sendRedirect("PostTrueFalseChoice"+QUESTIONMARK+TESTID+EQUAL+ServletVariables.testId+AND+MESSAGE+EQUAL+URLEncoder.encode(DEFAULT_ERROR,UTF8)+AND+"flag=0");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
