package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Test;
import com.utilities.JoinFirstNameAndLastName;
import com.variables.ServletVariables;

@WebServlet("/PostLoginProcess")
public class PostLoginProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    
    public PostLoginProcess() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Test testPojo=null;
		List<Test> testDetails=new ArrayList<Test>();
		ServletVariables.session=request.getSession();
		ServletVariables.enrollmentID=(String) ServletVariables.session.getAttribute(ID);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.studentDetailsList=StudentDB.getStudentDetailsById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID));
		ServletVariables.firstName=ServletVariables.studentDetailsList.get(0);
		ServletVariables.lastName=ServletVariables.studentDetailsList.get(1);
		ServletVariables.fullName=JoinFirstNameAndLastName.getFullName(ServletVariables.firstName, ServletVariables.lastName);
		ServletVariables.test=TestDB.getTestDetailsByStudentID(ServletVariables.con,Integer.parseInt(ServletVariables.enrollmentID));
		
		for(List<String> testTemp:ServletVariables.test)
		{
			testPojo=new Test();
			testPojo.setTestID(Integer.valueOf(testTemp.get(0)));
			testPojo.setTitle(testTemp.get(1));
			testPojo.setNoOfQuestions(Integer.valueOf(testTemp.get(2)));
			testPojo.setDescription(testTemp.get(3));
			testPojo.setMarks(Integer.valueOf(testTemp.get(4)));
			testPojo.setTypeOfQuestion(testTemp.get(5));
			testDetails.add(testPojo);
		}
		ServletVariables.session.setAttribute(NAME,ServletVariables.fullName);
		ServletVariables.session.setAttribute(TESTDETAILSLIST, testDetails);
		ServletVariables.session.setAttribute(LISTSIZE,testDetails.size());
		response.sendRedirect(HOME);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
