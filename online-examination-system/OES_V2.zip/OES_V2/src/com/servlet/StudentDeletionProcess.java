package com.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.inteface.Messages;
import com.variables.ServletVariables;

@WebServlet("/admin/StudentDeletionProcess")
public class StudentDeletionProcess extends HttpServlet implements Constants,Messages {
	private static final long serialVersionUID = 1L;
       

    public StudentDeletionProcess() {
        super();
    
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(HTML);
		ServletVariables.enrollmentID=request.getParameter(ID);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.queryStatus=StudentDB.deleteStudentById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID));
		if(ServletVariables.queryStatus>0)
		{
				response.sendRedirect("PreDeleteStudent"+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(SUCCESS_STUDENT_DELETE,UTF8));
		}
		else
		{
				response.sendRedirect("PreDeleteStudent"+QUESTIONMARK+MESSAGE+EQUAL+URLEncoder.encode(DEFAULT_ERROR,UTF8));
		}
		
	}

}
