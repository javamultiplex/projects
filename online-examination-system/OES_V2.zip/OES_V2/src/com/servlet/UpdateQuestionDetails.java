package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.pojo.Question;

/**
 * Servlet implementation class UpdateQuestionDetails
 */
@WebServlet("/admin/UpdateQuestionDetails")
public class UpdateQuestionDetails extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateQuestionDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(HTML);
		int testID=Integer.parseInt(request.getParameter("testtitle"));
		String typeAndId=request.getParameter("question");
		Question ques=new Question();
		String typeOfQuestion=null;
		String question=null;
		String option1=null;
		String option2= null;
		String option3=null;
		String option4=null;
		String answer=null;
		int status=0;
		List<String> answers=null;
		int questionId=0;
		Connection con=DBConnection.getConnection();
		if(typeAndId.startsWith(TRUEORFALSE))
			typeOfQuestion=TRUEORFALSE;
		else if(typeAndId.startsWith(SINGLE))
			typeOfQuestion=SINGLE;
		else if(typeAndId.startsWith(MULTI))
			typeOfQuestion=MULTI;
		questionId=Integer.parseInt(typeAndId.substring(typeOfQuestion.length(), typeAndId.length()));
		if(typeOfQuestion.equals(TRUEORFALSE))
		{
			question=request.getParameter("myquestion");
			answer=request.getParameter("answer");
			ques.setQuestion(question);
			ques.setBooleanAnswer(answer);
			status=QuestionDB.updateTrueFalseQuestiions(con, ques, questionId);
		}
		else if(typeOfQuestion.equals(SINGLE))
		{
			question=request.getParameter("myquestion");
			option1=request.getParameter("option1");
			option2=request.getParameter("option2");
			option3=request.getParameter("option3");
			option4=request.getParameter("option4");
			answer=request.getParameter("answer");
			ques.setQuestion(question);
			ques.setOption1(option1);
			ques.setOption2(option2);
			ques.setOption3(option3);
			ques.setOption4(option4);
			ques.setSingleAnswer(answer);
			status=QuestionDB.updateSingleChoiceQuestiions(con, ques,questionId);
		}
		else if(typeOfQuestion.equals(MULTI))
		{
			question=request.getParameter("myquestion");
			option1=request.getParameter("option1");
			option2=request.getParameter("option2");
			option3=request.getParameter("option3");
			option4=request.getParameter("option4");
			answer=request.getParameter("answer");
			ques.setQuestion(question);
			ques.setOption1(option1);
			ques.setOption2(option2);
			ques.setOption3(option3);
			ques.setOption4(option4);
			String[] ans=answer.split(",");
			answers=new ArrayList<String>();
			for(int i=0;i<ans.length;i++)
			{
				answers.add(ans[i]);
			}
			ques.setMultiAnswer(answers);
			status=QuestionDB.updateMultiChoiceQuestiions(con, ques, testID, questionId);
			
		}
		if(status>0)
		{
			response.sendRedirect("viewquestion.jsp?message=success");
		}
		else
		{
			response.sendRedirect("viewquestion.jsp?message=fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
