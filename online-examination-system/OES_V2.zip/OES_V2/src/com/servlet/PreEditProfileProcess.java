package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;
import com.variables.ServletVariables;


@WebServlet("/PreEditProfileProcess")
public class PreEditProfileProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    
    public PreEditProfileProcess() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Student student=new Student();
		ServletVariables.session=request.getSession();
		ServletVariables.enrollmentID=(String) ServletVariables.session.getAttribute(ID);
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.studentDetailsList=StudentDB.getStudentDetailsById(ServletVariables.con, Integer.parseInt(ServletVariables.enrollmentID));
		student.setFirstName(ServletVariables.studentDetailsList.get(0));
		student.setLastName(ServletVariables.studentDetailsList.get(1));
		student.setEmail(ServletVariables.studentDetailsList.get(2));
		student.setPhone(ServletVariables.studentDetailsList.get(3));
		student.setBranchName(ServletVariables.studentDetailsList.get(4));
		ServletVariables.session.setAttribute(STUDENT, student);
		response.sendRedirect(EDITPROFILE);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
