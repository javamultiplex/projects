package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.pojo.Question;
import com.variables.ServletVariables;

@WebServlet("/PreTest")
public class PreTest extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    
    public PreTest() {
        super();
        
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		List<Question> questionsList=new ArrayList<Question>();
		ServletVariables.session=request.getSession();
		ServletVariables.con=DBConnection.getConnection();
		ServletVariables.testDetails=request.getParameter(TEST);
		ServletVariables.testDetailsArray=ServletVariables.testDetails.split(COMMA);
		ServletVariables.testId=Integer.parseInt(ServletVariables.testDetailsArray[0]);
		ServletVariables.testType=ServletVariables.testDetailsArray[5];
		ServletVariables.questions=QuestionDB.getQuestionsBasedOnItsType(ServletVariables.con, ServletVariables.testId,ServletVariables.testType);
		for(List<String> question:ServletVariables.questions)
		{
			Question ques=new Question();
			if(ServletVariables.testType.equalsIgnoreCase(TRUEORFALSE))
			{
				ques.setQuestionId(Integer.valueOf(question.get(0)));
				ques.setQuestion(question.get(1));
			}
			else if(ServletVariables.testType.equalsIgnoreCase(SINGLE) || ServletVariables.testType.equalsIgnoreCase(MULTI))
			{
				ques.setQuestionId(Integer.valueOf(question.get(0)));
				ques.setQuestion(question.get(1));
				ques.setOption1(question.get(2));
				ques.setOption2(question.get(3));
				ques.setOption3(question.get(4));
				ques.setOption4(question.get(5));
			}
			questionsList.add(ques);
		}
		ServletVariables.session.setAttribute(QUESTIONSLIST, questionsList);
		ServletVariables.session.setAttribute(TESTTYPE,ServletVariables.testType);
		ServletVariables.session.setAttribute(TESTID, ServletVariables.testId);
		response.sendRedirect(TESTPAGE);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
