package com.inteface;

public interface Validation {

	public static String BLANK="";
	public static String REGX_ROLLNUMBER="^[0-9]+$";
	public static String REGX_NAME="^[a-zA-Z]+$";
	public static String REGX_PHONE="^[1-9]{1}[0-9]{9}$";
	public static String REGX_EMAIL="^[\\w!#$%&�*+/=?`{|}~^-]+(?:\\.[\\w!#$%&�*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
	
}
