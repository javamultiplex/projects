package com.inteface;

public interface Messages {

	public static String ADMIN_VALIDATION="<center><h1>Invalid username or password.</h1></center>";
	public static String STUDENT_VALIDATION="<center><h1>Invalid Roll Number or password.</h1></center>";
	public static String INVALID_ROLLNUMBER="<center><h1>Roll number is mandatory and should be numerical.</h1></center>";
	public static String INVALID_USERNAME="<center><h1>Username is mandatory.</h1></center>";
	public static String INVALID_PASSWORD="<center><h1>Password is mandatory.</h1></center>";
	public static String INVALID_FIRSTNAME="<center><h1>Firstname is mandatory and should be alphabetic.</h1></center>";
	public static String INVALID_LASTNAME="<center><h1>Lastname is mandatory and should be alphabetic.</h1></center>";
	public static String INVALID_PHONE="<center><h1>Phone number is mandatory and should be 10 digit long.</h1></center>";
	public static String INVALID_EMAIL="<center><h1>Email is mandatory.</h1></center>";
	public static String DEFAULT_ERROR="<center><h1>Some error occured, please try again.</h1></center>";
	public static String INVALID_OLDPASSWORD="<center><h2>Old password is wrong!!</h2></center>";
	public static String SUCCESS_STUDENT_ADDED="<p style='color:red;'>Student has been added successfully!!</p>";
	public static String SUCCESS_STUDENT_BRANCH_ADDED="<p style='color:red;'>Student branch has been updated successfully!!</p>";
	public static String SUCCESS_STUDENT_DELETE="<p style='color:red;'>Student details has been deleted successfully!!</p>";
	public static String SUCCESS_QUESTION_ADDED="Questions has been added successfully!!, Do you want to add more questions? if 'Yes' Press 'Ok' else 'Cancle'";
}
