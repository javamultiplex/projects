package com.inteface;

public interface DBParameters {

	public static String USERNAME="root";
	public static String PASSWORD="root";
	public static String DATABASE="onlineexaminationsystem";
	public static String URL="jdbc:mysql://localhost:3306/"+DATABASE;
	public static String DRIVER="com.mysql.jdbc.Driver";
		
}
