package com.variables;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

public class ServletVariables {

	public static PrintWriter out=null;
	public static RequestDispatcher rd=null;
	public static HttpSession session=null;
	public static String name=null;
	public static String password=null;
	public static String role=null;
	public static Connection con=null;
	public static boolean status=false;
	public static String firstName=null;
	public static String lastName=null;
	public static String email=null;
	public static String phone=null;
	public static int queryStatus=0;
	public static String enrollmentID=null;
	public static String fullName=null;
	public static List<String> studentDetailsList=null;
	public static List<String> testDetailsList=null;
	public static List<List<String>> test=null;
	public static List<List<String>> questions=null;
	public static String testDetails=null;
	public static String[] testDetailsArray=null;
	public static int resultId=0;
	public static int testId=0;
	public static String testType=null;
	public static int result=0;
	public static String oldPassword=null;
	public static int marksOfEachQuestion=0;
	public static int numberOfQuestions=0;
	public static String answer=null;
	public static int branch=0;
	public static String title=null;
	public static String description=null;
	public static int subjectId=0;
	public static String question=null;
	public static String option1=null;
	public static String option2=null;
	public static String option3=null;
	public static String answer1=null;
	public static String answer2=null;
	public static String answer3=null;
	public static String answer4=null;
	public static String option4=null;
	public static String message= null;
	
}
