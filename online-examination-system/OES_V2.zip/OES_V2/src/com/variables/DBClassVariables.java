package com.variables;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

public class DBClassVariables {

	public static PreparedStatement statement=null;
	public static ResultSet result=null;
	public static String query=null;
	public static int status=0;
	public static List<String> list=null;
	public static String enrollmentId=null;
	public static String firstName=null;
	public static String lastName=null;
	public static int branch=0;
	public static String password=null;
	public static String id=null;
	public static String email=null;
	public static String phone=null;
	public static boolean valid=false;
	public static Map<Integer,String> map=null;	
	public static String title=null;
	public static String description=null;
	public static int subjectID=0;
	public static int marks=0;
	public static String type=null;
	public static int status1=0;
	public static int status2=0;
	public static String question=null;
	public static String option1=null;
	public static String option2=null;
	public static String option3=null;
	public static String option4=null;
	public static String answer=null;
	public static List<String> answers=null;
	public static List<String> questionDetail=null;
	public static int numberOfQuestions=0;
	public static String branchName=null;
	public static List<List<String>> questions=null;
	public static List<List<String>> attempts=null;
	public static int totalMarks=0;
	public static int studentMarks=0;
	public static int percentage=0;
	public static char grade='\u0000';
	public static int resultId=0;
}
