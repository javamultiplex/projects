package com.utilities;

public class FindGrade {

	
	public static char getGrade(float percentage)
	{
		char grade;
		if(percentage>=90)
		{
			grade='A';
		}
		else if(percentage>=75 && percentage<90)
		{
			grade='B';
		}
		else if(percentage>=60 && percentage<75)
		{
			grade='C';
		}
		else if(percentage>=33 && percentage<60)
		{
			grade='D';
		}
		else
		{
			grade='E';
		}
		return grade;
	}
	
}
