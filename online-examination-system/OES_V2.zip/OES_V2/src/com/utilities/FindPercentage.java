package com.utilities;

public class FindPercentage {

	
	public static float getPercentange(float actualMarks,float totalMarks)
	{
		float result=(actualMarks/totalMarks)*100;
		return result;
	}
	
}
