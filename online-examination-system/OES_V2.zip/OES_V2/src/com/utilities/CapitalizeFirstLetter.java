package com.utilities;

public class CapitalizeFirstLetter {

	public static String result=null;
	
	public static String getResultantString(String name)
	{
		result=name.toUpperCase();
		result=result.substring(0, 1)+""+result.substring(1,result.length()).toLowerCase();
		return result;
	}
	
}
