package com.utilities;

public class JoinFirstNameAndLastName {
	
	public static String result=null;
	public static String first=null;
	public static String last=null;
	public static String getFullName(String firstName,String lastName)
	{
		first=firstName.toLowerCase();
		last=lastName.toLowerCase();
		result=first.substring(0, 1).toUpperCase()+""+first.substring(1,first.length())+" "+last.substring(0, 1).toUpperCase()+""+last.substring(1,last.length());
		return result;
	}

}
