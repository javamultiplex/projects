package com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.inteface.DBQuery;
import com.variables.DBClassVariables;

public class SubjectDB extends DBClassVariables implements DBQuery{

	//Get Subject names by branch id
	public static Map<Integer,String> getSubjectDetails(Connection con,int id)
	{
		query=SelectFromSubjectByBranchID;
		map=new HashMap<Integer, String>();
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			result=statement.executeQuery();
			while(result.next())
			{
				map.put(result.getInt(1), result.getString(2));
			}

		} catch (SQLException e) {
			System.out.println("Exception in method [getSubjectDetails(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{

			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getSubjectDetails(Connection con,int id)]");
				e.printStackTrace();
			}	
		}
		return map;

	}

}
