package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.inteface.DBParameters;

public class DBConnection implements DBParameters{
	
	
	private static Connection connection=null;
	private DBConnection(){}
	public static Connection getConnection()
	{
		if(connection!=null)
			return connection;
		else
			return getConnection(DRIVER,URL,USERNAME,PASSWORD);
	}
	
	private static Connection getConnection(String driver,String url,String username,String password)
	{
	
		try {
			Class.forName(driver);
			connection=DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			System.out.println("Unable to load mysql driver");
			e.printStackTrace();
		}catch(SQLException e){
			System.out.println("Unable to connect to DB");
			e.printStackTrace();
		}
		return connection;
	}
	

}
