package com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.inteface.DBQuery;
import com.variables.DBClassVariables;

public class BranchDB extends DBClassVariables implements DBQuery{

	//Get all Branch's ID and Name
	public static Map<Integer,String> getBranchDetails(Connection con)
	{
		query=SelectFromBranch;
		map=new HashMap<Integer,String>();
		try {
			statement=con.prepareStatement(query);
			result=statement.executeQuery();
			while(result.next())
			{
				map.put(result.getInt(1), result.getString(2));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getBranchDetails(Connection con)]");
			e.printStackTrace();
		}
		finally
		{
			
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getBranchDetails(Connection con)]");
			}
			
		}
		return map;
		
	}
	
	//Get all Branch's Name
	public static List<String> getBranch(Connection connection)
	{
		query=SelectFromBranch;
		try {
			statement=connection.prepareStatement(query);
			result=statement.executeQuery();
			list=new ArrayList<String>();
			while(result.next())
			{
				list.add(result.getString("Name"));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getBranch(Connection connection)]");
			e.printStackTrace();
		}
		finally {
			
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getBranch(Connection connection)]");
			}
			
			
		}
	return list;
	}
	
	public static String getBranchNameByID(Connection con,int id)
	{
		query=SelectBranchByid;
		branchName=null;
		try
		{
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			result=statement.executeQuery();
			result.next();
			branchName=result.getString("Name");
		}
		catch(SQLException e)
		{
			System.out.println("Exception in method [getBranchNameByID(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getBranchNameByID(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return branchName;
	}
}
