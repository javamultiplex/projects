package com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.inteface.DBQuery;
import com.pojo.Test;
import com.variables.DBClassVariables;

public class TestDB extends DBClassVariables implements DBQuery{
	
	//Delete test by id
	public static int isTestDeleted(Connection con,int id)
	{
		status=0;
		query=DeleteTestByID;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [isTestDeleted(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println("DB Statement has not closed for method [isTestDeleted(Connection con,int id)]");
					e.printStackTrace();
				}
			}
		}
		return status;
		
	}
	
	//Get test id and title by subject id.
	public static Map<Integer,String> getIdAndTitleDetails(Connection con,int id)
	{
		query=SelectFromTestDetailsBySubjectID;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			result=statement.executeQuery();
			map=new HashMap<Integer,String>();
			while(result.next())
			{
				map.put(result.getInt(1), result.getString(2));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getIdAndTitleDetails(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getIdAndTitleDetails(Connection con,int id)]");
			}
		}
		return map;
		
	}
	
	//Get test details by test id.
	public static List<String> getTestDetails(Connection con,int id)
	{
		query=SelectTestDetailsByTestID;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			list=new ArrayList<String>();
			result=statement.executeQuery();
			if(result.next())
			{
				list.add(result.getString("Title"));
				list.add(String.valueOf(result.getInt("questions")));
				list.add(result.getString("Description"));
				list.add(String.valueOf(result.getInt("Marks")));
				list.add(result.getString("Type"));
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in method [getTestDetails(Connection con,int id)]");
			e.printStackTrace();
		}finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getTestDetails(Connection con,int id)]");
			}
		}
		return list;
		
	}
	
	//Insert test details and return test id
	public static int insertTestDetails(Connection con,Test test)
	{
		status=0;
		query=InsertTestDetails;
		title=test.getTitle();
		description=test.getDescription();
		type=test.getTypeOfQuestion();
		subjectID=test.getSubjectId();
		marks=test.getMarks();
		try {
			statement=con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, title);
			statement.setString(2, description);
			statement.setInt(3, marks);
			statement.setString(4, type);
			statement.setInt(5, subjectID);
			statement.executeUpdate();
			result=statement.getGeneratedKeys();
			if(result.next())
			{
				status=result.getInt(1);
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in method [insertTestDetails(Connection con,Test test)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [insertTestDetails(Connection con,Test test)]");
			}
		}
		
		return status;		
	}

	//Update test title,description and marks by test id.
	public static int updateTestDetails(Connection con,Test test,int id)
	{
		status=0;
		title=test.getTitle();
		description=test.getDescription();
		marks=test.getMarks();
		query=UpdateTestDetailsByID;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, title);
			statement.setString(2, description);
			statement.setInt(3, marks);
			statement.setInt(4, id);
			status=statement.executeUpdate();
			
		} catch (SQLException e){
			System.out.println("Exception in method [updateTestDetails(Connection con,Test test,int id)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println("DB Statement has not closed for method [updateTestDetails(Connection con,Test test,int id)]");
					e.printStackTrace();
				}
			}
		}
		return status;
		
	}
	
	//Get test details by student id.
	public static List<List<String>> getTestDetailsByStudentID(Connection con,int id)
	{
		query=SelectTestDetailsByStudentID;
		List<List<String>> list=new ArrayList<List<String>>();
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			result=statement.executeQuery();
			while(result.next())
			{
				List<String> tempList=new ArrayList<String>();
				tempList.add(String.valueOf(result.getInt("TestID")));
				tempList.add(result.getString("Title"));
				tempList.add(String.valueOf(result.getInt("Questions")));
				tempList.add(result.getString("Description"));
				tempList.add(String.valueOf(result.getInt("Marks")));
				tempList.add(result.getString("Type"));
				list.add(tempList);
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getTestDetailsByStudentID(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getTestDetailsByStudentID(Connection con,int id)]");
			}
		}

		return list;
	}
	
}
