package com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inteface.DBQuery;
import com.pojo.Student;
import com.variables.DBClassVariables;

public class StudentDB extends DBClassVariables implements DBQuery{
	
	//delete student by id
	public static int deleteStudentById(Connection con,int id)
	{
		status=0;
		query=DeleteStudentById;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [deleteStudentById(Connection con,String id)]");
			e.printStackTrace();
		}
		finally{
			
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println("DB Statement has not closed for method [deleteStudentById(Connection con,String id)]");
					e.printStackTrace();
				}
			}
		}
		return status;		
	}
	
	//Get student details by id
	public static List<String> getStudentDetailsById(Connection con,int id)
	{
		query=SelectStudentDetailsById;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			result=statement.executeQuery();
			list=new ArrayList<String>();
			result.next();
				list.add(result.getString("FirstName"));
				list.add(result.getString("LastName"));
				if(result.getString("Email")==null)
					list.add("NA");
				else
					list.add(result.getString("Email"));
				if(result.getString("Phone")==null)
					list.add("NA");
				else
					list.add(result.getString("Phone"));
				branch=result.getInt("Branch");
				branchName=BranchDB.getBranchNameByID(con, branch);
				list.add(branchName);
				
		} catch (SQLException e) {
			System.out.println("Exception in method [getStudentDetailsById(Connection con,String id)]");
			e.printStackTrace();
		}
		finally {
			
			try
			{
				if(statement!=null)
				{
					statement.close();
				}
				if(result!=null)
				{
					result.close();
				}
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resulset has no closed for method [getStudentDetailsById(Connection con,String id)]");
				e.printStackTrace();
			}
			
		}
		
		return list;
	}
	
	//Get student id's
	public static List<String> getStudentIds(Connection con)
	{
		query=SelectStudent;
		try {
			statement=con.prepareStatement(query);
			result=statement.executeQuery();
			list=new ArrayList<String>();
			while(result.next())
			{
				list.add(String.valueOf(result.getInt(1)));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getStudentIds(Connection con)]");
			e.printStackTrace();
		}
		finally {
			try
			{
				if(statement!=null)
				{
					statement.close();
				}
				if(result!=null)
				{
					result.close();
				}
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resulset has no closed for method [getStudentIds(Connection con)]");
				e.printStackTrace();
			}
		}
		
		return list;	
	}
	
	//Insert student details by admin
	public static int insertStudentDataByAdmin(Connection con, Student student)
	{
		status=0;
		enrollmentId=student.getEnrollment();
		firstName=student.getFirstName();
		lastName=student.getLastName();
		branch=student.getBranch();
		query=InsertStudentDataByAdmin;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, firstName);
			statement.setString(2, lastName);
			statement.setInt(3, branch);
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [insertStudentDataByAdmin(Connection con, Student student)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					
					System.out.println("DB Statement has not closed for method [insertStudentDataByAdmin(Connection con, Student student)]");
					e.printStackTrace();
				}
			}
		}
		return status;
	}
	
	//Update student branch by id
	public static int updateBranchNameById(Connection con, int id,int branch)
	{
		status=0;
		query=UpdateBranchNameById;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1,branch);
			statement.setInt(2, id);
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [updateBranchNameById(Connection con, String id,String branch)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println("updateBranchNameById(Connection con, String id,String branch)");
					e.printStackTrace();
				}
			}
		}
		return status;
	}
	
	//Update student password
	public static int isPasswordUpdated(Connection con,Student student)
	{
		status=0;
		password=student.getPassword();
		id=student.getEnrollment();
		query=UpdatePasswordById;
		try {
			
			statement=con.prepareStatement(query);
			statement.setString(1, password);
			statement.setString(2, id);
			status=statement.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("Exception in method [isPasswordUpdated(Connection con,Student student)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e){
					System.out.println("DB Statement has not closed for method [isPasswordUpdated(Connection con,Student student)]");
					e.printStackTrace();
				}
				
			}
		}
		return status;
		
	}
	
	//Update password by id and old password and also updating login FirstLogin to true.
	public static int isPasswordUpdated(Connection con,String oldpassword,Student student)
	{
		
		status=0;
		password=student.getPassword();
		id=student.getEnrollment();
		query=UpdatePasswordByIdAndOldpassword;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, password);
			statement.setString(2, id);
			statement.setString(3, oldpassword);
			status=statement.executeUpdate();
			if(status>0)
			{
				query=UpdateFirstLogin;
				statement=con.prepareStatement(query);
				statement.setString(1, id);
				statement.executeUpdate();
			}
		
		} catch (SQLException e) {
			System.out.println("Exception in method [isPasswordUpdated(Connection con,String oldpassword,Student student)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e){
					System.out.println("DB Statement has not closed for method [isPasswordUpdated(Connection con,String oldpassword,Student student)]");
					e.printStackTrace();
				}
				
			}
		}
		return status;
		
	}
	
	//Update student details by id
	public static int updateStudentDetailsById(Connection con,Student student)
	{
		id=student.getEnrollment();
		status=0;
		firstName=student.getFirstName();
		lastName=student.getLastName();
		email=student.getEmail();
		phone=student.getPhone();
		query=UpdateStudentDetailsById;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, firstName);
			statement.setString(2, lastName);
			statement.setString(3, email);
			statement.setString(4, phone);
			statement.setString(5, id);
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [updateStudentDetailsById(Connection con,Student student)]");
			e.printStackTrace();
		}
		finally
		{
			if(statement!=null)
			{
				try {
					statement.close();
				} catch (SQLException e) {
					System.out.println("DB Statement has not closed for method [updateStudentDetailsById(Connection con,Student student)]");
					e.printStackTrace();
				}
			}
		}
		return status;
		
		
	}
	
	//Validating student first login.
	public static boolean isFirstLogin(Connection con, Student student)
	{
		valid=false;
		id=student.getEnrollment();
		query=SelectStudentDetailsById;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, id);
			result=statement.executeQuery();
			result.next();
			valid=result.getBoolean("FirstLogin");
		} catch (SQLException e) {
			System.out.println("Exception in method [isFirstLogin(Connection con, Student student)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
				{
					statement.close();
				}
				if(result!=null)
				{
					result.close();
				}
				
			}catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [isFirstLogin(Connection con, Student student)]");
			}
		}
		return valid;
	}

	//Validate student id and password
	public static boolean isValidStudent(Connection con, Student student)
	{
		valid=false;
		id=student.getEnrollment();
		password=student.getPassword();
		query=SelectStudentDetailsByIdAndPassword;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, id);
			statement.setString(2, password);
			result=statement.executeQuery();
			valid=result.next();
		} catch (SQLException e) {
			System.out.println("Exception in method [isValidStudent(Connection con, Student student)]");
			e.printStackTrace();
		}
		finally{
			
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [isValidStudent(Connection con, Student student)]");
				e.printStackTrace();
			}
			
			
		}
		return valid;
	}

	//Validate student id
	public static boolean isValidId(Connection con, String id)
	{
		valid=false;
		query=SelectStudentDetailsById;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, id);
			result=statement.executeQuery();
			valid=result.next();
		} catch (SQLException e) {
			System.out.println("Exception in method [isValidId(Connection con, String id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [isValidId(Connection con, String id)]");
				e.printStackTrace();
			}
		}
		return valid;
		
	}
	
}
