package com.validation;

import com.inteface.Validation;

public class LoginValidation implements Validation{

	public boolean isRollNumberValid(String name)
	{
		if(name==null || name.equals(BLANK)|| !(name.matches(REGX_ROLLNUMBER)))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public boolean isUserNameValid(String name)
	{
		if(name==null || name.equals(BLANK)|| !(name.matches(REGX_NAME)))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public boolean isPasswordValid(String password)
	{
		if(password==null || password.equals(BLANK))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
}
