package com.validation;

import com.inteface.Validation;

public class UpdateProfileValidation implements Validation {

	
	public boolean isNameValid(String name)
	{
		if(name==null || name.equals(BLANK)|| !(name.matches(REGX_NAME)))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	

	public boolean isEmailValid(String email)
	{
		if(email==null || email.equals(BLANK)|| !(email.matches(REGX_EMAIL)))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	
	public boolean isPhoneValid(String phone)
	{
		if(phone==null || phone.equals(BLANK)|| !(phone.matches(REGX_PHONE)))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
}
