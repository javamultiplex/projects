function removeAllOptions()
{
	
	var length1=document.test.subject.length;
	var length2=document.test.testtitle.length;
	for(var i=length1;i>=0;i--)
		{
		   document.test.subject.options[i]=null;
		}
	for(var i=length2;i>=0;i--)
	{
	   document.test.testtitle.options[i]=null;
	}
	document.getElementById("testviewslot").innerHTML="";
}

function addoptions(key,value)
{

    var ct1=document.createElement("OPTION");
    ct1.text=value;
    ct1.value=key;
    document.test.subject.options.add(ct1);

}
function removetestoptions()
{
	var length=document.test.testtitle.length;
	
	for(var i=length;i>=0;i--)
	{
	   document.test.testtitle.options[i]=null;
	}
	document.getElementById("testviewslot").innerHTML="";
}

function addtestoptions(key,value)
{

    var ct1=document.createElement("OPTION");
    ct1.text=value;
    ct1.value=key;
    document.test.testtitle.options.add(ct1);

}

function removetestdetailoptions()
{
	document.getElementById("testviewslot").innerHTML="";
}

