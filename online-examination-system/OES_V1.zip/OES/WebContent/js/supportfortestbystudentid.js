function removeAllOptions()
{
	var length=document.marks.test.length;
	for(var i=length;i>=0;i--)
		{
		   document.marks.test.options[i]=null;
		}
	document.getElementById("marksviewslot").innerHTML="";
}
function addoptions(key,value)
{

    var ct1=document.createElement("OPTION");
    ct1.text=value;
    ct1.value=key;
    document.marks.test.options.add(ct1);

}

function removemarksdetailoptions()
{
	document.getElementById("marksviewslot").innerHTML="";
}