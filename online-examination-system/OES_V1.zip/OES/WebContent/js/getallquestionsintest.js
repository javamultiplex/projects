function sendTestInfo(test)
{
	var url="GetQuestionFromTestDetails?id="+test;
	xhtp=handle();
	xhtp.onreadystatechange=getTestdetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getTestdetailsInfo()
{
	removequestionoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		
		z=0;
		 var r1=xhtp.responseXML.documentElement;
        var r2 =r1.getElementsByTagName("question")[z];
        var key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
        var value=r2.getElementsByTagName("number")[0].childNodes[0].nodeValue;

        while(key!=null && value!=null)
        {
                addquestionoptions(key,value);
                z++
                r2 =r1.getElementsByTagName("question")[z];
                key=r2.getElementsByTagName("id")[0].childNodes[0].nodeValue;
                value=r2.getElementsByTagName("number")[0].childNodes[0].nodeValue;
        }
	
		
	}
	
}