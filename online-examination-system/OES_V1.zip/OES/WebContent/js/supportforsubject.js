function removeAllOptions()
{
	var length=document.test.subject.length;
	for(var i=length;i>=0;i--)
		{
		   document.test.subject.options[i]=null;
		}
	
}
function addoptions(key,value)
{

    var ct1=document.createElement("OPTION");
    ct1.text=value;
    ct1.value=key;
    document.test.subject.options.add(ct1);

}