function sendStudentInfoForUpdation(student)
{
	var url="UpdateStudentBranchView?id="+student;
	xhtp=handle();
	xhtp.onreadystatechange=getStudentDetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getStudentDetailsInfo()
{
	removestudentdetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("viewstudentslot").innerHTML=xhtp.responseText;
	}
}