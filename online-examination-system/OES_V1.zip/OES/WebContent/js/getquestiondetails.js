function sendQuestionInfo(question)
{
	var url="GetQuestionDetails?id="+question;
	xhtp=handle();
	xhtp.onreadystatechange=getQuestiondetailsInfo;
	xhtp.open("GET",url,true);
	xhtp.send();
}

function getQuestiondetailsInfo()
{
	removequestiondetailoptions();
	if(xhtp.readyState==4 && xhtp.status==200)
	{
		document.getElementById("questionviewslot").innerHTML=xhtp.responseText;
	}
	
}