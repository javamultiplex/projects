function removestudentdetailoptions()
{
	
	document.getElementById("viewstudentslot").innerHTML="";
	
}