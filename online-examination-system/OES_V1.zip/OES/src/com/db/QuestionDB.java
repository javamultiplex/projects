package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inteface.DBQuery;
import com.pojo.Question;
import com.variables.DBClassVariables;

public class QuestionDB extends DBClassVariables implements DBQuery{
	
	//Insert single choice question details and update number of questions in test detail table.
	public static int insertSingleChoiceQuestionDetails(Connection con,Question ques,int id)
	{
		question=ques.getQuestion();
		status=0;
		status1=0;
		option1=ques.getOption1();
		option2=ques.getOption2();
		option3=ques.getOption3();
		option4=ques.getOption4();
		answer=ques.getSingleAnswer();
		query=InsertSingleChoiceQuestionDetails;
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, question);
			statement.setString(2, option1);
			statement.setString(3, option2);
			statement.setString(4, option3);
			statement.setString(5, option4);
			statement.setString(6, answer);
			statement.setInt(7, id);
			status1=statement.executeUpdate();
			if(status1>0)
			{
				query=SelectTestDetailsByTestID;
				statement=con.prepareStatement(query);
				statement.setInt(1, id);
				result=statement.executeQuery();
				if(result.next())
				{
					numberOfQuestions=result.getInt("Questions");
					numberOfQuestions++;
					
					query=UpdateNumberOfQuestionsBasedOnTestID;
					statement=con.prepareStatement(query);
					statement.setInt(1, numberOfQuestions);
					statement.setInt(2, id);
					status=statement.executeUpdate();
					
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in method [insertSingleChoiceQuestionDetails(Connection con,Question ques,int id)]");
			e.printStackTrace();
		}
		finally
		{
			
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [insertSingleChoiceQuestionDetails(Connection con,Question ques,int id)]");
				e.printStackTrace();
			}
			
		}
		return status;
	}
	
	//Insert true/false type questions and update number of questions in test details table.
	public static int insertTrueFalseQuestionDetails(Connection con,Question ques,int id)
	{
		query=InsertTrueFalseQuestionDetails;
		status=0;
		status1=0;
		question=ques.getQuestion();
		answer=ques.getBooleanAnswer();
		try {
			statement=con.prepareStatement(query);
			statement.setString(1, question);
			statement.setString(2, answer);
			statement.setInt(3, id);
			status1=statement.executeUpdate();
			if(status1>0)
			{
				query=SelectTestDetailsByTestID;
				statement=con.prepareStatement(query);
				statement.setInt(1, id);
				result=statement.executeQuery();
				if(result.next())
				{
					numberOfQuestions=result.getInt("Questions");
					numberOfQuestions++;
					
					query=UpdateNumberOfQuestionsBasedOnTestID;
					statement=con.prepareStatement(query);
					statement.setInt(1, numberOfQuestions);
					statement.setInt(2, id);
					status=statement.executeUpdate();
				}
				
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in method [insertTrueFalseQuestionDetails(Connection con,Question ques,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [insertTrueFalseQuestionDetails(Connection con,Question ques,int id)]");
				e.printStackTrace();
			}
			
		}
		return status;
	}
	
	//Insert multi choice type questions, update answers table and number of questions in test details table.
	public static int insertMultiChoiceQuestionDetails(Connection con,Question ques,int id)
	{
		status=0;
		status1=0;
		status2=0;
		question=ques.getQuestion();
		option1=ques.getOption1();
		option2=ques.getOption2();
		option3=ques.getOption3();
		option4=ques.getOption4();
		query=InsertMultiChoiceQuestionDetails;
		try {
			statement=con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
			statement.setString(1, question);
			statement.setString(2, option1);
			statement.setString(3, option2);
			statement.setString(4, option3);
			statement.setString(5, option4);
			statement.setInt(6, id);
			statement.executeUpdate();
			result=statement.getGeneratedKeys();
			if(result.next())
			{
				status1=result.getInt(1);
					if(status1>0)
					{
						query=InsertMultiChoiceAnswers;
						statement=con.prepareStatement(query);
						answers=ques.getMultiAnswer();
						for(String ans:answers)
						{
							statement.setString(1, ans);
							statement.setInt(2, status1);
							status2=statement.executeUpdate();
						}
						
						if(status2>0)
						{
								query=SelectTestDetailsByTestID;
								statement=con.prepareStatement(query);
								statement.setInt(1, id);
								result=statement.executeQuery();
								if(result.next())
								{
									numberOfQuestions=result.getInt("Questions");
									numberOfQuestions++;
									
									query=UpdateNumberOfQuestionsBasedOnTestID;
									statement=con.prepareStatement(query);
									statement.setInt(1, numberOfQuestions);
									statement.setInt(2, id);
									status=statement.executeUpdate();
									
									
								}
						}
				
					}
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in method [insertMultiChoiceQuestionDetails(Connection con,Question ques,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [insertMultiChoiceQuestionDetails(Connection con,Question ques,int id)]");
				e.printStackTrace();
			}
		}
		return status;
	}
	
	//Get true/false type question details by question id.
	public static List<String> getTrueFalseQuestionsDetails(Connection con,int id)
	{
		query=SelectFromTrueFalseQuestions;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			questionDetail=new ArrayList<String>();
			result=statement.executeQuery();
			while(result.next())
			{
				questionDetail.add(result.getString("Question"));
				questionDetail.add(result.getString("Answer"));
			}
		} catch (SQLException e){
			System.out.println("Exception in method [getTrueFalseQuestionsDetails(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getTrueFalseQuestionsDetails(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return questionDetail;
	}
	
	//Get single choice question details by question id.
	public static List<String> getSingleChoiceQuestionsDetails(Connection con,int id)
	{
		query=SelectFromSingleChoiceQuestions;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			questionDetail=new ArrayList<String>();
			result=statement.executeQuery();
			while(result.next())
			{
				
				questionDetail.add(result.getString("Question"));
				questionDetail.add(result.getString("Option1"));
				questionDetail.add(result.getString("Option2"));
				questionDetail.add(result.getString("Option3"));
				questionDetail.add(result.getString("Option4"));
				questionDetail.add(result.getString("Answer"));
			}
		} catch (SQLException e){
			System.out.println("Exception in method [getSingleChoiceQuestionsDetails(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getSingleChoiceQuestionsDetails(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return questionDetail;
	}
	
	//Get multi choice question details by question id.
	public static List<String> getMultiChoiceQuestionsDetails(Connection con,int id)
	{
		query=SelectFromMultiChoiceQuestions;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, id);
			questionDetail=new ArrayList<String>();
			result=statement.executeQuery();
			while(result.next())
			{
				questionDetail.add(result.getString("Question"));
				questionDetail.add(result.getString("Option1"));
				questionDetail.add(result.getString("Option2"));
				questionDetail.add(result.getString("Option3"));
				questionDetail.add(result.getString("Option4"));
				query=SelectFromAnswersOfMultiChoiceQuestions;
				statement=con.prepareStatement(query);
				statement.setInt(1, id);
				result=statement.executeQuery();
				while(result.next())
				{
					questionDetail.add(result.getString("Answer"));
				}
			}
		} catch (SQLException e){
			System.out.println("Exception in method [getMultiChoiceQuestionsDetails(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getMultiChoiceQuestionsDetails(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return questionDetail;
	}

	//Get question id of true/false type questions.
	public static List<String> getTrueFalseQuestionsIDByTestID(Connection con,int id)
	{
		query=SelectQuestionIDFromTrueFalseQuestions;
		try {
			statement=con.prepareStatement(query);
			list=new ArrayList<String>();
			statement.setInt(1, id);
			result=statement.executeQuery();
			while(result.next())
			{
				list.add(String.valueOf(result.getInt("QuestionID")));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getTrueFalseQuestionsIDByTestID(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getTrueFalseQuestionsIDByTestID(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//Get question id of single choice questions.
	public static List<String> getSingleChoiceQuestionsIDByTestID(Connection con,int id)
	{
		query=SelectQuestionIDFromSingleChoiceQuestions;
		try {
			statement=con.prepareStatement(query);
			list=new ArrayList<String>();
			statement.setInt(1, id);
			result=statement.executeQuery();
			while(result.next())
			{
				list.add(String.valueOf(result.getInt("QuestionID")));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getSingleChoiceQuestionsIDByTestID(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getSingleChoiceQuestionsIDByTestID(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//Get question id of multi choice questions.
	public static List<String> getMultiChoiceQuestionsIDByTestID(Connection con,int id)
	{
		query=SelectQuestionIDFromMultiChoiceQuestions;
		try {
			statement=con.prepareStatement(query);
			list=new ArrayList<String>();
			statement.setInt(1, id);
			result=statement.executeQuery();
			while(result.next())
			{
				list.add(String.valueOf(result.getInt("QuestionID")));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getMultiChoiceQuestionsIDByTestID(Connection con,int id)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement and Resultset has not closed for method [getMultiChoiceQuestionsIDByTestID(Connection con,int id)]");
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//Delete true/false type questions and updating number of question in test details table.
	public static int deleteTrueFalseTypeQuestions(Connection con,int questionID,int testID)
	{
		status=0;
		query=DeleteTrueFalseTypeQuestions;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, questionID);
			status1=statement.executeUpdate();
			if(status1>0)
			{
				query=SelectTestDetailsByTestID;
				statement=con.prepareStatement(query);
				statement.setInt(1, testID);
				result=statement.executeQuery();
				if(result.next())
				{
					numberOfQuestions=result.getInt("Questions");
					numberOfQuestions--;
					
					query=UpdateNumberOfQuestionsBasedOnTestID;
					statement=con.prepareStatement(query);
					statement.setInt(1, numberOfQuestions);
					statement.setInt(2, testID);
					status=statement.executeUpdate();
				}
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [deleteTrueFalseTypeQuestions(Connection con,int questionID,int testID)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
			
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
				
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [deleteTrueFalseTypeQuestions(Connection con,int questionID,int testID)]");
				e.printStackTrace();
			}
		}
		return status;
	}
	
	
	//Delete multi choice questions and updating number of question in test details table.
		public static int deleteMultiChoiceQuestions(Connection con,int questionID,int testID)
		{
			query=DeleteMultiChoiceQuestions;
			status=0;
			status1=0;
			try {
				statement=con.prepareStatement(query);
				statement.setInt(1, questionID);
				status1=statement.executeUpdate();
				if(status1>0)
				{
					query=SelectTestDetailsByTestID;
					statement=con.prepareStatement(query);
					statement.setInt(1, testID);
					result=statement.executeQuery();
					if(result.next())
					{
						numberOfQuestions=result.getInt("Questions");
						numberOfQuestions--;
						
						query=UpdateNumberOfQuestionsBasedOnTestID;
						statement=con.prepareStatement(query);
						statement.setInt(1, numberOfQuestions);
						statement.setInt(2, testID);
						status=statement.executeUpdate();
					}
				}
			} catch (SQLException e) {
				System.out.println("Exception in method [deleteMultiChoiceQuestions(Connection con,int questionID,int testID)]");
				e.printStackTrace();
			}
			finally
			{
				try
				{
				
					if(statement!=null)
						statement.close();
					if(result!=null)
						result.close();
					
				}
				catch(SQLException e)
				{
					System.out.println("DB Statement or Resultset has not closed for method [deleteMultiChoiceQuestions(Connection con,int questionID,int testID)]");
					e.printStackTrace();
				}
			}
			return status;
		}
	
		
		//Delete single choice questions and updating number of question in test details table.
				public static int deleteSingleChoiceQuestions(Connection con,int questionID,int testID)
				{
					query=DeleteSingleChoiceQuestions;
					status=0;
					status1=0;
					try {
						statement=con.prepareStatement(query);
						statement.setInt(1, questionID);
						status1=statement.executeUpdate();
						if(status1>0)
						{
							query=SelectTestDetailsByTestID;
							statement=con.prepareStatement(query);
							statement.setInt(1, testID);
							result=statement.executeQuery();
							if(result.next())
							{
								numberOfQuestions=result.getInt("Questions");
								numberOfQuestions--;
								
								query=UpdateNumberOfQuestionsBasedOnTestID;
								statement=con.prepareStatement(query);
								statement.setInt(1, numberOfQuestions);
								statement.setInt(2, testID);
								status=statement.executeUpdate();
							}
						}
					} catch (SQLException e) {
						System.out.println("Exception in method [deleteSingleChoiceQuestions(Connection con,int questionID,int testID)]");
						e.printStackTrace();
					}
					finally
					{
						try
						{
						
							if(statement!=null)
								statement.close();
							if(result!=null)
								result.close();
							
						}
						catch(SQLException e)
						{
							System.out.println("DB Statement or Resultset has not closed for method [deleteSingleChoiceQuestions(Connection con,int questionID,int testID)]");
							e.printStackTrace();
						}
					}
					return status;
				}
				
		//Update true/false type questions		
		public static int updateTrueFalseQuestiions(Connection con,Question ques,int QuestionID)
		{
			question=ques.getQuestion();
			answer=ques.getBooleanAnswer();
			status=0;
			query=UpdateTrueFalseQuestions;
			try {
				statement=con.prepareStatement(query);
				statement.setString(1, question);
				statement.setString(2, answer);
				statement.setInt(3, QuestionID);
				status=statement.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Exception in method [updateTrueFalseQuestiions(Connection con,Question ques,int QuestionID)]");
				e.printStackTrace();
			}finally {
				if(statement!=null)
				{
					try {
						statement.close();
					} catch (SQLException e) {
						System.out.println("DB statement has not closed for method [updateTrueFalseQuestiions(Connection con,Question ques,int QuestionID)]");
						e.printStackTrace();
					}
				}
			}
			return status;
		}
		
		
		//Update single choice questions		
				public static int updateSingleChoiceQuestiions(Connection con,Question ques,int QuestionID)
				{
					question=ques.getQuestion();
					status=0;
					option1=ques.getOption1();
					option2=ques.getOption2();
					option3=ques.getOption3();
					option4=ques.getOption4();
					answer=ques.getSingleAnswer();
					query=UpdateSingleChoiceQuestions;
					try {
						statement=con.prepareStatement(query);
						statement.setString(1, question);
						statement.setString(2, option1);
						statement.setString(3, option2);
						statement.setString(4, option3);
						statement.setString(5, option4);
						statement.setString(6, answer);
						statement.setInt(7, QuestionID);
						status=statement.executeUpdate();
					} catch (SQLException e) {
						System.out.println("Exception in method [updateSingleChoiceQuestiions(Connection con,Question ques,int QuestionID)]");
						e.printStackTrace();
					}finally {
						if(statement!=null)
						{
							try {
								statement.close();
							} catch (SQLException e) {
								System.out.println("DB statement has not closed for method [updateSingleChoiceQuestiions(Connection con,Question ques,int QuestionID)]");
								e.printStackTrace();
							}
						}
					}
					return status;
				}
				
				//Update multi choice questions->delete question and insert again		
				public static int updateMultiChoiceQuestiions(Connection con,Question ques,int testID, int questionID)
				{
					status=0;
					status1=0;
					status=deleteMultiChoiceQuestions(con, questionID, testID);
					if(status>0)
					{
						status1=insertMultiChoiceQuestionDetails(con, ques,testID);
					}
					return status1;
				}
				
				//Get questions based on its type.
				public static List<List<String>> getQuestionsBasedOnItsType(Connection con,int testId,String questionType)
				{
					List<List<String>> questionDetail=null;
					if(questionType.equalsIgnoreCase("single"))
					{
						questionDetail=getSingleChoiceQuestions(con,testId);
					}
					else if(questionType.equalsIgnoreCase("multi"))
					{
						questionDetail=getMultiChoiceQuestions(con,testId);
					}
					else if(questionType.equalsIgnoreCase("truefalse"))
					{
						questionDetail=getTrueFalseQuestions(con,testId);
					}
					return questionDetail;
				}

				//Get true false questions based on testId.
				public static List<List<String>> getTrueFalseQuestions(Connection con, int testId) {
					
					query=SelectTrueFalseQuestions;
					try {
						questions=new ArrayList<List<String>>();
						statement=con.prepareStatement(query);
						statement.setInt(1, testId);
						result=statement.executeQuery();
						while(result.next())
						{
							list=new ArrayList<String>();
							list.add(String.valueOf(result.getInt("QuestionID")));
							list.add(result.getString("Question"));
							list.add(result.getString("Answer"));
							questions.add(list);
						}
					} catch (SQLException e) {
						System.out.println("Exception in method [getTrueFalseQuestions(Connection con, int testId)]");
						e.printStackTrace();
					}
					finally
					{
						try
						{
							if(statement!=null)
								statement.close();
							if(result!=null)
								result.close();
						}
						catch(SQLException e)
						{
							System.out.println("DB Statement or Resultset has not closed for method [getTrueFalseQuestions(Connection con, int testId)]");
						}
					}
					return questions;
				}
				
				//Get multi choice questions based on testId.
				public static List<List<String>> getMultiChoiceQuestions(Connection con, int testId) {
					
					query=SelectMultiChoiceQuestions;
					ResultSet result1=null;
					try {
						questions=new ArrayList<List<String>>();
						statement=con.prepareStatement(query);
						statement.setInt(1, testId);
						result=statement.executeQuery();
						while(result.next())
						{
							list=new ArrayList<String>();
							list.add(String.valueOf(result.getInt("QuestionID")));
							list.add(result.getString("Question"));
							list.add(result.getString("Option1"));
							list.add(result.getString("Option2"));
							list.add(result.getString("Option3"));
							list.add(result.getString("Option4"));
							query=SelectFromAnswersOfMultiChoiceQuestions;
							statement=con.prepareStatement(query);
							statement.setInt(1, result.getInt("QuestionID"));
							result1=statement.executeQuery();
							while(result1.next())
							{
								list.add(result1.getString("Answer"));
							}
							questions.add(list);
						}
					} catch (SQLException e) {
						System.out.println("Exception in method [getMultiChoiceQuestions(Connection con, int testId)]");
						e.printStackTrace();
					}
					finally
					{
						try
						{
							if(statement!=null)
								statement.close();
							if(result!=null)
								result.close();
							if(result1!=null)
								result1.close();
						}
						catch(SQLException e)
						{
							System.out.println("DB Statement or Resultset has not closed for method [getMultiChoiceQuestions(Connection con, int testId)]");
						}
					}
					return questions;
				}

				//Get Single choice questions based on testId.
				public static List<List<String>> getSingleChoiceQuestions(Connection con, int testId) {
					
					query=SelectSingleChoiceQuestions;
					try {
						questions=new ArrayList<List<String>>();
						statement=con.prepareStatement(query);
						statement.setInt(1, testId);
						result=statement.executeQuery();
						while(result.next())
						{
							list=new ArrayList<String>();
							list.add(String.valueOf(result.getInt("QuestionID")));
							list.add(result.getString("Question"));
							list.add(result.getString("Option1"));
							list.add(result.getString("Option2"));
							list.add(result.getString("Option3"));
							list.add(result.getString("Option4"));
							list.add(result.getString("Answer"));
							questions.add(list);
						}
					} catch (SQLException e) {
						System.out.println("Exception in method [getSingleChoiceQuestions(Connection con, int testId)]");
						e.printStackTrace();
					}
					finally
					{
						try
						{
							if(statement!=null)
								statement.close();
							if(result!=null)
								result.close();
						}
						catch(SQLException e)
						{
							System.out.println("DB Statement or Resultset has not closed for method [getSingleChoiceQuestions(Connection con, int testId)]");
						}
					}
					return questions;
				}
		
}
