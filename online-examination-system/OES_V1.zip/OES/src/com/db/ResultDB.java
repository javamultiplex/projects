package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inteface.DBQuery;
import com.pojo.Result;
import com.variables.DBClassVariables;

public class ResultDB extends DBClassVariables implements DBQuery{

	public static boolean isTestIdAndStudentIdExistInResultsTable(Connection con,int testId,int studentId)
	{
		query=SelectResultIdFromResultsTable;
		valid=false;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, studentId);
			statement.setInt(2, testId);
			result=statement.executeQuery();
			if(result.next())
			{
				valid=true;
			}
			else
			{
				valid=false;
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [isTestIdAndStudentIdExistInResultsTable(Connection con,int testId,int studentId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [isTestIdAndStudentIdExistInResultsTable(Connection con,int testId,int studentId)]");
				e.printStackTrace();
			}
			
		}
		return valid;
	}
	
	public static int insertDetailsInResultsAndTestAttemptsTable(Connection con,int studentId,int testId,Result res)
	{
		query=InsertResultDetailsIntoResultsTable;
		status=0;
		try {
			statement=con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
			statement.setInt(1, studentId);
			statement.setInt(2, testId);
			statement.executeUpdate();
			result=statement.getGeneratedKeys();
			if(result.next())
			{
				resultId=result.getInt(1);
				status=insertDetailsInTestAttemptsTable(con,res,resultId);
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [insertDetailsInResultsAndTestAttemptsTable(Connection con,int studentId,int testId,Result res)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [insertDetailsInResultsAndTestAttemptsTable(Connection con,int studentId,int testId,Result res)]");
				e.printStackTrace();
			}
			
		}
		return status;
	}

	public static int insertDetailsInTestAttemptsTable(Connection con, Result res, int resultId) {
		
		totalMarks=res.getTotalMarks();
		studentMarks=res.getStudentMarks();
		grade=res.getGrade();
		percentage=res.getPercentage();
		status=0;
		query=InsertResultDetailsIntoTestAttemptsTable;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, resultId);
			statement.setInt(2, totalMarks);
			statement.setInt(3, studentMarks);
			statement.setString(4, String.valueOf(percentage)+"%");
			statement.setString(5, String.valueOf(grade));
			if(percentage>=33)
			{
				statement.setString(6, "Pass");
			}
			else
			{
				statement.setString(6, "Fail");
			}
			status=statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Exception in method [insertDetailsInTestAttemptsTable(Connection con, Result res, int resultId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement has not closed for method [insertDetailsInTestAttemptsTable(Connection con, Result res, int resultId)]");
				e.printStackTrace();
			}
			
		}
		return status;
	}
	
	public static int getResultId(Connection con,int testId,int studentId)
	{
		query=SelectResultIdFromResultsTable;
		resultId=0;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, studentId);
			statement.setInt(2, testId);
			result=statement.executeQuery();
			if(result.next())
			{
				resultId=result.getInt("result_id");
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getResultId(Connection con,int testId,int studentId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getResultId(Connection con,int testId,int studentId)]");
				e.printStackTrace();
			}
			
		}
		return resultId;
	}
	
	public static List<List<String>> getAttempsDetailsBasedOnResultId(Connection con,int resultId)
	{
		query=SelectTestAttemptsDetailsByResultId;
		try {
			attempts=new ArrayList<List<String>>();
			statement=con.prepareStatement(query);
			statement.setInt(1, resultId);
			result=statement.executeQuery();
			while(result.next())
			{
				list=new ArrayList<String>();
				list.add(String.valueOf(result.getInt("id")));
				list.add(String.valueOf(result.getInt("test_marks")));
				list.add(String.valueOf(result.getInt("student_marks")));
				list.add(result.getString("percentage"));
				list.add(result.getString("grade"));
				list.add(result.getString("status"));
				attempts.add(list);
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getAttempsDetailsBasedOnResultId(Connection con,int resultId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getAttempsDetailsBasedOnResultId(Connection con,int resultId)]");
				e.printStackTrace();
			}
			
		}
		return attempts;
	}
	
	public static List<String> getResultIdByTestId(Connection con,int testId)
	{
		query=SelectResultIdByTestId;
		list=new ArrayList<String>();
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, testId);
			result=statement.executeQuery();
			while(result.next())
			{
				list.add(String.valueOf(result.getInt("result_id")));
			}
		}catch (SQLException e) {
			System.out.println("Exception in method [getResultIdByTestId(Connection con,int testId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getResultIdByTestId(Connection con,int testId)]");
				e.printStackTrace();
			}
			
		}
		return list;
	}
	
	public static List<List<String>> getResultsWithMaxMarks(Connection con,List<String> results )
	{
		String inParameters=String.join(",", results);
		query="SELECT * FROM testattempts a INNER JOIN(SELECT result_id,MAX(student_marks) student_marks FROM testattempts WHERE result_id IN("+inParameters+") GROUP BY result_id) b on a.result_id=b.result_id AND a.student_marks=b.student_marks ORDER BY a.student_marks DESC";
		attempts=new ArrayList<List<String>>();
		try {
			statement=con.prepareStatement(query);
			result=statement.executeQuery();
			while(result.next())
			{
				list=new ArrayList<String>();
				list.add(String.valueOf(result.getInt("result_id")));
				list.add(String.valueOf(result.getInt("test_marks")));
				list.add(String.valueOf(result.getInt("student_marks")));
				list.add(result.getString("percentage"));
				list.add(result.getString("grade"));
				list.add(result.getString("status"));
				attempts.add(list);
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getResultsWithMaxMarks(Connection con)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getResultsWithMaxMarks(Connection con)]");
				e.printStackTrace();
			}
			
		}
		return attempts;
		
	}
	
	public static String getStudentIdByResultId(Connection con,int resultId)
	{
		query=SelectStudentIdByResultId;
		enrollmentId=null;
		try {
			statement=con.prepareStatement(query);
			statement.setInt(1, resultId);
			result=statement.executeQuery();
			if(result.next())
			{
				enrollmentId=String.valueOf(result.getInt("student_id"));
			}
		} catch (SQLException e) {
			System.out.println("Exception in method [getStudentIdByResultId(Connection con,int resultId)]");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement!=null)
					statement.close();
				if(result!=null)
					result.close();
			}
			catch(SQLException e)
			{
				System.out.println("DB Statement or Resultset has not closed for method [getStudentIdByResultId(Connection con,int resultId)]");
				e.printStackTrace();
			}
			
		}
		return enrollmentId;
		
	}
}
	
