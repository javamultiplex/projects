package com.inteface;

public interface Constants {
	
	public static String SINGLE="single";
	public static String TRUEORFALSE="truefalse";
	public static String MULTI="multi";
	public static String HTML="text/html";
	public static String XML="text/xml";
	public static String TABLESTARTTAG="<table>";
	public static String TABLESTARTTAGWITHBORDER="<table border=1>";
	public static String TABLEENDTTAG="</table>";
	public static String TABLEROWSTARTTAG="<tr>";
	public static String TABLEROWENDTAG="</tr>";
	public static String TABLECELLSTARTTAG="<td>";
	public static String TABLECELLENDTAG="</td>";
	public static String TABLEHEADSTARTTAG="<th>";
	public static String TABLEHEADENDTAG="</th>";
	public static String QUESTIONSSTARTTAG="<questions>";
	public static String QUESTIONSENDTAG="</questions>";
	public static String QUESTIONSTARTTAG="<question>";
	public static String QUESTIONENDTAG="</question>";
	public static String IDSTARTTAG="<id>";
	public static String IDENDTAG="</id>";
	public static String NUMBERSTARTTAG="<number>";
	public static String NUMBERENDTAG="</number>";
	public static String SUBJECTSSTARTTAG="<subjects>";
	public static String SUBJECTSENDTAG="</subjects>";
	public static String SUBJECTSTARTTAG="<subject>";
	public static String SUBJECTENDTAG="</subject>";
	public static String TESTSSTARTTAG="<tests>";
	public static String TESTSENDTAG="</tests>";
	public static String TESTSTARTTAG="<test>";
	public static String TESTENDTAG="</test>";
}
