package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;

/**
 * Servlet implementation class EditProfileProcess
 */
@WebServlet("/EditProfileProcess")
public class EditProfileProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProfileProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(HTML);
		HttpSession session=request.getSession();
		String id=(String) session.getAttribute("id");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		Student student=new Student();
		student.setEnrollment(id);
		student.setFirstName(firstName);
		student.setLastName(lastName);
		student.setEmail(email);
		student.setPhone(phone);
		Connection con=DBConnection.getConnection();
		int status=StudentDB.updateStudentDetailsById(con, student);
		if(status>0)
		{
			response.sendRedirect("viewprofile.jsp");
		}
	
	}

}
