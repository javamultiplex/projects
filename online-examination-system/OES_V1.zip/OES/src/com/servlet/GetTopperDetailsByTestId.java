package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.ResultDB;
import com.db.StudentDB;
import com.inteface.Constants;
import com.utilities.JoinFirstNameAndLastName;


@WebServlet("/admin/GetTopperDetailsByTestId")
public class GetTopperDetailsByTestId extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
   
    public GetTopperDetailsByTestId() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		int testId=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		String studentId=null;
		List<String> studentDetails=null;
		List<String> resultId=ResultDB.getResultIdByTestId(con, testId);
		List<List<String>> results=ResultDB.getResultsWithMaxMarks(con,resultId);
		if(results.size()<1)
		{
			out.print("<p style='margin-left:120px;'><b>No student attempted this exam</b></p>");
		}
		else
		{
		out.print(TABLESTARTTAGWITHBORDER);
		out.print(TABLEROWSTARTTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Rank");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Roll Number");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Name");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Exam Marks");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Student Marks");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Percentage");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Grade");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEHEADSTARTTAG);
			out.print("Status");
		out.print(TABLEHEADENDTAG);
		out.print(TABLEROWENDTAG);
		
		int i=1;
		for(List<String> result:results)
		{
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			 	out.print(i);
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				studentId=ResultDB.getStudentIdByResultId(con, Integer.parseInt(result.get(0)));
				out.print(studentId);
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				studentDetails=StudentDB.getStudentDetailsById(con, Integer.parseInt(studentId));
				out.print(JoinFirstNameAndLastName.getFullName(studentDetails.get(0),studentDetails.get(1)));
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				out.print(result.get(1));
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				out.print(result.get(2));
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				out.print(result.get(3));
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				out.print(result.get(4));
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
				out.print(result.get(5));
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			i++;
				
		}
		out.print(TABLEENDTTAG);
		}
		out.close();
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
