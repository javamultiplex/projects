package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;

/**
 * Servlet implementation class UpdateQuestionDetailsView
 */
@WebServlet("/admin/UpdateQuestionDetailsView")
public class UpdateQuestionDetailsView extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateQuestionDetailsView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		String typeAndId=request.getParameter("id");
		String typeOfQuestion=null;
		int questionId=0;
		Connection con=DBConnection.getConnection();
		List<String> questionDetail=null;
		if(typeAndId.startsWith(TRUEORFALSE))
			typeOfQuestion=TRUEORFALSE;
		else if(typeAndId.startsWith(SINGLE))
			typeOfQuestion=SINGLE;
		else if(typeAndId.startsWith(MULTI))
			typeOfQuestion=MULTI;
		questionId=Integer.parseInt(typeAndId.substring(typeOfQuestion.length(), typeAndId.length()));
		
		if(typeOfQuestion.equals(TRUEORFALSE))
		{
			questionDetail=QuestionDB.getTrueFalseQuestionsDetails(con, questionId);
			out.println(TABLESTARTTAG);
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Question</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<textarea name='myquestion' style='width:300px;height:100px;'>"+questionDetail.get(0)+"</textarea>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Answer</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='answer' style='width:303px;' value='"+questionDetail.get(1)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			out.print(TABLEENDTTAG);
		}
		else if(typeOfQuestion.equals(SINGLE))
		{
			questionDetail=QuestionDB.getSingleChoiceQuestionsDetails(con, questionId);
			out.println(TABLESTARTTAG);
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Question</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<textarea name='myquestion' style='width:300px;height:100px;'>"+questionDetail.get(0)+"</textarea>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option1</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option1' style='width:303px;' value='"+questionDetail.get(1)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option2</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option2' style='width:303px;' value='"+questionDetail.get(2)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option3</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option3' style='width:303px;' value='"+questionDetail.get(3)+"'/>");;
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option4</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option4' style='width:303px;' value='"+questionDetail.get(4)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Answer</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='answer' style='width:303px;' value='"+questionDetail.get(5)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			out.print(TABLEENDTTAG);
		}
		else if(typeOfQuestion.equals(MULTI))
		{
			questionDetail=QuestionDB.getMultiChoiceQuestionsDetails(con, questionId);
			String answers="";
			
			out.println(TABLESTARTTAG);
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Question</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<textarea name='myquestion' style='width:300px;height:100px;'>"+questionDetail.get(0)+"</textarea>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option1</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option1' style='width:303px;' value='"+questionDetail.get(1)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option2</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option2' style='width:303px;' value='"+questionDetail.get(2)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option3</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option3' style='width:303px;' value='"+questionDetail.get(3)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Option4</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<input type='text' name='option4' style='width:303px;' value='"+questionDetail.get(4)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			
			out.print(TABLEROWSTARTTAG);
			out.print(TABLECELLSTARTTAG);
			out.print("<b>Answer/'s</b>");
			out.print(TABLECELLENDTAG);
			out.print(TABLECELLSTARTTAG);
					for(int j=5;j<questionDetail.size();j++)
					{
						answers+=questionDetail.get(j)+", ";
					}
					out.print("<input type='text' name='answer' style='width:303px;' value='"+answers.substring(0,answers.length()-2)+"'/>");
			out.print(TABLECELLENDTAG);
			out.print(TABLEROWENDTAG);
			out.print(TABLEENDTTAG);
			
		}
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
