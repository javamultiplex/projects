package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.pojo.Question;

/**
 * Servlet implementation class TrueFalseQuestionsProcess
 */
@WebServlet("/admin/TrueFalseQuestionsProcess")
public class TrueFalseQuestionsProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrueFalseQuestionsProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType(HTML);
		Question ques=new Question();
		String question=request.getParameter("question");
		String answer=request.getParameter("answer");
		int id=Integer.parseInt(request.getParameter("id"));
		ques.setQuestion(question);
		ques.setBooleanAnswer(answer);
		Connection con=DBConnection.getConnection();
		int status=QuestionDB.insertTrueFalseQuestionDetails(con, ques, id);
		if(status>0)
		{
			response.sendRedirect("truefalsequestions.jsp?message=success&testid="+id);
		}
		else
		{
			response.sendRedirect("truefalsequestions.jsp?message=fail&testid="+id);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
