package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;
import com.pojo.Question;

/**
 * Servlet implementation class MultiChoiceQuestionsProcess
 */
@WebServlet("/admin/MultiChoiceQuestionsProcess")
public class MultiChoiceQuestionsProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MultiChoiceQuestionsProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		Question ques=new Question();
		List<String> answers=new ArrayList<String>();
		String question=request.getParameter("question");
		String option1=request.getParameter("option1");
		String option2=request.getParameter("option2");
		String option3=request.getParameter("option3");
		String option4=request.getParameter("option4");
		String answer1=request.getParameter("answer1");
		String answer2=request.getParameter("answer2");
		String answer3=request.getParameter("answer3");
		String answer4=request.getParameter("answer4");
		int id=Integer.parseInt(request.getParameter("id"));
		if(answer1!=null)
			answers.add(answer1);
		if(answer2!=null)
			answers.add(answer2);
		if(answer3!=null)
			answers.add(answer3);
		if(answer4!=null)
			answers.add(answer4);
		ques.setQuestion(question);
		ques.setOption1(option1);
		ques.setOption2(option2);
		ques.setOption3(option3);
		ques.setOption4(option4);
		ques.setMultiAnswer(answers);
		
		Connection con=DBConnection.getConnection();
		int status=QuestionDB.insertMultiChoiceQuestionDetails(con, ques, id);
		if(status>0)
		{
			response.sendRedirect("multichoicequestions.jsp?message=success&testid="+id);
		}
		else
		{
			response.sendRedirect("multichoicequestions.jsp?message=fail&testid="+id);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
