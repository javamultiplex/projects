package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.db.ResultDB;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Result;
import com.utilities.FindGrade;
import com.utilities.FindPercentage;


@WebServlet("/GenerateResult")
public class GenerateResult extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;

    public GenerateResult() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType(HTML);
		HttpSession session=request.getSession();
		String questionType=request.getParameter("type");
		int studentId=Integer.parseInt((String)session.getAttribute("id"));
		int testId=Integer.parseInt(request.getParameter("testId"));
		Connection con=DBConnection.getConnection();
		List<String> testDetails=TestDB.getTestDetails(con, testId);
		List<List<String>> list=QuestionDB.getQuestionsBasedOnItsType(con, testId, questionType);
		int marksOfEachQuestion=Integer.parseInt(testDetails.get(3));
		int numberOfQuestions=Integer.parseInt(testDetails.get(1));
		int status=0;
		String answer=null;
		int i=0,marks=0,totalMarks=numberOfQuestions*marksOfEachQuestion;
		float percentage=0;
		char grade;
		if(questionType.equalsIgnoreCase(Constants.TRUEORFALSE))
		{
			i=1;
			marks=0;
			for(List<String> question:list)
			{
				answer=request.getParameter("nameQuestion"+i);
				if(answer.equals(question.get(2)))
				{
					marks+=marksOfEachQuestion;
				}
				i++;
			}
		}
		else if(questionType.equalsIgnoreCase(Constants.SINGLE))
		{
			i=1;
			marks=0;
			for(List<String> question:list)
			{
				answer=request.getParameter("nameQuestion"+i);
				if(answer.equals(question.get(6)))
				{
					marks+=marksOfEachQuestion;
				}
				i++;
			}
		}
		else if(questionType.equalsIgnoreCase(Constants.MULTI))
		{
			i=1;
			marks=0;
			String[] multiAnswers=null;
			List<String> myAnswers=new ArrayList<String>();
			List<String> correctAnswers=null;
			for(List<String> question:list)
			{
				correctAnswers=new ArrayList<String>();
				multiAnswers=request.getParameterValues("nameQuestion"+i);
				myAnswers=Arrays.asList(multiAnswers);
				for(int j=6;j<question.size();j++)
				{
					correctAnswers.add(question.get(j));
				}
				if(myAnswers.equals(correctAnswers))
				{
					marks+=marksOfEachQuestion;
				}
				i++;
			}
		}
		
	percentage=FindPercentage.getPercentange((float)marks,(float)totalMarks);
	grade=FindGrade.getGrade(percentage);
	Result result=new Result();
	result.setTotalMarks(totalMarks);
	result.setStudentMarks(marks);
	result.setPercentage((int)percentage);
	result.setGrade(grade);
	if(!ResultDB.isTestIdAndStudentIdExistInResultsTable(con, testId, studentId))
	{
		status=ResultDB.insertDetailsInResultsAndTestAttemptsTable(con, studentId, testId, result);
	}
	else
	{
		int resultId=ResultDB.getResultId(con, testId, studentId);
		status=ResultDB.insertDetailsInTestAttemptsTable(con, result, resultId);
	}
	session.setAttribute("marks", marks);
	session.setAttribute("totalMarks", totalMarks);
	session.setAttribute("percentage", (int)percentage);
	session.setAttribute("grade", grade);
	response.sendRedirect("result.jsp");
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
