package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;

/**
 * Servlet implementation class ForgetPasswordProcess
 */
@WebServlet("/ForgetPasswordProcess")
public class ForgetPasswordProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetPasswordProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		String status=request.getParameter("status");
		String id=request.getParameter("enrollmentId");
		String password=request.getParameter("password");
		Student student=new Student();
		student.setEnrollment(id);
		student.setPassword(password);
		Connection con=DBConnection.getConnection();
		int result=0;
		if(status.equals("false"))
		{
			String oldPassword=request.getParameter("oldpassword");
			result=StudentDB.isPasswordUpdated(con, oldPassword, student);
			if(result>0)
			{
				response.sendRedirect("index.jsp");
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("forgetpassword.jsp?id="+id);
				out.println("<center><h2>Please fill correct details!!</h2></center>");
				rd.include(request, response);
			}
		}
		else
		{
			result=StudentDB.isPasswordUpdated(con, student);
			if(result>0)
			{
				response.sendRedirect("index.jsp");
			}
		}
		out.close();
	}

}
