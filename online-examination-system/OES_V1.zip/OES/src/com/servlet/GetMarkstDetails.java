package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.ResultDB;
import com.inteface.Constants;


@WebServlet("/admin/GetMarkstDetails")
public class GetMarkstDetails extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    
    public GetMarkstDetails() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		String testIdWithStudentId=request.getParameter("testId");
		int testAndStudentIdSeprator=testIdWithStudentId.indexOf("S");
		int testId=Integer.parseInt(testIdWithStudentId.substring(0, testAndStudentIdSeprator));
		int studentId=Integer.parseInt(testIdWithStudentId.substring(testAndStudentIdSeprator+1,testIdWithStudentId.length()));
		Connection con=DBConnection.getConnection();
		int resultId=ResultDB.getResultId(con,testId,studentId);
		List<List<String>> testAttempts=ResultDB.getAttempsDetailsBasedOnResultId(con, resultId);
		if(testAttempts.size()<1)
		{
			out.print("<p style='margin-left:120px;'><b>Student not attempted test</b></p>");
		}
		else
		{
		out.println(TABLESTARTTAGWITHBORDER);
			out.print(TABLEROWSTARTTAG);
				out.print(TABLEHEADSTARTTAG);
					out.print("Attempt");
				out.print(TABLEHEADENDTAG);
				
				out.print(TABLEHEADSTARTTAG);
					out.print("Subject Marks");
				out.print(TABLEHEADENDTAG);
				
				out.print(TABLEHEADSTARTTAG);
					out.print("Student Marks");
				out.print(TABLEHEADENDTAG);
				
				out.print(TABLEHEADSTARTTAG);
					out.print("Percentage");
				out.print(TABLEHEADENDTAG);
				
				out.print(TABLEHEADSTARTTAG);
					out.print("Grade");
				out.print(TABLEHEADENDTAG);
				
				out.print(TABLEHEADSTARTTAG);
					out.print("Status");
				out.print(TABLEHEADENDTAG);
			out.println(TABLEROWENDTAG);
			int i=1;
			for(List<String> attempt:testAttempts)
			{
			out.print(TABLEROWSTARTTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(i);
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(attempt.get(1));
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(attempt.get(2));
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(attempt.get(3));
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(attempt.get(4));
				out.print(TABLECELLENDTAG);
				out.print(TABLECELLSTARTTAG);
					out.print(attempt.get(5));
				out.print(TABLECELLENDTAG);
			out.println(TABLEROWENDTAG);
			i++;
		}
		out.println(TABLEENDTTAG);
	}
		out.close();
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
