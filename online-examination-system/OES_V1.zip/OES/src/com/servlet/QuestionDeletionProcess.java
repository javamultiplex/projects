package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.QuestionDB;
import com.inteface.Constants;

/**
 * Servlet implementation class QuestionDeletionProcess
 */
@WebServlet("/admin/QuestionDeletionProcess")
public class QuestionDeletionProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionDeletionProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		String typeAndId=request.getParameter("question");
		int testID=Integer.parseInt(request.getParameter("testtitle"));
		String typeOfQuestion=null;
		int questionId=0,status=0;
		Connection con=DBConnection.getConnection();
		if(typeAndId.startsWith(TRUEORFALSE))
			typeOfQuestion=TRUEORFALSE;
		else if(typeAndId.startsWith(SINGLE))
			typeOfQuestion=SINGLE;
		else if(typeAndId.startsWith(MULTI))
			typeOfQuestion=MULTI;
		questionId=Integer.parseInt(typeAndId.substring(typeOfQuestion.length(), typeAndId.length()));
		if(typeOfQuestion.equals(TRUEORFALSE))
		{
			status=QuestionDB.deleteTrueFalseTypeQuestions(con, questionId, testID);
		}
		else if(typeOfQuestion.equals(SINGLE))
		{
			status=QuestionDB.deleteSingleChoiceQuestions(con, questionId, testID);
		}
		else if(typeOfQuestion.equals(MULTI))
		{
			status=QuestionDB.deleteMultiChoiceQuestions(con, questionId, testID);
		}
		if(status>0)
		{
			response.sendRedirect("deletequestion.jsp?message=success");
		}
		else
		{
			response.sendRedirect("deletequestion.jsp?message=fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
