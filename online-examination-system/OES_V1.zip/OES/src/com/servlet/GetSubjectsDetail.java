package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.SubjectDB;
import com.inteface.Constants;


@WebServlet("/admin/GetSubjectsDetail")
public class GetSubjectsDetail extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    
    public GetSubjectsDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType(XML);
		PrintWriter out=response.getWriter();
		Connection con=DBConnection.getConnection();
		int id=Integer.parseInt(request.getParameter("branch"));
		Map<Integer,String> map=SubjectDB.getSubjectDetails(con, id);
		Set<Entry<Integer,String>> set=map.entrySet();
		Iterator<Entry<Integer,String>> iterator=set.iterator();
		out.print(SUBJECTSSTARTTAG);
			out.print(SUBJECTSTARTTAG);
					out.print("<id>None</id>");
					out.print("<name>None</name>");
			out.print(SUBJECTENDTAG);
			while(iterator.hasNext())
			{
				Entry<Integer,String> entry=iterator.next();
				out.print(SUBJECTSTARTTAG);
				out.print("<id>"+entry.getKey()+"</id>");
				out.print("<name>"+entry.getValue()+"</name>");
				out.print(SUBJECTENDTAG);
				
			}
		out.print(SUBJECTSENDTAG);
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
