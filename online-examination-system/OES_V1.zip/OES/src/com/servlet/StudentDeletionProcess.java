package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;

/**
 * Servlet implementation class StudentDeletionProcess
 */
@WebServlet("/admin/StudentDeletionProcess")
public class StudentDeletionProcess extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentDeletionProcess() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(HTML);
		int id=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		int status=StudentDB.deleteStudentById(con, id);
		if(status>0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("deletestudent.jsp");
			request.setAttribute("message", "Student details has been deleted successfully!");
			rd.forward(request, response);
		}
		
	}

}
