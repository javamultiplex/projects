package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Test;

/**
 * Servlet implementation class CreateTest
 */
@WebServlet("/admin/CreateTest")
public class CreateTest extends HttpServlet implements Constants {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateTest() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType(HTML);
		Test test=new Test();
		String title=request.getParameter("title");
		String description=request.getParameter("description");
		int subjectID=Integer.parseInt(request.getParameter("subject"));
		String typeOfQuestion=request.getParameter("type");
		int marksOfEachQuestion=Integer.parseInt(request.getParameter("marks"));
		test.setTitle(title);
		test.setDescription(description);
		test.setSubjectId(subjectID);
		test.setTypeOfQuestion(typeOfQuestion);
		test.setMarks(marksOfEachQuestion);
		Connection con=DBConnection.getConnection();
		int status=TestDB.insertTestDetails(con, test);
		if(status>0)
		{
			if(typeOfQuestion.equals(SINGLE))
			{
				response.sendRedirect("singlechoicequestions.jsp?testid="+status);
			}
			else if(typeOfQuestion.equals(MULTI))
			{
				response.sendRedirect("multichoicequestions.jsp?testid="+status);
			}
			else if(typeOfQuestion.equals(TRUEORFALSE))
			{
				response.sendRedirect("truefalsequestions.jsp?testid="+status);
			}
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
