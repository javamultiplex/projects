package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;

/**
 * Servlet implementation class StudentEnrollmentProcess
 */
@WebServlet("/admin/StudentEnrollmentProcess")
public class StudentEnrollmentProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentEnrollmentProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType(HTML);
		Student student=new Student();
		String message=null;
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		int branch=Integer.parseInt(request.getParameter("branch"));
		student.setFirstName(firstName);
		student.setLastName(lastName);
		student.setBranch(branch);
		Connection con=DBConnection.getConnection();
		int status=StudentDB.insertStudentDataByAdmin(con, student);
		if(status>0)
		{
			message="Student has been added successfully!!";
			response.sendRedirect("addstudent.jsp?message="+message);
		}
		else
		{
			message="Some Error has occured!";
			response.sendRedirect("addstudent.jsp?message="+message);
		}
		
		
	}

}
