package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.utilities.CapitalizeFirstLetter;

/**
 * Servlet implementation class GetStudentDetailsByID
 */
@WebServlet("/admin/GetStudentDetailsByID")
public class GetStudentDetailsByID extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetStudentDetailsByID() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		int studentID=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		List<String> studentList=StudentDB.getStudentDetailsById(con, studentID);
		out.println(TABLESTARTTAG);
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>First Name</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print(CapitalizeFirstLetter.getResultantString(studentList.get(0)));
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>Last Name</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print(CapitalizeFirstLetter.getResultantString(studentList.get(1)));
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>Email ID</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print(studentList.get(2));
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>Phone Number</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print(studentList.get(3));
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>Branch</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print(studentList.get(4));
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		out.print(TABLEENDTTAG);
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
