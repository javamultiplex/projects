package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.BranchDB;
import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;

/**
 * Servlet implementation class UpdateStudentBranchView
 */
@WebServlet("/admin/UpdateStudentBranchView")
public class UpdateStudentBranchView extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStudentBranchView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		int studentID=Integer.parseInt(request.getParameter("id"));
		Connection con=DBConnection.getConnection();
		List<String> studentList=StudentDB.getStudentDetailsById(con, studentID);
		Map<Integer,String> branch=BranchDB.getBranchDetails(con);
		Set<Entry<Integer,String>> set=branch.entrySet();
		Iterator<Entry<Integer,String>> iterator=set.iterator();	
		out.println(TABLESTARTTAG);
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>Current Branch</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<input type='text' style='width:250px;' value='"+studentList.get(4)+"'/>");
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEROWSTARTTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<b>New Branch</b>");
		out.print(TABLECELLENDTAG);
		out.print(TABLECELLSTARTTAG);
		out.print("<select name='branch' style='width:255px;'>");
		out.print("<option value='None'>None</option>");
		while(iterator.hasNext())
		{
			Entry<Integer,String> entry=iterator.next();
			out.print("<option value='"+entry.getKey()+"'>"+entry.getValue()+"</option>");
		}
		out.print("</select>");
		out.print(TABLECELLENDTAG);
		out.print(TABLEROWENDTAG);
		
		out.print(TABLEENDTTAG);
		
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
