package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;
import com.pojo.Student;

/**
 * Servlet implementation class AdminLoginProcess
 */
@WebServlet(urlPatterns={"/LoginProcess","/admin/LoginProcess"})
public class LoginProcess extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String role=request.getParameter("role");
		RequestDispatcher rd=null;
		HttpSession session=null;
		if(role.equals("admin"))
		{
				if(name.equalsIgnoreCase("admin") && password.equalsIgnoreCase("Password1"))
				{
					session=request.getSession();
					session.setAttribute("name", "admin");
					response.sendRedirect("home.jsp");
				}
				else
				{
					out.println("<center><h1>Invalid username or password.</h1></center>");
					rd=request.getRequestDispatcher("index.jsp");
					rd.include(request, response);
				}
		}
		else if(role.equals("student"))
		{
			Student student=new Student();
			student.setEnrollment(name);
			student.setPassword(password);
			Connection con=DBConnection.getConnection();
			boolean status=StudentDB.isValidStudent(con, student);
			if(status)
			{
				status=StudentDB.isFirstLogin(con, student);
				if(status==false)
				{
					response.sendRedirect("forgetpassword.jsp?id="+name);
				}
				else
				{
					session=request.getSession();
					session.setAttribute("id",name);
					response.sendRedirect("home.jsp");
				}
			}
			else
			{
				out.println("<center><h1>Invalid Roll Number or password.</h1></center>");
				rd=request.getRequestDispatcher("index.jsp");
				rd.include(request, response);
			}
			
		}
		out.close();
	}

}
