package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.TestDB;
import com.inteface.Constants;
import com.pojo.Test;

/**
 * Servlet implementation class UpdateTestDetails
 */
@WebServlet("/admin/UpdateTestDetails")
public class UpdateTestDetails extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateTestDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		Test test=new Test();
		int id=Integer.parseInt(request.getParameter("testtitle"));
		String title=request.getParameter("title");
		int marks=Integer.parseInt(request.getParameter("marks"));
		String description=request.getParameter("description");
		test.setTitle(title);
		test.setDescription(description);
		test.setMarks(marks);
		Connection con=DBConnection.getConnection();
		int status=TestDB.updateTestDetails(con, test, id);
		if(status>0)
		{
			response.sendRedirect("viewtest.jsp?message=success");
		}
		else
		{
			response.sendRedirect("viewtest.jsp?message=fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
