package com.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.DBConnection;
import com.db.StudentDB;
import com.inteface.Constants;

/**
 * Servlet implementation class UpdateStudentBranch
 */
@WebServlet("/admin/UpdateStudentBranch")
public class UpdateStudentBranch extends HttpServlet implements Constants{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStudentBranch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType(HTML);
		int id=Integer.parseInt(request.getParameter("id"));
		int branchID=Integer.parseInt(request.getParameter("branch"));
		Connection con=DBConnection.getConnection();
		int status=StudentDB.updateBranchNameById(con, id, branchID);
		if(status>0)
		{
			response.sendRedirect("updatestudent.jsp?message=success");
		}
		else
		{
			response.sendRedirect("updatestudent.jsp?message=fail");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
